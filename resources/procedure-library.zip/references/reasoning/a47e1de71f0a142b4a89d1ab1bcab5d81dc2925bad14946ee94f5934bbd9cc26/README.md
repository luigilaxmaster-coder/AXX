# Axx — Biblioteca de razonamiento operativo y aprendizaje verificable

Fecha: 29 de octubre de 2026. Idioma: español.

Este paquete contiene documentación original de integración y un catálogo de fuentes primarias. No contiene una nueva aplicación, instaladores, conectores activos, modelos, credenciales ni pruebas físicas ejecutadas. No modifica el repositorio de Axx ni la configuración del equipo.

## Objetivo

Que Axx utilice conocimiento relevante para definir objetivos, identificar incertidumbre, elegir acciones disponibles, comprobar resultados y conservar lecciones reutilizables. Se busca una mejora medible del comportamiento, no afirmar conciencia, lectura de mente o entrenamiento de pesos por leer archivos.

## Tres clases de documentación

**Para el integrador:** papers, documentación de frameworks y estos contratos. Sirven para diseñar e implementar el sistema.

**Para Axx en ejecución:** manuales de aplicaciones compatibles, fichas de herramientas, procedimientos revisados y contexto pertinente. Se recuperan según la tarea; no se cargan todos en cada conversación.

**Producida por la experiencia:** resultados comprobados, incidentes, correcciones y recetas verificadas. Deben conservar procedencia, ámbito y vigencia.

## Orden de lectura

1. `01_FUENTES_PRIORIZADAS.md`: qué extraer de cada fuente.
2. `02_RAZONAMIENTO_OPERATIVO.md`: decisiones y estado de tarea.
3. `03_MEMORIA_Y_CONOCIMIENTO.md`: recuerdos, vigencia y olvido.
4. `04_DOCUMENTOS_A_HABILIDADES.md`: convertir conocimiento en procedimientos.
5. `05_MODOS_CAPACIDADES_Y_EJECUCION.md`: Discreto, Copiloto y Full.
6. `06_EVALUACION_Y_MEJORA.md`: criterios de prueba y promoción.
7. `07_PROMPT_PARA_INTEGRADOR.md`: encargo listo para el agente de programación.
8. `08_EJEMPLO_PROCEDIMIENTO.md`: primer recorrido de ensayo.

`sources.json` es un catálogo informativo propuesto, no una API ni un formato que Axx ya reconozca. `manifest.sha256` permite detectar cambios en los archivos de este paquete; no demuestra funcionalidad ni autenticidad de las fuentes externas.

## Integración

Primero leer instrucciones, Git, propietarios, tareas y checkpoints del repositorio. Mapear los conceptos de este paquete a interfaces reales; no crear otro ejecutor, journal, planificador o memoria equivalente. Los nombres de campos de estas guías son conceptuales salvo que se verifiquen en el código.

Mantener avatar, Morph Reach, disposición radial, voz, configuración y persistencia. Preservar los tres perfiles configurables. Full admite iniciativa y observación intensivas expresamente configuradas, no capacidades imaginadas ni ampliaciones de permiso por una predicción.

R02 sigue siendo material de diseño: 12 ejemplos, 8 familias, 0 ejecuciones según la especificación aportada. M15 no se declara resuelto sin evidencia. No promover capacidades físicas que dependan de ese aislamiento mientras permanezca bloqueado.

Las guías históricas de Axx recuperadas en esta conversación son snapshots documentales, no inspección actual del checkout. Deben contrastarse antes de programar.
