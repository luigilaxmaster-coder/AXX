# Ejemplo de procedimiento: verificar un archivo de ensayo

**Estado: especificación propuesta; no implementada ni probada en Axx por este paquete.**

Este documento es una ficha de diseño. No es un SKILL.md instalado, una API existente ni una prueba ejecutada.

## Intención

Confirmar que el archivo producido por una tarea coincide con las condiciones pactadas. Separar comprobación de existencia, integridad y contenido; ninguna implica automáticamente las otras.

## Disparador

Evento de finalización emitido por la generación real de un artefacto, con tarea, identidad del archivo, versión y resultado conocido. No disparar por una frase del modelo o por una animación.

## Entradas

Referencia estable al artefacto, condiciones esperadas de la tarea, ubicación autorizada y verificador disponible. No inventar un hash esperado después de leer el archivo y presentarlo como validación independiente.

## Precondiciones

El archivo pertenece a la tarea, el permiso permite inspeccionarlo y hay un verificador compatible. Resolver la ruta y los enlaces según la política de almacenamiento; bloquear un escape del ámbito. Trabajar sobre versión o snapshot estable cuando sea necesario para evitar que el contenido cambie durante la comprobación.

## Ejecución conceptual

En una transacción del journal, reclamar el trabajo con su clave de idempotencia. Revalidar tarea, revisión, recurso y permiso. Ejecutar la inspección mediante la infraestructura real. Guardar evidencia y estado sin confundir despacho con verificación. Emitir la actualización de UI desde el estado persistido.

Un TXT de ensayo permite verificar existencia, codificación y fragmentos esperados sin abrir aplicaciones. En otro formato, usar el verificador ya disponible; no instalar uno durante el recorrido ni ejecutar macros o scripts incrustados.

## Resultado

Informar comprobaciones concretas: archivo encontrado, formato leído y condiciones comparadas. Cuando solo se conoce existencia o tamaño, no afirmar que el contenido es correcto.

Ejemplo de mensaje de resultado, condicionado a evidencia real: “El archivo existe y se puede leer. Contiene las tres secciones solicitadas. No comprobé la exactitud del contenido de esas secciones”.

## Aprendizaje

Si funciona, actualizar evidencia de esa receta en ese contexto. No inferir una preferencia permanente por el formato o ubicación. Si falla, guardar síntoma; una causa sugerida sigue como hipótesis hasta validarse.

## Casos de desarrollo

Archivo correcto; archivo ausente; contenido incompleto; archivo cambiado antes de aceptar; permiso revocado; doble aceptación; caída después de inspeccionar; cancelación en cola; dos tareas sobre el mismo artefacto. Estos casos están expuestos y no pueden presentarse como holdout nuevo.

## Alcance de la verificación de este paquete

Solo se verifica integridad de los documentos y del ZIP. No se ha conectado este procedimiento a Axx, ejecutado una acción física, resuelto M15 ni medido una mejora de razonamiento.
