# Fuentes priorizadas para Axx

**Estado: especificación propuesta; no implementada ni probada en Axx por este paquete.**


## Criterio de selección

No instalar todos los proyectos. Adoptar patrones pequeños y comprobar su utilidad dentro de Axx. Un paper describe evidencia en sus propias tareas; no garantiza transferencia a Windows o a este asistente. Un repositorio público no prueba compatibilidad local. La fecha de consulta no fija una revisión inmutable: antes de adaptar código, registrar commit/tag, licencia exacta y dependencias.

## Núcleo: leer primero

### S01 — Cognitive Architectures for Language Agents (CoALA)

Fuente: [Cognitive Architectures for Language Agents (CoALA)](https://arxiv.org/abs/2309.02427).

Qué tomar: Organizar memoria, acciones y toma de decisiones; referencia de arquitectura, no dependencia obligatoria.

### S02 — ReAct: Synergizing Reasoning and Acting in Language Models

Fuente: [ReAct: Synergizing Reasoning and Acting in Language Models](https://react-lm.github.io/).

Qué tomar: Alternar planificación con observaciones y acciones; replantear cuando cambia la evidencia.

Repositorio de referencia: https://github.com/ysymyth/ReAct

### S03 — Reflexion: Language Agents with Verbal Reinforcement Learning

Fuente: [Reflexion: Language Agents with Verbal Reinforcement Learning](https://proceedings.neurips.cc/paper_files/paper/2023/hash/1b44b878bb782e6954cd888628510e90-Abstract-Conference.html).

Qué tomar: Lecciones en memoria episódica a partir de feedback, sin actualizar pesos.

Repositorio de referencia: https://github.com/noahshinn/reflexion

### S04 — Voyager: An Open-Ended Embodied Agent with Large Language Models

Fuente: [Voyager: An Open-Ended Embodied Agent with Large Language Models](https://voyager.minedojo.org/).

Qué tomar: Biblioteca de habilidades componibles y mejora con feedback; resultados originales en Minecraft, no en Windows.

### S05 — Agent Skills specification

Fuente: [Agent Skills specification](https://agentskills.io/specification).

Qué tomar: Formato SKILL.md, recursos asociados y carga progresiva. Un archivo no crea permisos ni herramientas.

Repositorio de referencia: https://github.com/agentskills/agentskills

### S06 — Effective context engineering for AI agents

Fuente: [Effective context engineering for AI agents](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents).

Qué tomar: Selección de contexto, recuperación bajo demanda, compactación y notas persistentes.

## Operación y ampliaciones selectivas


### S07 — LangGraph persistence and interrupts

Fuente: [LangGraph persistence and interrupts](https://docs.langchain.com/oss/python/langgraph/persistence).

Uso en Axx: Checkpoints, pausas y recuperación; reutilizar el journal de Axx antes de considerar un runtime nuevo.

### S08 — Graphiti

Fuente: [Graphiti](https://github.com/getzep/graphiti).

Uso en Axx: Memoria temporal y procedencia; candidato opcional, no una segunda memoria por defecto.

### S09 — Agent S

Fuente: [Agent S](https://github.com/simular-ai/Agent-S).

Uso en Axx: Referencias de computer use y aprendizaje de interfaces; no sustituir el ejecutor existente.

### S10 — GEPA reflective optimization

Fuente: [GEPA reflective optimization](https://github.com/gepa-ai/gepa).

Uso en Axx: Optimizar instrucciones con métricas y feedback; solo en evaluación separada, con presupuesto y sin autopromoción.

### S11 — OSWorld

Fuente: [OSWorld](https://os-world.github.io/).

Uso en Axx: Evaluación por efectos observados en entornos de ordenador, no por afirmaciones del agente.

### S12 — AgentDojo

Fuente: [AgentDojo](https://github.com/ethz-spylab/agentdojo).

Uso en Axx: Comprobar que contenido externo no se convierte en instrucciones de autoridad.

### S13 — Microsoft UI Automation Client Programmer Guide

Fuente: [Microsoft UI Automation Client Programmer Guide](https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-clientportal).

Uso en Axx: Acceso semántico a elementos Windows y control patterns; contrastar con el adaptador real.

### S14 — Playwright locators and actionability

Fuente: [Playwright locators and actionability](https://playwright.dev/docs/locators).

Uso en Axx: Localizadores semánticos y comprobaciones previas de interacción; verificar después el resultado de negocio.

### S15 — Adobe Photoshop UXP scripting

Fuente: [Adobe Photoshop UXP scripting](https://developer.adobe.com/photoshop/uxp/scripting/).

Uso en Axx: Operaciones documentadas de Photoshop; requiere puente compatible y pruebas locales.

### S16 — Letta memory blocks

Fuente: [Letta memory blocks](https://docs.letta.com/v1-sdk/memory/memory-blocks).

Uso en Axx: Referencia opcional de bloques de memoria persistente y de solo lectura; no migrar Axx automáticamente.

## Biblioteca interna que debe tener prioridad

Reutilizar `AXX_DOCUMENTACION_MAESTRA.md`, `AXX_ANALISIS_PROMPTS_Y_PLAN_DE_INTEGRACION.md` y `2026-10-22-axx-integracion-modular.md`, localizados en la Library durante esta consulta. Son informes y propuestas con revisiones históricas identificadas, no una comprobación actual de la instalación.

Dar prioridad al código vigente, contratos registrados y evidencia reproducible frente a ejemplos de documentación. La presencia de miles de procedimientos documentales no equivale a miles de acciones ejecutables. Resolver discrepancias dejando registradas fuente, revisión y decisión.

## Lectura versus instalación

CoALA, ReAct, Reflexion y Voyager son referencias conceptuales. Agent Skills proporciona un formato. LangGraph y Letta ofrecen patrones que no justifican por sí solos una migración. Graphiti es opcional si la memoria temporal actual no basta. GEPA requiere primero datos, métricas y presupuesto de evaluación. Agent S es referencia de computer use, no autorización para reemplazar WindowsInput o ActionExecutor.
