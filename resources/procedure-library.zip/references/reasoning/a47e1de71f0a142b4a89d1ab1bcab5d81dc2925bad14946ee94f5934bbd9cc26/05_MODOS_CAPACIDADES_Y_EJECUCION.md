# Modos, capacidades y ejecución

**Estado: especificación propuesta; no implementada ni probada en Axx por este paquete.**

## Perfiles de usuario

**Discreto:** responde a órdenes y completa su alcance; no inicia trabajos adicionales por una predicción.

**Copiloto:** observa el ámbito habilitado, sugiere y prepara borradores aislados. Ejecuta iniciativas nuevas al aceptarse o cuando una orden vigente ya las cubra.

**Full:** admite seguimiento intensivo e iniciativa autónoma en ámbitos autorizados, con permisos persistentes y sin confirmación redundante para cada paso cubierto. La comunicación puede ser silenciosa o participativa independientemente de la autonomía.

El perfil no crea privilegios por sí mismo. Configurar de forma independiente fuentes observables, retención, envío a proveedores, lectura, escritura, escritorio, comunicación externa y vigencia. No rebajar Full a meras notificaciones, ni usarlo para ignorar destino, versión o revocación.

`OFF` y `SHADOW` pueden seguir existiendo como interruptor o estado de validación del subsistema, sin convertirse en más perfiles de presencia para el usuario.

## Catálogo real de capacidades

El catálogo vigente debe indicar operación, esquema de entradas/salidas, método, precondiciones, efectos, permisos, recursos exclusivos, verificador, compatibilidad y última evidencia. Verificar esta información contra el registro y el ejecutor, no generarla a partir de marketing.

Microsoft UI Automation documenta interfaces para interactuar con controles Windows; Playwright documenta localizadores y comprobaciones de interacción web; Photoshop UXP documenta automatización dentro de Photoshop. Son fuentes para adaptadores específicos, no capacidades universales por instalar una biblioteca. [S13](https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-clientportal) · [S14](https://playwright.dev/docs/locators) · [S15](https://developer.adobe.com/photoshop/uxp/scripting/)

## Única frontera de efectos

Reutilizar ActionExecutor, journal, WindowsInput, planificador, observación, memoria y HostMCP donde sus interfaces reales lo permitan. Los módulos de aprendizaje y consulta no deben disponer de una vía paralela para producir efectos.

No tratar “verificar archivo” como permiso para ejecutar macros, scripts o contenido incrustado. Cada verificador declara si solo inspecciona, abre un programa o ejecuta código. El primer recorrido debe favorecer inspección acotada de recursos de ensayo.

## Plan y autorización

Cada aceptación se vincula a un plan canónico y revisión exactos. Un permiso persistente autoriza familias acotadas de planes, no cualquier parámetro inferido. Revalidar tras adquirir el recurso y antes del efecto. Cambiar de modelo conserva el estado, pero un plan nuevo debe volver a validarse.

La reducción de modo o revocación invalida acciones en cola incompatibles. Elevar el modo no revive descartes ni propuestas caducadas. Esc detiene lo cancelable y evita la reactivación inmediata de la misma cadena.

## Concurrencia

Establecer dueño de tarea y de cada efecto. Deduplicar propuestas por identidad semántica y recursos, no por texto. Una lease vencida no demuestra terminación; usar fencing o generación de propietario donde la infraestructura lo permita. Reconciliar efectos inciertos antes de transferir ejecución.

## Recuperación

Un checkpoint conserva progreso, pero no convierte la base de datos y una aplicación externa en una sola transacción atómica. Definir idempotencia o reconciliación por operación. No prometer “exactly once” universal mediante un hash local.

LangGraph documenta que reanudar un interrupt puede volver a ejecutar código del nodo; estudiar el patrón para el journal propio sin crear otro planificador. [S07](https://github.com/langchain-ai/docs/blob/main/src/oss/langgraph/interrupts.mdx)

Si una operación no puede reintentarse de forma demostrablemente segura, conservar estado incierto y pedir resolución concreta. Los efectos ya ocurridos deben quedar visibles.
