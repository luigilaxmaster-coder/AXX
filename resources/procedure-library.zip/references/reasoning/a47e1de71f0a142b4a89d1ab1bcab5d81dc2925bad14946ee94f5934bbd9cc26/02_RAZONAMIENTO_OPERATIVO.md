# Razonamiento operativo

**Estado: especificación propuesta; no implementada ni probada en Axx por este paquete.**

## Qué significa mejorar

Evaluar si Axx interpreta correctamente el objetivo, reconoce información faltante, consulta una fuente apropiada, selecciona un método viable, actúa dentro de alcance y detecta cuándo el resultado no coincide. No medir inteligencia por la longitud de una explicación.

CoALA organiza memoria, acciones y decisiones; ReAct estudia la alternancia entre razonamiento, acciones y observaciones. Este contrato es una adaptación propuesta para Axx, no una implementación de esos artículos. [S01](https://arxiv.org/abs/2309.02427) · [S02](https://react-lm.github.io/)

## Ciclo

Objetivo → estado confirmado → preguntas pendientes → contexto y procedimientos pertinentes → opciones viables → autorización → acción → observación del resultado → continuar, corregir o detener → lección candidata.

No hace falta invocar un modelo en cada paso. Una receta verificada y compatible puede resolverse de forma determinista. Reservar inferencia para ambigüedad relevante, composición nueva y diagnóstico de errores no cubiertos. Los presupuestos se fijan y miden en la instalación; este paquete no promete latencia.

## Estado mínimo de tarea

Conceptos a mapear al esquema existente:

| Campo conceptual | Función |
|---|---|
| Identidad y revisión de tarea | Evitar mezclar misiones o planes antiguos. |
| Objetivo y condiciones de éxito | Definir qué debe comprobarse para terminar. |
| Hechos observados con procedencia | Distinguir observación de inferencia. |
| Incertidumbres | Identificar qué dato falta y su importancia. |
| Recursos y versiones | Resolver el documento, ventana o cuenta correctos. |
| Pasos confirmados y pendientes | No repetir lo ya verificado. |
| Capacidades disponibles | Evitar inventar herramientas o parámetros. |
| Perfil y autorizaciones | Mantener independiente lo deseable de lo permitido. |
| Presupuesto y condición de parada | Evitar exploración o cadenas infinitas. |

## Selección de acciones

Una decisión debe responder: ¿contribuye al objetivo?, ¿hay evidencia suficiente del destino?, ¿existe un método disponible?, ¿está autorizado?, ¿cómo comprobaré el resultado?, ¿qué haré si el efecto queda incierto?

Cuando falte información que pueda recuperarse con una observación permitida, obtenerla antes de preguntar. Cuando dos objetivos sigan siendo plausibles, hacer una pregunta concreta. No ocultar la ambigüedad tras un número de confianza.

La predicción puede priorizar opciones, pero nunca crear una herramienta inexistente o ampliar un permiso. Un resultado semánticamente parecido recuperado del índice tampoco prueba compatibilidad técnica.

## Registro explicable

Conservar objetivo, evidencia utilizada, método elegido, justificación breve, restricciones y resultado. No requerir ni almacenar cadenas de pensamiento privadas del proveedor; el registro operativo debe bastar para auditar decisiones y reproducir efectos.

## Replanificación

Al corregir el usuario una tarea, incrementar la revisión del plan y conservar efectos confirmados. Cancelar los pasos incompatibles. Comprobar nuevamente el destino y el permiso antes del siguiente efecto. No reejecutar todo el plan desde el principio.

Una nueva observación puede invalidar una hipótesis. Mantenerla como desestimada con su motivo cuando sea útil para diagnóstico, en lugar de conservar dos hechos contradictorios como verdaderos.

## Parada

Terminar cuando se cumplen las condiciones acordadas; detener por revocación, presupuesto agotado, destino ambiguo o efecto incierto no reconciliable. Mantener borradores y progreso válido. No autoasignarse nuevas tareas para justificar actividad.
