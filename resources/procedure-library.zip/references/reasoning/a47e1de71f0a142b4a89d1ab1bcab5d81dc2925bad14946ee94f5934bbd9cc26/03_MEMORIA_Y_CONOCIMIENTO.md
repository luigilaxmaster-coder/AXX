# Memoria y conocimiento

**Estado: especificación propuesta; no implementada ni probada en Axx por este paquete.**

## Tipos que no deben mezclarse

**Trabajo:** objetivo activo, estado confirmado y datos pendientes. Su vigencia suele depender de la tarea.

**Documental:** manuales, especificaciones, fragmentos de código y referencias; conocer un procedimiento no implica poder ejecutarlo.

**Episódica:** qué se intentó, qué efecto se observó, qué se verificó y qué corrigió el usuario.

**Procedural:** recetas parametrizadas con herramientas reales, condiciones, verificadores y compatibilidad.

**Preferencias y rutinas:** instrucciones explícitas o patrones con evidencia, ámbito, excepciones y caducidad. No elevar una repetición a preferencia permanente.

CoALA proporciona un marco de memoria y acciones. Reflexion estudia guardar feedback lingüístico para orientar intentos posteriores sin modificar pesos. Estos conceptos deben adaptarse al almacenamiento existente. [S01](https://arxiv.org/abs/2309.02427) · [S03](https://proceedings.neurips.cc/paper_files/paper/2023/hash/1b44b878bb782e6954cd888628510e90-Abstract-Conference.html)

## Procedencia por registro

Registrar identificador, fuente exacta, revisión, fecha de observación, actor, tarea, ámbito, estado de verificación y dependencias. Diferenciar fecha en que se conoce algo de fecha en que es válido. Si una fuente cambia, invalidar o revisar los registros derivados pertinentes.

Para capacidades dependientes del entorno, incluir aplicación/build, sistema operativo, idioma, método de acceso y versión del contrato. Una receta no es universal porque sus palabras se parezcan a una tarea nueva.

Graphiti es una referencia de memoria temporal y procedencia. No introducirlo por defecto si las tablas, índices y relaciones existentes satisfacen estos requisitos. [S08](https://github.com/getzep/graphiti)

## Recuperación

Filtrar primero por usuario, tarea, permiso, aplicación, versión y estado. Después buscar por identificadores exactos, palabras clave y, si se mide una mejora, similitud semántica. Recuperar fragmentos pertinentes con su fuente, no libros enteros ni todos los recuerdos.

El resumen de una fuente conserva vínculo al original. Una síntesis sin fuente debe permanecer como inferencia o propuesta. No resolver una contradicción únicamente porque una frase aparece muchas veces.

La ingeniería de contexto recomienda seleccionar información y recuperarla cuando se necesita, en vez de acumularla indiscriminadamente. [S06](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents)

## Aprendizaje sin circularidad

Separar actor humano, Axx y otras automatizaciones. Una acción que Axx inicia puede probar fiabilidad técnica de una receta, pero no evidencia por sí sola una preferencia humana. La ausencia de respuesta no es feedback positivo.

Ante un fallo, almacenar primero el síntoma y la evidencia. La causa propuesta permanece como hipótesis hasta validarse. Una lección candidata debe señalar cuándo aplica y cuándo no. No usar afirmaciones del propio modelo como única prueba de que aprendió.

## Corrección y olvido

Permitir corregir el ámbito y vigencia, retirar una rutina o borrar aprendizajes de una sesión. La eliminación debe alcanzar índices, cachés, resúmenes y recetas derivadas cuando corresponda. Mantener únicamente metadatos mínimos que sean necesarios para evitar reimportar lo suprimido, de forma transparente y configurable.

Los rechazos se vinculan a identidad lógica estable, no solo a versión. Cambiar la redacción de una propuesta no debe eludir “no volver a sugerir”.

## Observación, retención y envío

Son controles separados. Full puede usar observación intensiva expresamente habilitada sin retener todo ni enviar todo a un proveedor. No guardar secretos o contenido excluido en logs, notas o índices como efecto colateral.
