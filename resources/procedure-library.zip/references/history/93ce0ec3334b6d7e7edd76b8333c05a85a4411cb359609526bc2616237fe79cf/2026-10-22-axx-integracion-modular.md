# Axx: integración modular de Coucou, Jarvis y 50 flujos — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Incorporar las capacidades útiles de Coucou, las guías adjuntas y los 50 flujos del catálogo Jarvis dentro del Axx residente, con entregas independientes y resultados verificables.

**Architecture:** Conservar el host Tauri/Rust, la interfaz HTML/JavaScript/WebGL y el backend Python de AXX. Ampliar su registro de capacidades, CommandService, ActionExecutor y memoria; adaptar de Coucou el relé y protocolos, y de Axx-System únicamente componentes comprobables. Los 50 casos de uso se implementan como recetas sobre servicios compartidos.

**Tech Stack:** Base existente AXX v0.20.3; Tauri 2/Rust; Python; SQLite; JavaScript/WebGL. Adaptadores Windows, UI Automation, servicios de modelos y conectores autenticados según cada entrega. Dependencias de voz/visión adicionales solo cuando su módulo las necesite.

**Spec:** Solicitud del usuario; `Texto pegado(6).txt`; `GUIA_CREAR_COUCOU_PASO_A_PASO.md`; `GUIA_CREAR_JARVIS_PASO_A_PASO.md`; `GUIA_ESTILO_GRAFICO_Y_DISENO.md`; `README.md` adjunto. Las decisiones y especificaciones de integración se desarrollan en este mismo documento.

**Fecha de revisión:** 22 de octubre de 2026.  
**Alcance:** Auditoría estática y propuesta de implementación. No se han modificado los repositorios, compilado sus aplicaciones ni probado hardware Windows en esta revisión.

## Global Constraints

- Base propuesta: `luigilaxmaster-coder/AXX`, commit `3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6`.
- Referencia Coucou: `Louis-CFM/coucou`, commit `1e5180921c1326fc72e41d313e3e2855e9c10162`.
- Componentes candidatos de Axx-System: commit `7b0d627cdd5e6e5fe74f198c7f042b06a6155efb`.
- Conservar identidad de Axx: cuerpo 3D propio, acabado oscuro/iridiscente, herramientas radiales y paneles independientes.
- Mantener la semántica de invocación, retorno a base y cancelación de Axx; cualquier acceso nuevo debe ser configurable y comprobar conflictos.
- Primera acción rápida: Magic Pen. Siguiente entrega: conversor de archivos. Móvil al final.
- Mantener separación entre transcribir, insertar y enviar; y entre proponer, autorizar, ejecutar y verificar.
- Conservar el proveedor/modelo seleccionado. La comparación entre modelos crea versiones explícitas y no repite efectos externos.
- Código ajeno adaptado conserva los avisos de licencia correspondientes. Los activos propios de Coucou no se incluyen en Axx.
- “Presente en el código”, “conectado”, “probado por CI” y “verificado en el equipo” son estados distintos.

## Review Focus

1. Contexto que cambia: ventana, selección, cuenta, archivo, monitor o escala cambian entre observar y actuar; la acción se detiene o vuelve a observar.
2. Reintento tras interrupción: un resultado incierto no provoca una segunda escritura, envío o creación.
3. Aprobación desactualizada o incompleta: se autoriza exactamente el contenido mostrado, dentro de su vigencia.
4. Información parcial: un conector desconectado, OCR incompleto o fuente antigua se muestra como limitación de cobertura.
5. Competencia por recursos: dictado, voz, reproducción y grabación comparten dispositivos y cancelación sin interrumpir sesiones ajenas.

---

## 1. Conclusión de arquitectura

La integración es viable por componentes. AXX ya ofrece una base más concreta que los ejemplos simplificados de las guías: tiene registro de herramientas, transporte autenticado, estados persistentes de operaciones, aprobaciones, cancelación y comprobaciones posteriores. Conviene ampliar esos mecanismos.

Coucou aporta sobre todo supervisión de agentes externos, puente de solicitudes, estados, diffs y patrones de voz/móvil. El catálogo Jarvis describe 50 resultados de producto; no contiene sus conectores ni código ejecutable. Axx-System contiene algunas piezas útiles de contexto y memoria, junto con rutas cuya respuesta aún es simulada. [A1][A2][A3][J1]

### Repositorios y papel propuesto

| Fuente | Estado observado | Papel en la integración |
|---|---|---|
| AXX, v0.20.3 | Tauri 2, frontend servido desde `1.AXX`, backend Python y avatar residente. | Aplicación principal y autoridad de ejecución. |
| Axx-System, paquete JS v4.0.0 | React/Vite/Three.js, Tauri y diversos servicios Python Jarvis. | Adaptar módulos seleccionados con pruebas de efectos reales. |
| Coucou | macOS Swift, Windows/Linux Tauri/Rust/TS y Android Kotlin. | Extraer contratos y módulos compatibles, conservando la identidad Axx. |
| Guías adjuntas | Fragmentos pedagógicos, varios incompletos o simulados. | Requisitos e ideas; cada fragmento se contrasta con código actual. |
| Texto pegado | 50 títulos únicos en 9 colecciones; los destacados repiten algunos. | Catálogo de recetas y criterios de aceptación del capítulo 5. |

Fuentes de stacks: manifiestos y configuración de ambos proyectos. [A4][A5][J2]

### Servicios compartidos propuestos

1. **Contexto:** selección, texto, archivo, pantalla, ventana, fecha y referencias.
2. **Voz:** captura, STT, dictado, conversación y TTS con un dueño del micrófono.
3. **Modelos:** catálogo, selección explícita, capacidad de visión/herramientas y versiones de respuestas.
4. **Conectores:** correo, calendario, archivos, mensajes, tareas, diseño y repositorios.
5. **Búsqueda:** consultas locales/federadas, sincronización y cobertura visible.
6. **Memoria:** recuerdos versionados y procedimientos separados de hechos y planes.
7. **Recetas:** composición de pasos de lectura, análisis, borrador y acción.
8. **Acciones y permisos:** contratos concretos, preparación, autorización y cancelación.
9. **Evidencia:** lectura posterior, resultados, referencias y estado incierto.
10. **Interfaz:** herramientas radiales, paneles persistentes y progreso expresado por Axx.

El relé de agentes externos es un productor de eventos y solicitudes. No adquiere autoridad para ejecutar acciones generales en el ordenador.

## 2. Coucou, separado por componentes

### C-01. Seguimiento de agentes

**Observado.** La versión Windows normaliza eventos de diferentes agentes y los refleja en estados. Aprobaciones y seguimiento son capacidades distintas. El adaptador de respuestas contempla Claude Code, Codex, Copilot CLI y Muse; otros agentes tienen integración de observación. El README reconoce agentes que no se han probado en Windows. [C1][C2]

**Incorporación.** Crear un adaptador que traduzca el evento externo a `AgentEvent`, con identidad de agente, sesión y proyecto. El panel Agentes de Axx muestra trabajando, esperando decisión, terminó, falló o perdió conexión.

**Mejora.** Indexar por `(agent_id, session_id)`. En Coucou varias vistas se agrupan por pastilla/agente; conviene evitar que dos sesiones del mismo agente mezclen su estado o diff. Un heartbeat antiguo pasa a “sin confirmar”, no a “terminado”.

**Aceptación.** Dos sesiones Claude y una Codex producen tres historiales y tres estados independientes. La caída de un relé no borra el estado de las demás.

### C-02. Aprobaciones y preguntas

**Observado.** Upstream tiene un flujo real: solicitud identificada, reconocimiento de interfaz, espera, respuesta y retorno al agente. Si falta la interfaz o la decisión, no fabrica un `allow`. La guía adjunta sí contiene un `allow` fijo como ejemplo; ese defecto no debe atribuirse al repositorio real. [C3]

**Incorporación.** Presentar una tarjeta con agente, proyecto, herramienta, destino y contenido completo. Las aprobaciones externas conservan el contrato del agente; las acciones propias pasan por CommandService/ActionExecutor. En el Axx actual hay controles específicos de rechazo/cancelación para solicitudes Codex, y las acciones locales pendientes abren su revisión en Biblioteca de comandos; no conviene sustituir esto por un botón genérico que permita todo. [A6]

**Mejoras verificadas por inspección.**

- El relé reduce cadenas ordinarias a 2.000 bytes. Una solicitud de permiso puede mostrar un comando recortado y autorizar el original: se debe mostrar completo o devolver la revisión al agente. [C4]
- La UI cierra la tarjeta antes de esperar confirmación del comando. Introducir “decisión enviada”, “confirmada”, “caducada” y “devuelta al agente”. [C5]
- Mantener cola por solicitud; impedir doble clic, reutilización y respuesta tardía.
- No convertir “ausencia de decisión” en aprobación. La conducta final corresponde al contrato y modo del agente.

**Aceptación.** Una solicitud sin clic nunca sale aprobada; una respuesta tardía no afecta otra solicitud; un comando largo no puede aprobarse ocultando parte de su contenido; el error de IPC permanece visible.

### C-03. Instalación de hooks y relé local

**Observado.** Upstream tiene pipe por SID, verificación del usuario del servidor, framing JSON, lectura estricta, copias y escritura mediante temporal. Son avances frente al ejemplo. El límite “mismo usuario” no acredita por sí mismo la identidad de aplicación. [C3][C6][C20]

**Incorporación.** Herramienta de instalación de adaptadores con diagnóstico, vista previa del cambio y desinstalación. El nombre y la ruta del relé pertenecerán a Axx. Conservar avisos de las porciones adaptadas.

**Mejora concreta.** En el instalador Claude, un grupo se considera propio si cualquiera de sus handlers contiene el marcador Coucou; eliminarlo puede borrar handlers ajenos mezclados. Modificar solo el handler propio. Añadir tamaño/plazo desde stdin y primera trama, límite de conexiones y conservación explícita de permisos Windows cuando el original tenga una DACL específica. [C7][C4]

**Aceptación.** Instalar y desinstalar conserva todos los hooks de terceros, rechaza JSON inválido, detecta cambios desde la vista previa y no altera el original si falla la copia.

### C-04. Diffs y evidencia de cambios

**Observado.** Los diffs parten de eventos terminados de herramientas; no son una vista previa universal ni un sistema de restauración. Un evento `Write` puede representarse como todo añadido sin comparación contra el archivo anterior. [C8]

**Incorporación.** Panel de cambios vinculado al agente, sesión, repositorio y revisión. Para un diff exacto de archivo existente, obtener versión anterior y posterior autorizadas o comparación Git.

**Mejora.** Etiquetar “evento de edición”, “diff exacto” y “recuento parcial”. La reversión es una operación propia con precondición sobre el archivo actual.

**Aceptación.** Una escritura sobre un archivo existente no se presenta como creación; un archivo cambiado después de la captura invalida una reversión preparada.

### C-05. Flow, dictado y conversación

**Observado.** El commit contiene una ruta Windows/Linux completa en el código: captura por `cpal`, reconocimiento con Parakeet/`sherpa-onnx`, procesamiento del texto y pegado; `lib.rs` registra y arranca los módulos. La voz conversacional transcribe y consulta Claude. Esto corrige una lectura basada solo en secciones antiguas del README que podían hacer pensar que todo seguía siendo exclusivo de macOS. [C9][C10][C11][C21]

**Incorporación.** Mantener como primera base el dictado ya presente en Axx. Adaptar de Flow su máquina de estados, vocabulario y cancelación. Evaluar el motor adicional con audio y hardware reales antes de incorporarlo al paquete. No cargar dos reconocedores cuando solo uno tiene trabajo.

**Mejoras.**

- Un gestor único de sesión de audio asigna el micrófono a dictado, conversación o notas.
- El destino de inserción conserva ventana y control seleccionados; si cambia, se vuelve a validar.
- Preservar original y traducción. El envío sigue siendo una acción distinta.
- La restauración del portapapeles de Coucou Windows conserva texto, no todos los formatos: no prometer conservación integral de imágenes/HTML al copiar el patrón. [C12]
- Axx dispone de síntesis Windows propia; puede servir de adaptación más adecuada que el respaldo nativo de Coucou Windows, cuya función devuelve `false`. [C11][A7]

**Aceptación.** Dictar, cancelar, traducir e insertar funcionan sin enviar; Esc cancela la sesión activa; no se pega en otro campo; se prueba pérdida de micrófono, dispositivo sin voces y cambios de foco.

### C-06. Notas de reuniones y llamadas

La primera entrega de Axx debe aceptar una transcripción o notas ya disponibles y producir resumen, acuerdos y tareas con referencias temporales. La captura en directo es otra entrega: micrófono y audio del sistema, buffers, interrupción, reconocimiento y conservación de originales según la preferencia del usuario.

El módulo de grabación de área de AXX describe actualmente vídeo sin audio. No se puede tratar esa grabación como transcripción de reuniones ya resuelta. [A8]

**Aceptación.** Un responsable o fecha no explícitos aparecen como propuesta; no se asigna una cita al hablante equivocado cuando la diarización es incierta. El resumen conserva enlaces a segmentos originales.

### C-07. Servicios y mensajería

Los indicadores de actividad de servicios pueden alimentar el panel de avisos. Para los flujos del catálogo se necesitan conectores con búsqueda, paginación, sincronización, lectura de objetos y, cuando proceda, escritura verificable. Un contador de notificaciones no acredita un conector de trabajo completo.

WhatsApp en Coucou usa gateways GOWA/OpenWA y una implementación macOS de texto. El contrato `send(text:to:)` y las etiquetas para medios no equivalen a notas de voz ni llamadas. La guía Jarvis propone Baileys, una implementación diferente. [C13]

**Incorporación.** Diseñar la mensajería como adaptador independiente: consulta de conversaciones, creación de borrador y envío explícito. Notas de voz, llamadas y comandos remotos son capacidades separadas con sus propias pruebas.

**Aceptación.** Borrador y envío tienen identificadores distintos; un mensaje entrante nunca obtiene permiso de control del ordenador por el mero hecho de llegar.

### C-08. Android e iPhone

**Observado.** Android↔Windows/Linux dispone de protocolo, TLS con pinning, emparejamiento, estado, aprobaciones, preguntas, chat de texto y widgets. El conjunto de mensajes no incluye audio remoto, eventos de ratón ni teclas. El token de conexión se conserva hasta rotación; no es un QR de un solo uso por defecto. Existe también diseño de relay opcional. [C14][C15]

El iPhone usa otra arquitectura con CloudKit y macOS. Su dictado compone instrucciones textuales; no convierte al teléfono en un micrófono remoto general de Windows. [C16]

**Incorporación, última fase.** Empezar con estado/chat y emparejamiento Axx. Añadir después canales expresamente separados para micrófono, teclado y trackpad, con capacidades revocables y límites de frecuencia.

**Mejora.** Secreto breve y de un solo uso para emparejar, seguido de credencial persistente independiente; lista de dispositivos y revocación. Es una propuesta para Axx, no una propiedad ya acreditada de Coucou.

**Aceptación.** Revocar un dispositivo corta nuevas operaciones. Una autorización móvil se liga a solicitud y contenido completos. La suspensión del teléfono no hace prometer entrega inmediata.

## 3. Las guías adjuntas, analizadas por separado

### 3.1. Guía de creación de Coucou

Es una explicación útil de Tauri, una ventana flotante y un relé. Sus fragmentos no constituyen una distribución terminada. En concreto: aprobación fija, función de decisión incompleta, ruta de pipe incorrecta, schema de hooks inadecuado, lectura simplificada y dependencias/registro incompletos.

**Decisión:** usarla para entender la separación de piezas; tomar como referencia técnica el upstream fijado y aplicar las correcciones C-01 a C-04. No recrear su personaje ni sustituir el host residente de Axx.

### 3.2. Guía de creación de Jarvis: sus nueve módulos

| Módulo de la guía | Evaluación | Incorporación concreta a Axx |
|---|---|---|
| 1. Electron y backend desacoplado | La separación es útil; AXX ya tiene host y backend. | Mantener Tauri/Python y módulos externos al renderer. |
| 2. Exclusión de capturas | Es una opción de ventana; no es percepción ni una garantía universal de invisibilidad. | Propiedad nativa configurable y comprobación con la API de captura utilizada. |
| 3. Computer Use ONNX/UIA | `parseBoxes` devuelve una caja fija; el ejemplo no implementa reconocimiento completo. | Empezar por UIA; sumar OCR y detector apropiado solo donde falte accesibilidad. |
| 4. Revisor de pasos | Los prompts no crean por sí solos un bucle de ejecución/verificación. | Envolver ActionExecutor con observar→preparar→actuar→leer resultado. |
| 5. WhatsApp/Baileys | Esqueleto distinto del conector Coucou; conexión no acredita todos los flujos. | Adaptador independiente, con estado de sesión y borradores; audio/llamadas por separado. |
| 6. PowerShell/Office COM | Ejemplo Excel con valores fijados; faltan contratos completos, errores, timeout y limpieza. | Trabajadores específicos Excel, Word y Outlook, añadidos uno a uno. |
| 7. WebRTC/GPT-Live | La guía no es prueba de latencia ni implementación completa del cliente. | Adaptador de voz del proveedor vigente, sesión gestionada desde backend y pruebas de interrupción. |
| 8. Memoria/Dreaming | La sustitución de “going to” por pasado inventa que una intención ocurrió. | Recuerdos versionados con fuente y vigencia; planes vencidos quedan por confirmar. |
| 9. Runtimes y empaquetado | Específico del ejemplo Electron, sin acreditar paquete reproducible. | Extender build Tauri/Python existente; verificar módulos, modelos y avisos incluidos. |

No debe declararse erróneo un endpoint únicamente por su nombre. El módulo de voz deberá contrastar su contrato con la documentación vigente del proveedor en el momento de implementarse; las cifras publicitadas de latencia o memoria requieren medición en el equipo.

### 3.3. Guía gráfica

Propone paletas, bordes, spring motion y superficies translúcidas útiles como referencia. El ejemplo denominado gradiente de 48 pasos contiene menos paradas; su CSS no es una medición del comportamiento óptico ni un renderer 3D. La transparencia de un elemento HTML tampoco acredita por sí sola un desenfoque del escritorio por detrás de la ventana.

**Aplicación a Axx:**

- Estado por color/movimiento y texto accesible: escuchando, trabajando, esperando, error y terminado.
- Paneles con jerarquía, contraste, foco de teclado y animación reducida.
- Avatar y tentáculos propios; las novedades se incorporan a las herramientas radiales.
- Separar posición base persistente, posición temporal al invocar y geometría de paneles.
- Pausar trabajo visual cuando no aporta información y medir consumo real en reposo.

El código MIT de Coucou se puede adaptar conservando su aviso; nombre, Mochi, diseño/animaciones del personaje, iconos, sonidos y determinados medios quedan excluidos por `LICENSE-ASSETS.md`. La integración propuesta usa los recursos propios de Axx. [C17][C18]

### 3.4. README adjunto

Sirve de índice de las tres guías y requisitos generales. No añade un cuarto motor ni acredita compatibilidad conjunta. Sus dependencias deben resolverse por módulo contra los manifiestos reales de AXX, evitando instalar todas las pilas de las guías para una función pequeña.

## 4. Qué existe ya en Axx y qué conviene ampliar

### 4.1. Autoridad de ejecución

`backend/actions/executor.py` registra operaciones, argumentos, evidencias y resultados. Un `operation_id` repetido no debe volver a ejecutar un efecto; reutilizarlo con otros argumentos se rechaza. Una caída deja estado incierto. El resultado de una herramienta se comprueba, no se deduce de que la llamada haya sido aceptada. [A1]

**Conservar:** esa autoridad para todas las nuevas escrituras, exportaciones y acciones de escritorio. Añadir herramientas tipadas y esquemas; no habilitar un ejecutor arbitrario por cada receta.

### 4.2. Registro y superficie de usuario

`backend/connect/registry.py` describe herramientas y límites. Incluye transformación determinista de texto, paneles, dictado, lector, música y otras funciones. Algunas capacidades constan como pendientes porque no pueden acreditar aún el resultado completo. Un handler registrado no equivale a disponibilidad: la UI comunica handlers activos. [A2]

Magic Pen requiere una transformación asistida por modelo y un flujo de selección/vista previa/inserción, más allá de las funciones actuales de limpiar, ordenar o cambiar mayúsculas. La conversión numérica/unidades de `runLocal` tampoco acredita un conversor general de archivos.

### 4.3. Memoria

Axx ya tiene memoria procedural SQLite para recetas, versiones, intentos y entorno. Es una base apropiada para repetir procedimientos verificados, con sus permisos actuales. La memoria de hechos, decisiones, preferencias y planes es otro conjunto de registros. [A3]

De Axx-System, `record_store.py` ofrece versionado, separación por ámbito, propuestas y recuperación. Su propia validación rechaza `verified_execution` porque no está ligada al journal; al adaptarla a Axx esa conexión debe realizarse con evidencia real. [J3]

**Modelo propuesto:** `kind`, `content`, `source_refs`, `asserted_at`, `valid_from`, `valid_until`, `status`, `version` y `supersedes`. “Aprobado para recordar” acredita el permiso de guardar, no la verdad del contenido.

### 4.4. Contexto y acciones de Windows

El módulo UIA de Axx-System contiene recolección real de ventana/controles; el contexto espacial incluye selecciones, geometrías, PID, monitores y caducidad. Son candidatos a adaptación bajo el contrato Axx. [J4][J5]

Existe también una ruta `WindowsExecutor` que devuelve ventanas y texto de pantalla fijos con `ok: True`. Esos métodos no acreditan efectos físicos. Por eso se elige cada adaptador y se exige lectura posterior del sistema antes de mostrar éxito. [J1]

Microsoft UI Automation ofrece propiedades y patrones de controles; `SendInput` está sujeto a niveles de integridad. No se debe prometer control de todas las ventanas desde un proceso sin elevar. [M1][M2]

### 4.5. Office y documentos

No se identificó un adaptador tipado completo Word/Excel/Outlook en los registros revisados. La existencia de PowerShell no resuelve el ciclo de vida de Office.

La propuesta separa edición del archivo de automatización de la aplicación abierta. Para operaciones que necesitan Office: trabajador STA, timeout, detección de diálogo, instancia propia identificada, limpieza en `finally` y lectura posterior. Microsoft documenta restricciones y bloqueos posibles en automatización no interactiva; la sesión local de usuario requiere sus propias pruebas, no se puede tratar como un servicio universal. [M3]

Primera entrega sugerida: leer un rango Excel y crear una copia con cambios explícitos. Después Word y borradores Outlook. Envíos y cambios compartidos se incorporan como acciones distintas.

### 4.6. Construcción y trazabilidad

El build predeterminado de Axx-System copia un bundle congelado sobre `dist` después de Vite. Un cambio en `src` puede no ser la aplicación servida; hay un canal explícito `source`. La integración propuesta en AXX debe comprobar el identificador/hash del código empaquetado. [J6]

La CI Windows de Coucou para el commit fijado terminó en éxito. Es evidencia de construcción y pruebas upstream, no de instalación de esta integración ni de latencias en el equipo. [C19]

## 5. Catálogo: los 50 flujos por separado

Estos son requisitos de producto extraídos del nuevo adjunto. Cada implementación y criterio siguiente es una propuesta para Axx. Los nombres originales permiten comprobar cobertura uno a uno.

**Fases:** P1 acciones rápidas; P2 contexto/voz; P3 agentes; P4 memoria/conectores; P5 automatización especializada. P6 móvil se trata aparte porque no forma parte de los 50 flujos del texto.

### Pantalla y contexto

#### 01. Preguntar sobre la pantalla

**Original:** Ask about your screen.  
**Base / fase:** Contexto + visión; P2.  
**Implementación y mejora:** Capturar la región elegida, ventana, texto UIA/OCR y momento de captura; responder citando región o fragmento.  
**Criterio de aceptación:** La respuesta distingue lo visible de lo inferido y conserva una referencia a la captura.

#### 02. Orientarse en aplicaciones

**Original:** Navigate confusing apps.  
**Base / fase:** Contexto + acciones; P2.  
**Implementación y mejora:** Localizar controles mediante UIA y explicar el siguiente paso; ofrecer resaltar antes de activar.  
**Criterio de aceptación:** Un cambio de ventana invalida el objetivo; guiar no ejecuta acciones por sí solo.

#### 03. Investigar desde la página actual

**Original:** Research from the current page.  
**Base / fase:** Contexto + investigación; P4.  
**Implementación y mejora:** Combinar URL/texto accesible y selección con búsqueda web; guardar fecha y enlaces de fuentes.  
**Criterio de aceptación:** Una afirmación verificable incluye fuente; la captura no se presenta como lectura completa del sitio.

#### 04. Preguntar mientras se ve un vídeo

**Original:** Ask while watching.  
**Base / fase:** Contexto + audio; P2.  
**Implementación y mejora:** Adjuntar fotograma y tiempo; usar subtítulos o transcripción del intervalo cuando estén disponibles.  
**Criterio de aceptación:** Axx identifica el intervalo analizado y no atribuye al vídeo contenido fuera de ese intervalo.

#### 05. Rehacer con otro modelo

**Original:** Redo this with another model.  
**Base / fase:** Router de modelos; P1.  
**Implementación y mejora:** Crear una nueva versión con la misma pregunta y contexto congelado, seleccionando explícitamente proveedor/modelo.  
**Criterio de aceptación:** Conserva ambas versiones y nunca repite automáticamente acciones externas al comparar respuestas.

#### 06. Controlar memoria y permisos

**Original:** Control what Jarvis remembers and can do.  
**Base / fase:** Memoria + permisos; P4.  
**Implementación y mejora:** Panel de recuerdos, fuentes, vigencia y permisos por función/conector; corregir, olvidar y revocar.  
**Criterio de aceptación:** Una revocación impide nuevas lecturas y un olvido elimina también índices derivados dentro del alcance declarado.

### Voz y accesos rápidos

#### 07. Hablar sobre lo que se está viendo

**Original:** Talk to what you’re looking at.  
**Base / fase:** Voz + contexto; P2.  
**Implementación y mejora:** Vincular cada turno de voz a una captura o selección identificable y al modelo elegido.  
**Criterio de aceptación:** Si la pantalla cambia, Axx refresca o pregunta a cuál contexto se refiere; Esc cancela el turno.

#### 08. Dictar instrucciones

**Original:** Dictate instructions.  
**Base / fase:** Voz + acciones; P2.  
**Implementación y mejora:** Extender el dictado existente con modos separados: transcribir, insertar y proponer una acción.  
**Criterio de aceptación:** La voz no se convierte en PowerShell ni envía mensajes automáticamente; el campo de destino sigue siendo el seleccionado.

#### 09. Recorrer código mediante voz

**Original:** Walk through code by voice.  
**Base / fase:** Voz + código; P2.  
**Implementación y mejora:** Leer archivo/rango o diff autorizado, añadir terminal visible y permitir preguntas habladas.  
**Criterio de aceptación:** La explicación referencia archivo y líneas; no afirma que una prueba pasó sin resultado real.

### Comunicación

#### 10. Gestionar la bandeja de entrada

**Original:** Manage your inbox.  
**Base / fase:** Conector correo + recetas; P4.  
**Implementación y mejora:** Conector de correo con sincronización incremental, hilos y clasificación; preparar borradores revisables.  
**Criterio de aceptación:** Todo resumen enlaza al hilo y el borrador queda separado de su envío.

#### 11. Redactar respuestas con tu tono

**Original:** Draft replies in your voice.  
**Base / fase:** Magic Pen + memoria; P1.  
**Implementación y mejora:** Magic Pen usa el mensaje seleccionado y ejemplos de estilo aprobados; muestra original y propuesta.  
**Criterio de aceptación:** Mantiene nombres, cifras e intención; permite corregir el estilo y elegir qué ejemplos recordar.

#### 12. Detectar lo urgente

**Original:** Check what’s urgent.  
**Base / fase:** Conectores + clasificación; P4.  
**Implementación y mejora:** Reglas de prioridad configurables sobre correo, tareas y calendario, con deduplicación de avisos.  
**Criterio de aceptación:** Cada prioridad muestra motivo, fuente y fecha; faltas de acceso se declaran como cobertura parcial.

#### 13. Mejorar la redacción en inglés

**Original:** Sound sharper in English.  
**Base / fase:** Magic Pen + traducción; P1.  
**Implementación y mejora:** Acción rápida de corrección, traducción y tono; conservar original y nombres propios.  
**Criterio de aceptación:** Respeta cifras y negaciones; inserción y envío son operaciones distintas.

#### 14. Preparar respuestas a clientes

**Original:** Prepare customer replies.  
**Base / fase:** Correo + conocimiento; P4.  
**Implementación y mejora:** Recuperar conversación, documentación de producto y políticas válidas; redactar con referencias.  
**Criterio de aceptación:** No promete precios, descuentos o compromisos ausentes de las fuentes.

#### 15. Preparar una propuesta de renovación

**Original:** Draft a renewal pitch.  
**Base / fase:** CRM + análisis + escritura; P5.  
**Implementación y mejora:** Cruzar historial, uso, incidencias y valor demostrado; elaborar un borrador editable.  
**Criterio de aceptación:** Señala datos faltantes y conserva evidencia para cifras y condiciones comerciales.

### Reuniones y planificación

#### 16. Preparar reuniones

**Original:** Prepare meeting briefs.  
**Base / fase:** Calendario + búsqueda; P4.  
**Implementación y mejora:** Unir evento, participantes, agenda, mensajes y documentos autorizados; generar objetivos y preguntas.  
**Criterio de aceptación:** El brief corresponde al evento correcto y enlaza sus fuentes.

#### 17. Planificar el día

**Original:** Plan your day.  
**Base / fase:** Calendario + tareas; P4.  
**Implementación y mejora:** Combinar calendario, tareas, duraciones propuestas y margen; producir agenda editable.  
**Criterio de aceptación:** Respeta zona horaria y solapamientos; distingue propuesta de cambios guardados.

#### 18. Gestionar calendario y recordatorios

**Original:** Manage calendar and reminders.  
**Base / fase:** Calendario + ejecución; P4.  
**Implementación y mejora:** Adaptadores tipados de consulta y creación, con zona horaria, recurrencia y lectura posterior.  
**Criterio de aceptación:** Un reintento conserva el identificador y no duplica citas ni recordatorios.

#### 19. Retomar el trabajo

**Original:** Pick up where you left off.  
**Base / fase:** Memoria de trabajo; P4.  
**Implementación y mejora:** Guardar una instantánea explícita de proyecto: archivos, borradores, preguntas y siguiente paso.  
**Criterio de aceptación:** Después de reiniciar recupera el estado guardado y avisa si un archivo cambió.

#### 20. Preparar una reunión individual

**Original:** Prepare for a 1:1.  
**Base / fase:** Reuniones + memoria; P4.  
**Implementación y mejora:** Recuperar acuerdos abiertos, cambios y asuntos que el usuario quiera tratar; redactar agenda.  
**Criterio de aceptación:** Separa citas de interpretaciones y muestra pendientes realmente documentados.

#### 21. Resumir una llamada con un cliente

**Original:** Summarize a customer call.  
**Base / fase:** Transcripción + recetas; P2/P4.  
**Implementación y mejora:** Primera entrega: importar notas/transcripción; después integrar captura de micrófono y audio del sistema.  
**Criterio de aceptación:** Acciones, responsables y fechas aparecen como confirmados o propuestos según el texto fuente.

### Proyectos y equipos

#### 22. Resumir hilos de Slack

**Original:** Summarize Slack threads.  
**Base / fase:** Slack + búsqueda; P4.  
**Implementación y mejora:** Conector con permisos del usuario, reconstrucción del hilo y enlaces a mensajes.  
**Criterio de aceptación:** No mezcla hilos ni inventa responsables; conserva citas y acceso por espacio.

#### 23. Convertir conversaciones en tareas

**Original:** Turn conversations into tasks.  
**Base / fase:** Recetas + gestor de tareas; P4.  
**Implementación y mejora:** Extraer propuestas y revisarlas antes de crearlas mediante un adaptador del gestor elegido.  
**Criterio de aceptación:** No duplica una tarea al reintentar; cada tarea conserva vínculo a la conversación.

#### 24. Seguir el estado de proyectos

**Original:** Track project status.  
**Base / fase:** Conectores + memoria; P4.  
**Implementación y mejora:** Calcular cambios desde un punto de control en tareas, issues, mensajes y documentación.  
**Criterio de aceptación:** Indica última sincronización y no transforma un plan o comentario en trabajo terminado.

#### 25. Revisar trabajo de GitHub

**Original:** Review GitHub work.  
**Base / fase:** GitHub + código; P3/P4.  
**Implementación y mejora:** Consultar repositorios, issues, PR, diffs y comprobaciones con commit/revisión identificables.  
**Criterio de aceptación:** Distingue código leído, comprobaciones de CI observadas y pruebas ejecutadas por Axx.

#### 26. Ponerse al día tras una ausencia

**Original:** Catch up after time off.  
**Base / fase:** Búsqueda federada + memoria; P4.  
**Implementación y mejora:** Buscar novedades dentro de un intervalo y agrupar decisiones, bloqueos y acciones pendientes.  
**Criterio de aceptación:** Respeta fechas, evita duplicados y muestra qué aplicaciones no pudieron consultarse.

#### 27. Preparar la incorporación de una persona

**Original:** Brief me on a new hire.  
**Base / fase:** Conocimiento + escritura; P4.  
**Implementación y mejora:** Crear una guía de proyecto, contactos profesionales, documentos y primeras tareas permitidas.  
**Criterio de aceptación:** Ajusta información al acceso del destinatario y no incorpora datos personales irrelevantes.

#### 28. Preparar una actualización de CRM

**Original:** Prepare a CRM update.  
**Base / fase:** CRM + ejecución; P5.  
**Implementación y mejora:** Extraer datos de llamada/correo y mapearlos al esquema del CRM; primera entrega como borrador estructurado.  
**Criterio de aceptación:** La actualización señala campos desconocidos y verifica los cambios si se publica.

### Diseño y producto

#### 29. Revisar diseños de Figma

**Original:** Review Figma designs.  
**Base / fase:** Figma + contexto; P4.  
**Implementación y mejora:** Leer nodos, capturas y comentarios de la versión seleccionada; emitir observaciones con referencia.  
**Criterio de aceptación:** Cada observación corresponde a un frame/nodo; diferencia defecto comprobable de preferencia.

#### 30. Convertir comentarios de diseño en acciones

**Original:** Turn design feedback into actions.  
**Base / fase:** Diseño + gestor de tareas; P4.  
**Implementación y mejora:** Agrupar feedback de Figma, mensajes y correo por componente; proponer tareas y prioridades.  
**Criterio de aceptación:** Conserva origen, evita duplicados y expone desacuerdos entre comentarios.

#### 31. Escribir notas de versión

**Original:** Write release notes from shipped work.  
**Base / fase:** GitHub + escritura; P4.  
**Implementación y mejora:** Combinar cambios de una versión, PR incluidos y notas de lanzamiento, con filtro de relevancia.  
**Criterio de aceptación:** Solo presenta como entregado lo que está incluido en la versión verificada.

### Datos y análisis

#### 32. Entender hojas de cálculo

**Original:** Understand spreadsheets.  
**Base / fase:** Archivos + tablas; P1/P5.  
**Implementación y mejora:** Leer celdas, fórmulas y tipos desde el archivo o API; explicar rangos identificados.  
**Criterio de aceptación:** Distingue fórmula, valor guardado y valor recalculado; no calcula solo desde una captura.

#### 33. Investigar un cambio de métrica

**Original:** Investigate a metric.  
**Base / fase:** Tablas + investigación; P5.  
**Implementación y mejora:** Comprobar definición, periodo y segmentos; calcular diferencias y contrastar hipótesis con fuentes.  
**Criterio de aceptación:** Separa cálculo reproducible, correlación e hipótesis causal.

#### 34. Investigar la pérdida de un cliente

**Original:** Investigate a churned account.  
**Base / fase:** CRM + cronología; P5.  
**Implementación y mejora:** Construir cronología con soporte, uso, reuniones y comunicaciones de la cuenta.  
**Criterio de aceptación:** No afirma una causa única sin evidencia; muestra lagunas y señales contradictorias.

#### 35. Comparar presupuestos de proveedores

**Original:** Compare vendor quotes.  
**Base / fase:** Documentos + tablas; P1/P5.  
**Implementación y mejora:** Extraer conceptos, moneda, impuestos, alcance, vigencia y condiciones; normalizar una tabla.  
**Criterio de aceptación:** Marca costes ausentes y diferencias de alcance; no compara solo importes finales.

#### 36. Conciliar un informe de gastos

**Original:** Reconcile an expense report.  
**Base / fase:** Archivos + cálculo; P5.  
**Implementación y mejora:** Extraer recibos y movimientos, emparejar por importe/fecha y señalar discrepancias y duplicados.  
**Criterio de aceptación:** Los totales se recalculan con aritmética y cada pareja conserva sus documentos fuente.

### Conocimiento y aprendizaje

#### 37. Encontrar archivos y contexto anterior

**Original:** Find files and old context.  
**Base / fase:** Búsqueda + archivos; P4.  
**Implementación y mejora:** Índice local y conectores de archivos con metadatos, texto y resultados vinculados.  
**Criterio de aceptación:** Respeta carpetas y cuentas autorizadas; una coincidencia muestra origen y fecha.

#### 38. Buscar en todo el espacio de trabajo

**Original:** Search your workspace.  
**Base / fase:** Conectores + búsqueda; P4.  
**Implementación y mejora:** Consultas federadas por conector, normalización y ranking; cobertura visible.  
**Criterio de aceptación:** Una aplicación desconectada aparece como no consultada, no como sin resultados.

#### 39. Resumir PDF y documentos largos

**Original:** Summarize PDFs and long documents.  
**Base / fase:** Archivos + conocimiento; P1/P4.  
**Implementación y mejora:** Extraer texto/tablas, dividir por estructura y responder con referencias a páginas/secciones.  
**Criterio de aceptación:** Expone páginas no legibles y no omite silenciosamente anexos relevantes.

#### 40. Estudiar con apuntes y clases

**Original:** Study from notes and lectures.  
**Base / fase:** Conocimiento + recetas; P4.  
**Implementación y mejora:** Construir explicaciones y ejemplos a partir del material elegido; mantener referencias.  
**Criterio de aceptación:** Señala dónde termina el contenido de los apuntes y empieza una explicación adicional.

#### 41. Aprender un concepto

**Original:** Learn a new concept.  
**Base / fase:** Modelo + contexto; P1.  
**Implementación y mejora:** Receta pedagógica con nivel, ejemplos y comprobación de comprensión, usando contexto cuando proceda.  
**Criterio de aceptación:** Adapta dificultad sin atribuir al material una definición que no contiene.

#### 42. Organizar notas y memoria

**Original:** Organize notes and memory.  
**Base / fase:** Memoria + archivos; P4.  
**Implementación y mejora:** Proponer etiquetas, relaciones, fusiones y correcciones; aplicar cambios versionados.  
**Criterio de aceptación:** Una fusión conserva procedencia y puede deshacerse sin perder notas originales.

#### 43. Encontrar dónde se tomó una decisión

**Original:** Find the decision.  
**Base / fase:** Memoria + búsqueda; P4.  
**Implementación y mejora:** Extraer decisiones con autor, fecha, cita, estado y relación con decisiones sustituidas.  
**Criterio de aceptación:** Distingue propuesta, acuerdo y decisión vigente; muestra si hay contradicción.

#### 44. Investigar una empresa o contacto profesional

**Original:** Research a prospect.  
**Base / fase:** Investigación + CRM; P5.  
**Implementación y mejora:** Combinar fuentes públicas y notas autorizadas para preparar un brief con fecha.  
**Criterio de aceptación:** Identidad desambiguada, fuentes visibles y ausencia de inferencias personales sensibles.

#### 45. Verificar una respuesta de Axx

**Original:** Verify what Jarvis told you.  
**Base / fase:** Verificación + investigación; P2/P4.  
**Implementación y mejora:** Descomponer afirmaciones y contrastarlas con fuentes o cálculos; señalar respaldo y contradicciones.  
**Criterio de aceptación:** Un segundo modelo no cuenta por sí solo como verificación; el resultado muestra evidencia.

#### 46. Hacer preguntas sobre los apuntes

**Original:** Quiz me from my notes.  
**Base / fase:** Conocimiento + voz; P4.  
**Implementación y mejora:** Generar preguntas, respuestas justificadas y pistas desde el material seleccionado; modo voz opcional.  
**Criterio de aceptación:** Cada respuesta correcta tiene respaldo en el material; el progreso puede borrarse.

### Creación

#### 47. Reescribir con tu estilo

**Original:** Rewrite text in your own tone.  
**Base / fase:** Magic Pen + memoria; P1.  
**Implementación y mejora:** Magic Pen transforma selección o borrador con reglas de estilo y ejemplos aceptados.  
**Criterio de aceptación:** Muestra cambios, preserva significado y permite copiar, insertar o descartar.

#### 48. Crear publicaciones con contexto

**Original:** Create posts from context.  
**Base / fase:** Escritura + conectores; P4.  
**Implementación y mejora:** Receta por canal que usa notas, cambios y datos elegidos; produce borradores.  
**Criterio de aceptación:** No inventa métricas y publicar exige una acción diferenciada sobre el borrador final.

#### 49. Convertir notas de entrevista en feedback

**Original:** Turn interview notes into feedback.  
**Base / fase:** Escritura + documentos; P4.  
**Implementación y mejora:** Organizar evidencias por criterios del puesto y separar observación de conclusión.  
**Criterio de aceptación:** Todo juicio se apoya en notas pertinentes; evita atributos sensibles o suposiciones personales.

#### 50. Redactar una actualización para dirección

**Original:** Draft a board update.  
**Base / fase:** Análisis + escritura; P5.  
**Implementación y mejora:** Integrar métricas, avances, clientes, riesgos y decisiones requeridas en una plantilla.  
**Criterio de aceptación:** Las cifras tienen periodo y fuente; conserva incertidumbres y revisión del autor.

## 6. Contratos comunes propuestos

Son nombres nuevos de diseño; esta auditoría no los ha añadido al repositorio.

| Contrato | Campos mínimos | Regla de uso |
|---|---|---|
| `ContextSnapshot` | `context_id, captured_at, source_kind, window_identity, region, text_refs, file_refs, expires_at, cloud_allowed` | El contexto se cita y sus permisos acompañan cada uso. |
| `WorkflowSpec` | `workflow_id, version, input_schema, required_capabilities, steps, output_schema` | Describe una receta; no concede autoridad a sus pasos. |
| `TaskRequest` | `operation_id, command_id, inputs, context_id, origin` | Se adapta a la ejecución existente y conserva el identificador en reintentos. |
| `ActionReceipt` | `operation_id, state, postconditions_passed, evidence_refs, output, error` | Distingue aceptación de una llamada y efecto comprobado. |
| `AgentEvent` | `event_id, agent_id, session_id, project, event_type, request_id, payload_ref, observed_at` | Deduplica eventos sin mezclar sesiones y conserva íntegra la acción autorizada. |
| `MemoryRecord` | `kind, content, source_refs, validity, status, version, supersedes` | Un plan caducado no se convierte automáticamente en hecho pasado. |
| `Connector` | `capabilities(), search(query,cursor), fetch(ref), prepare(action), apply(prepared_id)` | Anuncia solo capacidades autorizadas y disponibles. |

Pantallas, documentos y mensajes son datos de contexto; su contenido no amplía permisos ni se convierte en instrucción privilegiada. Un historial unifica la presentación, distinguiendo herramientas propias y decisiones delegadas a agentes externos.

## 7. Entregas independientes y archivos que tocar

Las rutas bajo “Crear” son propuestas. Cada entrega tiene una salida comprobable y se puede deshabilitar sin desactivar herramientas actuales.

### P0. Base y capacidades

**Existentes:** `backend/connect/registry.py`, `backend/connect/service.py`, `backend/commands.py`, `backend/actions/executor.py`, `1.AXX/scripts/axx-connect.js`.  
**Crear:** `backend/workflows/contracts.py`, `backend/workflows/tests/test_contracts.py`.  
**Interfaz:** `validate_workflow(spec: dict, capabilities: dict) -> dict`.

- [ ] Registrar build/commit y capacidades disponibles en el equipo objetivo.
- [ ] Escribir `test_workflow_rejects_unavailable_capability`: una receta no comienza si su conector requerido está desconectado.
- [ ] Implementar comprobación de dependencias sobre la autoridad de ejecución existente.
- [ ] Verificar cancelación, estado incierto y selección del modelo con los controles actuales.
- [ ] Entregar catálogo visible de capacidades y limitaciones reales.

### P1-A. Magic Pen como primera acción rápida

**Existentes:** `1.AXX/Axx.html`, registro de capacidades y herramientas.  
**Crear:** `1.AXX/scripts/magic-pen.js`, `backend/workflows/text_rewrite.py`, `backend/actions/text_edit.py`, `backend/workflows/tests/test_text_rewrite.py`, `backend/actions/tests/test_text_edit.py`.  
**Interfaces:** `preview_text(context: dict, instruction: str, model_ref: dict) -> dict`; `insert_text(proposal_id: str, target: dict, operation_id: str) -> dict`.

- [ ] Escribir `test_text_insert_refuses_stale_target`: cambiar ventana/control/selección impide insertar.
- [ ] Implementar selección, original, propuesta, cambios y referencia al modelo.
- [ ] Añadir corregir, traducir, resumir, explicar y reescribir al panel apropiado.
- [ ] Implementar copiar y descartar; habilitar inserción para destinos identificables.
- [ ] Verificar nombres, números, negaciones, cancelación y foco. Insertar no envía.
- [ ] Entregar esta función antes de ampliar la automatización de escritorio.

El dibujo, lazo y subrayado alimentarán después el mismo contrato de contexto. La primera entrega puede limitarse a texto seleccionado y una región explícita.

### P1-B. Conversor de archivos

**Existentes:** `backend/actions/tools.py`, `backend/commands.py`, `backend/actions/executor.py`, `backend/connect/registry.py`.  
**Crear:** `backend/actions/file_convert.py`, `backend/actions/tests/test_file_convert.py`, `1.AXX/scripts/file-converter.js`.  
**Interfaz:** `convert_file(source: str, target_format: str, destination: str, options: dict, operation_id: str) -> dict`.

- [ ] Escribir `test_conversion_keeps_source_and_rejects_unsupported_pair`: conserva hash del original y rechaza una pareja no admitida antes de escribir.
- [ ] Definir formatos explícitos. Primera entrega sugerida: PNG/JPEG/WebP y CSV/TSV/JSON tabular, haciendo visibles pérdidas de transparencia/tipos.
- [ ] Generar un temporal, volver a leerlo para validar el formato y publicar sin sobrescritura silenciosa.
- [ ] Incorporar permisos y parámetros al registro y a la lista de argumentos que valida el ejecutor.
- [ ] Verificar cancelación, nombre repetido, extensión engañosa, archivo corrupto y fallo de espacio.
- [ ] Ampliar DOCX/PDF y audio/vídeo según el motor disponible y la fidelidad comprobada.

La salida aceptada es un archivo real con formato comprobable; una barra de progreso no acredita conversión.

### P2-A. Contexto de pantalla y archivos

**Crear:** `backend/context/models.py`, `backend/context/service.py`, `backend/context/windows_uia.py`, `backend/context/tests/test_context.py`.  
**Adaptar:** patrones de `uia_context.py` e `interaction_context.py` auditados.  
**Interfaces:** `capture_context(request: dict) -> dict`; `validate_target(context_id: str, current: dict) -> bool`.

- [ ] Escribir `test_context_invalidates_on_pid_or_monitor_change` y `test_password_control_is_redacted`.
- [ ] Implementar lectura UIA acotada, selección de región y referencias de archivos.
- [ ] Normalizar coordenadas físicas/lógicas y conservar identidad del monitor/ventana.
- [ ] Añadir OCR donde falte texto; no deducir una tabla completa de un recorte.
- [ ] Verificar cambio de ventana, dos monitores y distintas escalas.
- [ ] Entregar preguntas sobre pantalla con referencias visibles.

### P2-B. Voz y dictado sobre contexto

**Existentes:** `1.AXX/scripts/native-voice.js`, `backend/speech/offline_asr.py`, `backend/speech/windows_tts.py`.  
**Crear:** `backend/speech/session_manager.py`, `backend/speech/tests/test_session_manager.py`.  
**Interfaces:** `acquire_audio(owner: str, purpose: str) -> dict`; `cancel_audio(session_id: str) -> dict`.

- [ ] Escribir `test_cancel_one_audio_session_keeps_other_owner_intact`.
- [ ] Conectar contexto al turno y mantener original/traducción.
- [ ] Resolver inicio, final, manos libres, dispositivo perdido y reproducción interrumpible.
- [ ] Comparar el motor existente y cualquier motor nuevo con el mismo audio español/inglés.
- [ ] Medir tiempo al primer texto, fin de turno, errores y reposo en el equipo.
- [ ] Entregar dictado/conversación sin envíos implícitos.

### P3. Relé y panel Agentes

**Existentes:** `src-tauri/src/lib.rs`, `src-tauri/Cargo.toml`, build Windows y UI Connect.  
**Crear:** `agent-hook/` como crate del relé Axx; `src-tauri/src/agent_relay/mod.rs`, `pipe.rs`, `install.rs`; `1.AXX/scripts/agent-monitor.js`.  
**Interfaz:** `AgentEvent`; respuesta por `request_id` y huella del payload completo.

- [ ] Portar pruebas de ausencia de decisión, segunda solicitud, cierre y caducidad.
- [ ] Añadir dos sesiones del mismo agente, payload largo, lectura fragmentada y hooks mezclados.
- [ ] Adaptar relé/configuración conservando handlers ajenos y avisos de licencia.
- [ ] Mostrar decisiones como confirmadas únicamente tras reconocimiento.
- [ ] Probar versiones concretas de Claude Code, Codex y Copilot; anunciar seguimiento/permisos por separado.
- [ ] Verificar instalación, actualización y desinstalación en un perfil de prueba.

### P4-A. Memoria de hechos, planes y decisiones

**Existentes:** memoria procedural y adaptador ai-memory.  
**Crear:** `backend/memory/records.py`, `backend/memory/tests/test_records.py`.  
**Candidato:** `Axx-System/jarvis/memory/record_store.py`.  
**Interfaces:** `propose_record(record: dict) -> dict`; `revise_record(record_id: str, expected_version: int, changes: dict) -> dict`; `forget_record(record_id: str) -> dict`.

- [ ] Escribir `test_expired_plan_never_becomes_completed_fact` y `test_stale_revision_cannot_overwrite_user_correction`.
- [ ] Implementar procedencia, vigencia, ámbitos y revisiones.
- [ ] Vincular ejecución verificada al journal real, separando recetas y recuerdos.
- [ ] Ofrecer ver/corregir/olvidar y limpiar índices derivados.
- [ ] Entregar “retomar”, “encontrar decisión” y preferencias de estilo con evidencia.

### P4-B. Conectores, uno por entrega

**Crear:** `backend/integrations/base.py`, `backend/integrations/credentials.py`, módulos por servicio y sus pruebas. Se usa una carpeta distinta de `backend/connect`, que ya cumple otro papel en Axx.

**Orden sugerido:** correo → calendario → archivos; luego GitHub/mensajes/documentación/diseño; gestores de tareas y CRM según cuentas realmente usadas.

- [ ] Definir consultas, paginación, ámbitos y sincronización de cada conector.
- [ ] Escribir `test_revoked_connector_is_reported_as_unavailable` y `test_pagination_keeps_source_identity`.
- [ ] Implementar lecturas con origen/fecha antes de escrituras.
- [ ] Incorporar preparación y aplicación diferenciadas, con identificación del resultado.
- [ ] Verificar tokens vencidos, duplicados, desconexión y reintento sin repetir efectos.
- [ ] Habilitar las recetas que dependan del conector probado.

Una receta local no necesita todas las aplicaciones conectadas. La cobertura parcial queda visible.

### P4-C. Registro de los 50 flujos

**Crear:** `backend/workflows/registry.py`, `backend/workflows/runner.py`, `backend/workflows/definitions/`, `backend/workflows/tests/test_runner.py`.  
**Interfaz:** `run_workflow(workflow_id: str, inputs: dict, context_id: str | None, operation_id: str) -> dict`.

- [ ] Registrar las 50 entradas del capítulo 5 con dependencias y disponibilidad.
- [ ] Escribir `test_workflow_does_not_repeat_external_effect_after_unknown_result`.
- [ ] Componer lectura, cálculo, generación y acción con herramientas existentes.
- [ ] Generar resultados estructurados, referencias y borradores.
- [ ] Verificar una receta de cada colección y después sus variantes.
- [ ] Separar pruebas de exactitud factual y calidad de redacción.

### P5. Windows y Office

**Existentes:** `backend/actions/desktop.py`, `tools.py`, `executor.py` y `backend/commands.py`.  
**Crear:** `backend/actions/windows_uia.py`, `backend/actions/office.py` y pruebas por operación.

- [ ] Escribir `test_action_fails_when_readback_disagrees`.
- [ ] Implementar una operación UIA concreta con condición posterior.
- [ ] Añadir trabajador Excel con instancia propia, timeout y lectura del resultado.
- [ ] Verificar cancelación y ausencia de procesos Office huérfanos; no cerrar instancias ajenas.
- [ ] Ampliar Word y Outlook por separado; un borrador no envía correo.
- [ ] Evaluar visión local solo para interfaces donde UIA no baste y con un modelo apropiado.

### P6. Móvil

**Propuesta:** cliente y protocolo Axx versionado, adaptando ideas del puente Android auditado.

- [ ] Entregar emparejamiento, estado y chat con revocación por dispositivo.
- [ ] Probar autorización ligada a solicitud vigente y contenido completo.
- [ ] Añadir micrófono remoto como canal de audio independiente.
- [ ] Añadir trackpad/teclado con comandos tipados y límites de frecuencia.
- [ ] Probar suspensión, cambio de red, pérdida de conexión y reconexión.
- [ ] Evaluar iOS como cliente del protocolo Axx; CloudKit de Coucou no resuelve Windows.

## 8. Criterio de entrega por módulo

Una integración se considera terminada cuando:

1. Aparece en el lugar acordado de Axx y puede deshabilitarse.
2. Sus dependencias y permisos tienen estado visible.
3. Recibe entradas reales, produce la salida prevista y acredita sus efectos.
4. Conserva errores, cancelación y estados inciertos.
5. Mantiene los flujos existentes relacionados: invocación, foco, paneles, voz, música y grabación.
6. El paquete instalado contiene el código validado y recursos/licencias necesarios.

Las pruebas deben concentrarse en riesgos concretos. No hace falta repetir toda la validación por una receta de lectura ni probar que un mock devuelve lo que se le programó.

## 9. Recomendación de comienzo

Primer paquete: **Magic Pen sobre selección de texto, con vista previa e inserción verificable**. Aprovecha modelo, UI y herramientas de Axx, aporta valor a escritura y establece el contexto común.

Segundo paquete: **conversión de archivos con formatos explícitos y salida comprobada**. Después contexto/voz, relé de agentes, memoria y conectores; automatización especializada y móvil cuando esa base esté estable.

Este documento entrega análisis y especificación por componentes. No acredita que las nuevas funciones ya estén instaladas ni que los 50 flujos estén disponibles.

## 10. Fuentes de código y documentación

Las referencias de código están fijadas a los commits auditados. Los adjuntos se usan como requisitos y material de referencia, no como prueba de funcionamiento de sus ejemplos.

- **A1.** [AXX: ActionExecutor](https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/backend/actions/executor.py)
- **A2.** [AXX: registro de capacidades](https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/backend/connect/registry.py)
- **A3.** [AXX: memoria procedural](https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/backend/memory/procedural_memory.py)
- **A4.** [AXX: manifiesto](https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/package.json)
- **A5.** [AXX: configuración del host](https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/src-tauri/tauri.conf.json)
- **A6.** [AXX: interfaz Connect](https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/1.AXX/scripts/axx-connect.js)
- **A7.** [AXX: adaptadores de voz](https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/1.AXX/scripts/native-voice.js)
- **A8.** [AXX: estado documentado y grabación](https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/README.md)
- **J1.** [Axx-System: ruta con resultados simulados](https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/jarvis/control/windows_executor.py)
- **J2.** [Axx-System: manifiesto](https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/package.json)
- **J3.** [Axx-System: registros versionados](https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/jarvis/memory/record_store.py)
- **J4.** [Axx-System: lectura UIA](https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/jarvis/screen/uia_context.py)
- **J5.** [Axx-System: contexto espacial](https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/jarvis/operational/interaction_context.py)
- **J6.** [Axx-System: restauración del bundle](https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/scripts/restore-hyperconfig-v4.mjs)
- **C1.** [Coucou: decisiones por agente](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/hook/src/reply.rs)
- **C2.** [Coucou: capacidades y límites Windows](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/README.md)
- **C3.** [Coucou: solicitudes y respuesta](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/pipe.rs)
- **C4.** [Coucou: lectura y reducción del payload](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/hook/src/main.rs)
- **C5.** [Coucou: interacción de aprobaciones](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src/island/island.ts)
- **C6.** [Coucou: vista previa y escritura de configuración](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/config_file.rs)
- **C7.** [Coucou: instalación Claude](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/hooks.rs)
- **C8.** [Coucou: construcción de diffs](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src/core/diff.ts)
- **C9.** [Coucou: Flow Windows/Linux](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/flow/mod.rs)
- **C10.** [Coucou: reconocimiento y modelos](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/speech/mod.rs)
- **C11.** [Coucou: conversación y salida de voz](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/voice/mod.rs)
- **C12.** [Coucou: portapapeles y pegado](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/flow/paste.rs)
- **C13.** [Coucou: contrato WhatsApp](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/NotchBuddy/Sources/App/WhatsAppProvider.swift)
- **C14.** [Coucou: protocolo Android](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/docs/ANDROID_LINK.md)
- **C15.** [Coucou: mensajes Android](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/android/app/src/main/kotlin/com/coucou/android/link/Protocol.kt)
- **C16.** [Coucou: instrucciones desde iPhone](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/NotchBuddy/Sources/Phone/InstructionComposer.swift)
- **C17.** [Coucou: licencia del código](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/LICENSE)
- **C18.** [Coucou: licencia de activos](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/LICENSE-ASSETS.md)
- **C19.** [Coucou: ejecución CI del commit](https://github.com/Louis-CFM/coucou/actions/runs/39450491848)
- **C20.** [Coucou: verificación del usuario del servidor](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/hook/src/win.rs)
- **C21.** [Coucou: registro y arranque](https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/lib.rs)
- **M1.** [Microsoft: UI Automation](https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-uiautomationoverview)
- **M2.** [Microsoft: SendInput y niveles de integridad](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput)
- **M3.** [Microsoft: automatización Office](https://learn.microsoft.com/en-us/office/client-developer/integration/considerations-unattended-automation-office-microsoft-365-for-unattended-rpa)
- **M4.** [Anthropic: contratos de hooks](https://code.claude.com/docs/en/hooks)

[A1]: https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/backend/actions/executor.py
[A2]: https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/backend/connect/registry.py
[A3]: https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/backend/memory/procedural_memory.py
[A4]: https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/package.json
[A5]: https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/src-tauri/tauri.conf.json
[A6]: https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/1.AXX/scripts/axx-connect.js
[A7]: https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/1.AXX/scripts/native-voice.js
[A8]: https://github.com/luigilaxmaster-coder/AXX/blob/3f3a8f0a145fc7876822de2dfe7abb7f06a9f1b6/README.md
[J1]: https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/jarvis/control/windows_executor.py
[J2]: https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/package.json
[J3]: https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/jarvis/memory/record_store.py
[J4]: https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/jarvis/screen/uia_context.py
[J5]: https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/jarvis/operational/interaction_context.py
[J6]: https://github.com/luigilaxmaster-coder/Axx-System/blob/7b0d627cdd5e6e5fe74f198c7f042b06a6155efb/scripts/restore-hyperconfig-v4.mjs
[C1]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/hook/src/reply.rs
[C2]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/README.md
[C3]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/pipe.rs
[C4]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/hook/src/main.rs
[C5]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src/island/island.ts
[C6]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/config_file.rs
[C7]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/hooks.rs
[C8]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src/core/diff.ts
[C9]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/flow/mod.rs
[C10]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/speech/mod.rs
[C11]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/voice/mod.rs
[C12]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/flow/paste.rs
[C13]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/NotchBuddy/Sources/App/WhatsAppProvider.swift
[C14]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/docs/ANDROID_LINK.md
[C15]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/android/app/src/main/kotlin/com/coucou/android/link/Protocol.kt
[C16]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/NotchBuddy/Sources/Phone/InstructionComposer.swift
[C17]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/LICENSE
[C18]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/LICENSE-ASSETS.md
[C19]: https://github.com/Louis-CFM/coucou/actions/runs/39450491848
[C20]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/hook/src/win.rs
[C21]: https://github.com/Louis-CFM/coucou/blob/1e5180921c1326fc72e41d313e3e2855e9c10162/windows/src-tauri/src/lib.rs
[M1]: https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-uiautomationoverview
[M2]: https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput
[M3]: https://learn.microsoft.com/en-us/office/client-developer/integration/considerations-unattended-automation-office-microsoft-365-for-unattended-rpa
[M4]: https://code.claude.com/docs/en/hooks

