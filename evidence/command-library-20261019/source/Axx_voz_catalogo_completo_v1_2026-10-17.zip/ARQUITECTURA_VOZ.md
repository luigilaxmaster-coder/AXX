# Axx · Invocación por voz de la biblioteca completa

## Estado y alcance
Configuración documental y prototipo offline de selección de recetas. No es integración ejecutable en Axx. Corte: lote 23:00 del 17 de octubre de 2026, America/Santo_Domingo. Se reconciliaron 7.494 IDs únicos: 7.286 principales (2.382 revisados documentalmente y 4.904 heredados sin certificación retrospectiva) y 208 suplementos excluidos. Siete versiones históricas no son IDs nuevos. Cero instrucciones nuevas se suman por alias, pruebas o configuraciones.

Todos los IDs tienen mapa y hash del registro vigente. Cada principal admite dos frases plantilla para **preparar o consultar** su receta; esto no acredita pronunciación, reconocimiento, comprensión, compatibilidad de parámetros ni ejecución. Todos conservan `execution_enabled:false`, `DOCUMENTED_NOT_EXECUTED` y pruebas individuales de voz pendientes. Los suplementos están explícitamente deshabilitados. Ningún comando se convierte automáticamente en ejecutable por poseer un alias.

## Pipeline obligatorio de producción pendiente
1. Activación deliberada, preferentemente pulsar para hablar, con indicador visible y alternativa accesible. No abrir micrófono en instalación ni habilitar escucha persistente sin consentimiento.
2. El host confiable entrega audio de una sesión activa con identificador, expiración y origen. La transcripción, una web, un archivo o una respuesta de modelo no pueden fijar esos campos.
3. Reconocedor elegido según disponibilidad, idioma, coste y privacidad consentidos. Este paquete no selecciona ni contrata proveedor, no configura API keys y no transmite audio.
4. Resultado final → normalización Unicode → selección de candidatos por intención/ID → desambiguación → extracción de slots → validación de tipos y límites → verificación del foco y objetos.
5. Resolver receta por ID y hash fijado. Cambio de receta, versión o permisos invalida el plan pendiente. No ejecutar texto de transcripción, snippets copiados ni interpolación de shell.
6. Crear propuesta visible con objetivo, aplicación, archivos, destinos y efectos. La confianza acústica nunca reemplaza permisos ni autenticación.
7. Aplicar política de autorización por acción, destinatario, dato y riesgo. Registrar una decisión verificable ligada al hash del plan, slots, sesión, expiración y paso. No heredar permisos de otro paso ni de una confirmación anterior para otro recurso.
8. Adaptador de Axx implementado y probado realiza una acción; observador independiente comprueba postcondición. Solo entonces avanzar. Error, timeout o resultado incierto detienen dependientes.
9. Respuesta hablada breve basada en evidencia: realizado, parcial, falló, requiere confirmación o no verificado. No anunciar éxito por emitir comandos, animar el personaje o recibir un HTTP 200 intermedio.

## Compatibilidad de TODOS los comandos
El inventario es exhaustivo por identidad, pero el contrato de ejecución aún requiere adaptación individual. Se preservan `inputs`, `parameters` y `link_contract` originales dentro de cada mapa. `slots:[]` significa **pendiente de tipar**, nunca ausencia de parámetros ni permiso para ejecutar sin ellos. No convertir prosa de requisitos automáticamente en valores por defecto.

Por cada ID, el integrador debe asignar: adaptador/API/UIA exacto, versiones reales de aplicación/OS, precondiciones, slots y validadores, foco requerido, permisos, resultado observable, recuperación y prueba de aceptación con evidencia. Si falta alguno, estado pendiente y ejecución bloqueada. Para recetas que requieren ratón, selección visual o interacción física, la voz puede iniciar el flujo y pedir selección asistida; no garantiza ejecución autónoma de cada paso. Acciones que exigen intervención personal deben mantenerse como handoff aunque se inicien por voz.

Estados separados: `MAPPED_TEMPLATE_PENDING_REVIEW` → `INTENT_REVIEWED` → `ADAPTER_IMPLEMENTED` → `VOICE_E2E_VERIFIED` → `ENABLED_WITH_POLICY`. Los estados intermedios futuros son especificaciones; esta entrega no los asigna a las 7.286 principales. Suplementos: `DISABLED_EXCLUDED`.

## Slots y diálogos
Tipos recomendados: `ApprovedLocalPath`, `ExistingFile`, `NewDestination`, `ApplicationInstance`, `DocumentSelection`, `IntegerBounded`, `Duration`, `Enum`, `LanguageTag`, `VerifiedRecipient`, `LocalRepo`, `HexPrefix`, `GitObjectId`, `LocalPDF`. No deducir tipos sólo por nombres. Mantener unidades y límites explícitos, distinguir uno/once, quince/cincuenta, nombres parecidos, negación y correcciones. Rutas largas se eligen con selector accesible o alias local aprobado; deletreo siempre con readback. Evitar dictar secretos.

Ejemplo: «Axx, prepara rastrear la introducción de un blob conocido aunque cambie de nombre» selecciona la receta existente. Falta repositorio y OID; preguntar por ambos, mostrar sus valores y validar localmente. «Ese» o «aquí» exige selección/foco observado reciente y único; no adivinar. Una negación como «no lo borres» no puede mapear por palabra clave a borrar.

Baja confianza: pedir repetición o selección visual. Ambigüedad: mostrar hasta tres candidatos con aplicación y efecto; conservar la intención sin ejecutar. Ausencia de confianza calibrada: no inventar porcentaje. N-best y confianza dependen del motor y no prueban identidad ni probabilidad absoluta. La comparación de umbrales entre motores no es válida sin calibración propia.

## Riesgo, permisos y readback
Lectura local de alcance ya autorizado puede preparar una propuesta con verificación de contexto. Escritura reversible requiere comprobar autorización y destino; cambios irreversibles, publicación, envío, compras, credenciales o seguridad tienen barreras específicas y confirmación/handoff según política aplicable. El motor debe poder elevar protección, nunca reducirla por voz.

Readback mínimo antes de efectos relevantes: acción, objeto, destino, cantidad/unidad cuando aplique y consecuencia. La confirmación debe referirse a ese resumen exacto y caducar si cambia. Un «sí» fuera de una solicitud pendiente no autoriza nada. Voz ambiental, altavoces, audio de vídeo y voces sintetizadas no son autenticación. Ni un wake word ni diarización garantizan que habla el propietario. Para consecuencias altas usar confirmación visual accesible o mecanismo fuerte en la sesión autenticada; no confiar sólo en transcripción.

Rechazar entrada conocida como reproducción; silenciar entrada durante TTS propio o manejar eco validado. Esto reduce fallos, no promete detectar toda reproducción o suplantación. Las señales `origin`, `armed` y `playback_active` del prototipo son fixtures: la integración real debe producirlas y protegerlas.

## Control de flujos enlazados
«Pausa» solicita detener nuevos pasos en el siguiente punto seguro. «Cancela» corta dependientes y solicita cancelar operaciones que lo soporten; no revierte acciones consumadas. Mostrar qué continúa, qué se detuvo y qué efecto ya ocurrió. «Reanuda» vuelve a verificar sesión, permisos, hashes, foco y postcondiciones; no reenvía una operación incierta. «Deshaz» es un plan separado de compensación si existe y es seguro. Envíos, publicaciones o cambios externos pueden carecer de reversión.

La prioridad de parada debe implementarse fuera de la cola ordinaria y con botón/Esc accesible. El prototipo no controla procesos y devuelve sólo `REQUEST_STOP`; su comprobación de sesión se mantiene conservadora. Diseñar el botón/Esc de emergencia para funcionar incluso cuando falla ASR o foco.

Los ejemplos de flujos incluyen dos pipelines existentes del paquete de enlaces: Git (prefijo→OID→historial) y Zotero (importar anotaciones→exportar copia). No ejecutar el segundo paso si el primero no produce resultado verificado, ni reutilizar autorización para nuevos archivos. Las invocaciones de voz son propuestas, con parámetros de fixture, no acciones nuevas.

## Privacidad y accesibilidad
Audio sin retención por defecto; logs guardan IDs, estado y razones, no transcripción completa, rutas personales ni contenido del documento salvo necesidad y consentimiento. Si se usa nube, informar proveedor, datos y finalidad antes de transmitir; ofrecer alternativa local si disponible, sin fingir que está instalada. Evitar leer secretos o mensajes privados por altavoz; permitir respuesta textual. Indicadores de escucha/procesamiento/error legibles, teclado, lector de pantalla, texto editable, repetir y cancelar. No depender de color, sonido o precisión verbal perfecta.

## Validación para habilitar en Axx
Probar por receta: variaciones de frase, acentos, ruido, negación, homófonos, slots ausentes, foco cambiado, permisos denegados, destinatarios ambiguos, cancelación, timeout, resultado incierto y reconexión. Medir éxito de tarea con evidencia, falsos positivos y acciones no autorizadas; no sólo error de transcripción. Mantener fixtures y casos adversarios separados de entradas útiles. No habilitar por tasa agregada si una receta sensible falla.

Las pruebas incluidas ejecutan únicamente funciones puras con texto/fixtures, sin micrófono, ASR, UI, red, shell ni adaptadores. Por ello no acreditan seguridad acústica ni compatibilidad real de Windows/Axx. La importación de este JSONL por la aplicación y cualquier migración productiva requieren trabajo posterior.

## Migración reproducible y reversión
`python build_voice.py RAIZ_BIBLIOTECA SALIDA_NUEVA` reconstruye la instantánea desde el corpus consolidado de lote23, sus registros nuevos y los índices revisados. Exige conteos de este corte; falla si cambian para evitar una cobertura falsa. Para nuevos lotes, preparar una revisión del migrador con manifiesto y conteos nuevos, nunca eludir assertions. Conservar mapas anteriores, comparar IDs/hash, invalidar binding si cambió receta y revisar nuevo contrato. No reemplazar automáticamente reglas aprobadas de voz por plantillas. El prototipo no modifica la biblioteca fuente.

Rollback documental: conservar versión anterior del mapa y seleccionar su manifest. En producción, volver a un mapa previo exige que los hashes de recetas y adaptadores coincidan; de lo contrario deshabilitar. No restaura efectos externos ya realizados.

## Fuentes consultadas el 18-10-2026 UTC
- Microsoft RecognizedPhrase.Confidence: https://learn.microsoft.com/en-us/dotnet/api/system.speech.recognition.recognizedphrase.confidence?view=netframework-4.8.1 (confianza relativa y dependiente del motor).
- Microsoft SpeechRecognitionResult.Confidence: https://learn.microsoft.com/en-us/uwp/api/windows.media.speechrecognition.speechrecognitionresult.confidence (alternativas ordenadas por confianza).
- W3C Semantic Interpretation for Speech Recognition: https://www.w3.org/TR/semantic-interpretation/ (separación entre resultados de reconocimiento y representación semántica).
- Catálogo existente y paquete de enlaces: https://drive.google.com/drive/folders/1l4iQhN_LKV9tOuX0XNEyrQgmc-xi7ukV .
Las políticas y estados de Axx en este documento son diseño propuesto; las referencias no demuestran que estén implementados. No se afirma soporte actual de un proveedor concreto.

## Archivos para el integrador
- `voice_map.jsonl`: 7.494 registros; contratos de parámetros preservados; todas las invocaciones sin activar.
- `source_inventory.jsonl`: ID, título y hash del registro fuente, para comprobar cobertura sin duplicar recetas.
- `voice_intent.schema.json`: contrato JSON Schema 2020-12 del sobre documental. Su existencia no valida las reglas semánticas ni ejecuta un adaptador.
- `typed_slot_examples.json`: cuatro propuestas de slots para los IDs ya usados en los dos flujos enlazados. No se promueven a compatibles ni sustituyen el estado pendiente de su mapa.
- `voice_workflows.json`: conserva dependencias, hashes y barreras de los dos flujos anteriores, añadiendo frases de preparación.
- `voice_policy.json`: configuración de denegación de ejecución por defecto.
- `voice_router.py`: selector puro de propuestas con coincidencia exacta; no reconoce habla ni ejecuta comandos. Frases naturales distintas aún requieren revisión, nunca fallback a shell.
- `build_voice.py`: reconstrucción determinista del corte usando catálogo local ya existente. No instala, actualiza ni modifica Axx.
- `test_voice.py` y `TEST_RESULTS.txt`: pruebas offline de estructura y puertas lógicas, sin pruebas acústicas.

Límite del router: las frases de `voice_workflows.json` no están conectadas a la función `propose`; son especificaciones de invocación que necesitan adaptador de flujo y pruebas. No confundir los ejemplos JSON con flujos que ya se puedan lanzar hablando. El migrador usa errores explícitos de conteo y pertenencia, que siguen activos con Python optimizado.
