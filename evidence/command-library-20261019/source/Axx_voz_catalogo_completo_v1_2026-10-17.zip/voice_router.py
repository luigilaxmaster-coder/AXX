"""Pure proposal router. No audio capture, adapters, network, shell or execution."""
import unicodedata

def normalize(s):
 return ' '.join(unicodedata.normalize('NFKC',s).casefold().split())
def propose(text, records, session):
 # session is a synthetic fixture here. Production must obtain these signals from a trusted host.
 if not session.get('armed') or session.get('origin')!='explicit_user_session':return {'state':'IGNORED','execution_enabled':False}
 if session.get('playback_active') or not session.get('final_result'):return {'state':'IGNORED','execution_enabled':False}
 if not session.get('recognizer_calibrated') or not session.get('confidence_accepted'):return {'state':'ASK_REPEAT','execution_enabled':False}
 if not session.get('focus_verified'):return {'state':'ASK_CONTEXT','execution_enabled':False}
 n=normalize(text)
 if n in ['axx cancela','axx, cancela','axx pausa','axx, pausa']:
  return {'state':'REQUEST_STOP','execution_enabled':False,'effects_reverted':False}
 found=[r for r in records if n in [normalize(p) for p in r['voice_intent']['phrases']]]
 if not found:return {'state':'NO_MATCH','execution_enabled':False}
 if len(found)!=1:return {'state':'ASK_DISAMBIGUATION','candidates':[x['recipe_id'] for x in found],'execution_enabled':False}
 r=found[0]
 if r['catalog_group']=='SUPLEMENTO_EXCLUIDO':return {'state':'BLOCKED_EXCLUDED','execution_enabled':False}
 return {'state':'PROPOSAL_REQUIRES_REVIEW','recipe_id':r['recipe_id'],'source_sha256':r['source_sha256'],'execution_enabled':False,'authorization_granted':False,'missing_slots_review':True}
