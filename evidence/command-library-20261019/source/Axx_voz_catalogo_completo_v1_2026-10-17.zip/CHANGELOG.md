# Cambios de voz v1

Nueva capa de configuración documental, sin modificar las recetas originales ni Axx.

- Se incorpora inventario completo por ID y hash, separado entre principales revisados, heredados y suplementos excluidos.
- Se generan dos plantillas de preparación/consulta por ID; no suman instrucciones.
- Se preservan contratos originales de parámetros y permisos, con adaptación individual pendiente.
- Se añaden esquema del sobre, política de denegación por defecto y router puro sin ejecutor.
- Se documentan controles de contexto, ambigüedad, baja confianza, efectos, autorización, cancelación y privacidad.
- Se vinculan dos flujos existentes y cuatro ejemplos de slots tipados propuestos.
- Se comprueban 14.988 frases mediante fixtures de texto en un test exhaustivo. No son 14.988 pruebas de voz ni nuevas habilidades.
- Se valida estructura de 7.494 registros contra JSON Schema. No implica validación semántica de requisitos.

No existe una versión anterior de esta capa que haya activado ejecución. La reversión consiste en conservar o retirar esta configuración documental; no se realizaron cambios al sistema del usuario.

Corrección posterior a revisión independiente: el migrador cambia assertions por errores explícitos y comprueba pertenencia y disyunción de grupos; reconstrucción con `python -O` conserva el mapa idéntico. Se explicita que las frases de flujos no son procesadas por el router de recetas. Los conteos históricos siguen fijados a este corte y requieren reconciliación futura.
