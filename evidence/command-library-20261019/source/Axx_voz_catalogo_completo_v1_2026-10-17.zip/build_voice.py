"""Offline, deterministic catalog migration. Never executes recipes or opens microphone."""
import json,hashlib,pathlib,collections,sys

def rows(p): return [json.loads(s) for s in pathlib.Path(p).read_text().splitlines() if s.strip()]
def canonical(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def build(root,out):
 root=pathlib.Path(root);out=pathlib.Path(out);out.mkdir(exist_ok=True,parents=True)
 prior=rows(root/'2026-10-17_2300/review/prior_corpus.jsonl')
 for name in ['python','sqlite','SUPLEMENTOS_NO_CONTADOS']:
  p=root/'2026-10-17_2300/revised'/f'{name}.jsonl'
  if p.exists():prior+=rows(p)
 by={x['id']:x for x in prior}
 if len(by)!=len(prior) or len(by)!=7494:raise ValueError('Unexpected cut or duplicate IDs')
 legacy={x['id'] for x in rows(root/'base/catalogo_axx_normalizado.jsonl')}
 main=set()
 for p in sorted(root.glob('2026*/revised/INDICE.jsonl')):
  if p.parent.parent.name<='2026-10-17_2300':main.update(x['id'] for x in rows(p))
 for name in ['windows','development','diagnostics','orchestration','productivity']:
  main.update(x['id'] for x in rows(root/'2026-10-16_1000/revised'/f'{name}.jsonl'))
 if len(legacy)!=4904 or len(main)!=2382:raise ValueError('Unexpected principal group counts')
 if legacy & main or not (legacy|main)<=set(by):raise ValueError('Overlapping or missing principal IDs')
 if len(set(by)-(legacy|main))!=208:raise ValueError('Unexpected supplement membership count')
 maps=[]
 for id,x in sorted(by.items()):
  group='HEREDADO_SIN_CERTIFICAR' if id in legacy else 'PRINCIPAL_REVISADO' if id in main else 'SUPLEMENTO_EXCLUIDO'
  title=x.get('title',''); params={k:x[k] for k in ['inputs','parameters','link_contract'] if k in x}
  m={'schema_version':'1.0','recipe_id':id,'source_sha256':hashlib.sha256(canonical(x).encode()).hexdigest(),'title':title,'catalog_group':group,'source_status':x.get('status'),'source_review_status':x.get('review_status'),'voice_intent':{'intent_id':'voice.'+id,'locale':'es-DO','phrases':['Axx, prepara '+title,'Axx, muéstrame cómo '+title],'aliases_reviewed':False,'slots':[], 'slot_mapping_status':'PENDING_MANUAL_TYPE_AND_SCOPE_REVIEW','source_parameter_contract':params,'missing_parameter_question':'¿Sobre qué recurso y con qué valores quieres preparar esta acción? Revisar requisitos de la receta antes de formular preguntas específicas.'},'coverage_status':'DISABLED_EXCLUDED' if group=='SUPLEMENTO_EXCLUIDO' else 'MAPPED_TEMPLATE_PENDING_REVIEW','execution_enabled':False,'status':'DOCUMENTED_NOT_EXECUTED','voice_runtime_verified':False,'authorization':'TRANSCRIPT_IS_NOT_AUTHORIZATION','policy_ref':'voice_policy.json','source_permissions':{k:x[k] for k in ['permission','permissions','permission_risk'] if k in x},'blockers':['No adapter validated in Axx','No individual speech/alias test','Slots and environment compatibility pending'],'counted_as_new_instruction':False}
  maps.append(m)
 (out/'voice_map.jsonl').write_text(''.join(canonical(x)+'\n' for x in maps))
 # retain minimal source evidence sufficient to reconcile identity and content hashes; full recipes remain original library
 (out/'source_inventory.jsonl').write_text(''.join(canonical({'id':x['id'],'title':x.get('title'),'sha256':hashlib.sha256(canonical(x).encode()).hexdigest()})+'\n'for x in sorted(prior,key=lambda x:x['id'])))
 counts=dict(collections.Counter(x['catalog_group'] for x in maps))
 (out/'coverage.json').write_text(json.dumps({'cutoff_batch':'2026-10-17_2300','unique_ids':len(maps),'groups':counts,'main_nominal':len(main|legacy),'reviewed_main':len(main),'legacy_uncertified':len(legacy),'historical_revisions_not_new_ids':7,'source_versions_total':7501,'voice_tested_individually':0,'execution_enabled_count':0,'new_instructions_added':0,'typed_slot_templates_pending':len(maps),'migration':'build_voice.py','missing_ids':sorted((main|legacy)-set(by))},indent=2))
 return maps
if __name__=='__main__':build(sys.argv[1],sys.argv[2])
