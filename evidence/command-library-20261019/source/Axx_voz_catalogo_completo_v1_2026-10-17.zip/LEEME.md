# Axx · Voz para todos los IDs del catálogo

Mapa documental completo al corte del lote 23:00 del 17-10-2026 (America/Santo_Domingo). No activa la voz en Axx ni habilita ejecución.

- 7.286 instrucciones principales con invocaciones plantilla: 2.382 revisadas y 4.904 heredadas aún sin certificación retrospectiva.
- 208 suplementos presentes, expresamente bloqueados.
- 7.494 IDs únicos cubiertos; 7 revisiones históricas se conservan en la biblioteca original y no suman IDs.
- Cero instrucciones nuevas contabilizadas. Cero pruebas acústicas, adaptadores implementados o comandos ejecutados en el equipo.

Lee ARQUITECTURA_VOZ.md. El mapa permite preparar o consultar una receta existente. Cada ID necesita completar su adaptación de parámetros, permisos y herramientas antes de habilitarlo. Los cuatro ejemplos tipados son propuestas, no prueba de compatibilidad del resto.

Para comprobar el paquete en un entorno de desarrollo con Python ya disponible: `python -m unittest test_voice -v`. Sólo prueba lógica sobre fixtures de texto y archivos de este paquete; no controla el PC.

La reconstrucción requiere el catálogo original y los índices del corte exacto: `python build_voice.py RAIZ_BIBLIOTECA CARPETA_NUEVA`. La herramienta rechaza una biblioteca con conteos distintos; una ampliación requiere nuevo manifiesto y revisión. Conservar versiones anteriores.

El destino mantiene los permisos existentes de Drive. Los hashes verifican una instantánea; no hacen inmutable la carpeta ni protegen contra cambios de terceros. No almacenar aquí datos personales o credenciales.
