# Independent review: Axx documentary voice mapping v1

Reviewed 2026-10-18 UTC. Scope: files in this package, against the original hourly catalog through batch `2026-10-17_2300`. Offline inspection, reconstruction and pure-function tests only. No recipe, microphone, ASR provider, network request, application adapter or user workflow was executed.

## Verdict

PASS for an exhaustive, disabled documentary mapping and proposal-router prototype. NOT evidence that all commands are voice-compatible in the running Axx application. No blocking defect was found within the stated documentary scope. Production voice integration remains unimplemented and explicitly disclosed.

## Independent source reconciliation

Reconstructed the current catalog without relying on `source_inventory.jsonl` or the builder's consolidated `prior_corpus.jsonl`: started from `base/catalogo_axx_normalizado.jsonl`, then applied actual chronological revised recipe files, including `CORRECCIONES_BASE.jsonl` and supplements, excluding summary indexes.

- 7,501 source record versions; 7,494 distinct current IDs.
- Seven historical replacements, all in the base correction file: AXX-03-0890 and AXX-03-0964 through AXX-03-0969.
- Independently grouped source IDs: 4,904 legacy, 2,382 reviewed principal, 208 excluded supplements. Groups are pairwise disjoint; principals total 7,286.
- Every mapping has the correct group. Missing IDs: 0. Extra IDs: 0. Duplicate mapped IDs: 0.
- Recomputed canonical source-record SHA-256 for every current recipe: 0 mismatches against the complete voice map.
- Every preserved `inputs`, `parameters` and `link_contract` field matches the actual current recipe exactly. Every preserved `permission`, `permissions` and `permission_risk` field also matches.
- All four recipe/hash bindings in the two documentary voice workflows match the actual source records.
- 14,988 phrase templates; 14,988 distinct strings after router normalization. No current exact normalized collisions. This does not establish acoustic distinctness or natural-language coverage.

## Reproducibility and tests

Ran `python -m unittest -v test_voice.py`: all 18 tests passed. Inspected the code before running; these are offline proposal-router tests and map consistency checks, not recipe execution.

Ran the builder against the source root into a separate temporary directory. All three generated files were byte-identical to the delivered files:

- voice_map.jsonl: SHA-256 `8982ba9489412e67bb159be8feb938ef7a690447e6e129205f75c649b99f21e0`
- source_inventory.jsonl: SHA-256 `95a28def617922a5faeefb70ba59cd876a0011ef8cdd21b5d07df7e2c30a721a`
- coverage.json: SHA-256 `e7d485652825fc9141002c3d4bcbd50326f089429a4f00d94fce6214953e42f4`

## Safety and claim accuracy

Every row has execution disabled, runtime voice verification false, aliases unreviewed and status DOCUMENTED_NOT_EXECUTED. Every empty slots array is paired with an explicit pending manual type/scope-review status; documentation correctly says this means unresolved slots, not a parameter-free action. Supplements remain excluded.

The router never executes anything or grants authorization. It requires synthetic armed/origin/final/confidence/focus signals, ignores known playback, requests disambiguation, blocks excluded records and returns review-required proposals. Documentation clearly distinguishes those fixtures from trustworthy production signals. It also correctly says a stop request is not undo and acknowledges that emergency stop must eventually work outside the ordinary recognition/focus checks.

The architecture discloses missing adapters, missing per-command speech tests, unresolved slots, environment verification, policy enforcement, no microphone access and no running-app integration. There is no false assertion that passing these tests verifies operational voice compatibility. External reference links were not fetched in this offline review; their currency/content was not independently validated here.

## Non-blocking limitations and hardening recommendations

1. The supplied inventory-hash test compares two generated outputs. It does not independently detect a stale or incorrectly consolidated source snapshot. This review closes that gap for this exact cut; preserve an automated independent source reconciliation test for later versions.
2. The builder uses Python assertions for fixed-cut validation, and does not explicitly assert disjoint source groups, exact membership or zero missing IDs. Assertions disappear under `python -O`. Replace them with explicit errors and validate the exact source sets before treating this as a durable migration tool. Current-cut source sets were independently verified and are correct.
3. The seven historical revisions and 7,501 source versions are hard-coded metadata. They are correct for this cut, independently verified, but should be derived or reconciled against an explicit source manifest for future cuts.
4. The router assumes well-formed trusted record/session structures and has no typed-slot extraction, recipe resolution/hash revalidation, authorization engine, expiry, adapter or postcondition executor. These are disclosed production gaps, not implemented protections. Never connect its returned proposal directly to an executor.
5. The two documentary workflow invocation phrases are not routed by `voice_router.propose`, which searches recipe records only. This matches their proposed/documentary status but needs implementation and testing if workflows later become runnable by voice.
6. Eighteen unit tests and zero exact phrase collisions do not certify 7,494 spoken commands. Actual per-command recognition, slot, risk, focus, cancellation and end-to-end evidence remain required.

Recommended delivery wording: “All 7,494 catalog IDs are mapped for a future voice interface; 7,286 principals have preparation/consultation phrase templates, and 208 supplements remain disabled. Execution and individual voice compatibility are not enabled or verified.”

## Added schema, examples and delivery notes

Reviewed the final additions `voice_intent.schema.json`, `typed_slot_examples.json`, `LEEME.md`, `FUENTES_Y_REVISION.md` and the architecture file list. Draft 2020-12 schema validation passed for all 7,494 map records; all ten proposed slots across the four examples validate against the slot definition. Each example's recipe/hash binding matches the previously independently verified source. All examples retain execution disabled and a proposed, adapter-test-required status. The schema validates a documentary envelope only; it deliberately does not prove semantic safety, cross-field policy consistency or enforce runtime authorization. The validation descriptions are prose, not implemented validators. The added delivery notes accurately maintain the scope distinction and disclose source access limitations.

Stop-control caveat explicitly reviewed: the prototype evaluates session, playback, confidence and focus gates before recognizing stop. Thus it cannot be an emergency-stop implementation. The architecture correctly requires a separate priority stop/button/Esc mechanism for production. This is acceptable only while it remains a non-executing proposal fixture.

Final test update: independently reran the expanded 18-test suite successfully. The new test visits all 14,988 phrase templates through isolated single-record routing; every principal produces a review-required proposal and every supplement is blocked. This is text-only coverage and does not test speech or whole-catalog ambiguity; normalized whole-catalog uniqueness was checked separately above.

## Independent verification addendum: final hardening delta

Inspected the revised `build_voice.py`. Recommendation 2 above is addressed for the fixed-cut integrity gates: validation now uses explicit `ValueError` checks for unique ID/count consistency, principal group counts, group overlap, missing principal IDs and the excluded remainder count. These checks remain active under optimized Python. Independently rebuilt with `python -O`; `voice_map.jsonl`, `source_inventory.jsonl` and `coverage.json` remain byte-identical to the reviewed artifacts. Also ran three in-memory negative source fixtures under `python -O`: duplicate ID, missing principal ID and overlapping groups were each rejected with the expected explicit error. Original catalog files were not changed. The supplement check verifies remainder count; independent exact supplement membership for this cut is established by the source reconciliation above.

Independently reran all 18 offline unit tests after this delta: PASS. The architecture now explicitly states that documentary workflow phrases are not connected to `propose`, and that a workflow adapter and tests remain necessary. The overall documentary-scope PASS remains unchanged; this delta does not implement voice recognition, runtime authorization, emergency stopping or Axx execution.
