# Fuentes y revisión documental
Fecha: 18-10-2026 UTC, 17-10-2026 America/Santo_Domingo.

1. Exactitud y cobertura: reconstrucción de 7.494 IDs a partir del corpus de lote23 y sus 12 registros finales, clasificación por índices de principales y base. Hash canónico JSON por registro. Se preserva prosa de parámetros, sin fingir tipos inferidos como contratos ejecutables. Los títulos se convierten mecánicamente en plantillas de preparación/consulta.
2. Seguridad: ejecución bloqueada en todas las filas y en todas las respuestas del router. Origen, foco, confianza y resultado final son condiciones de propuesta; no una autenticación. Confirmación y handoff según consecuencia, no herencia de permisos. Cancelar no implica deshacer. Se verificó que el mapa no contiene cadenas de usuario nominal ni correos personales conocidos; esto es una comprobación limitada, no un detector universal de secretos.
3. Utilidad: ID/hash y parámetros preservados permiten enlazar la intención al contrato original. Se incluyen cuatro ejemplos tipados para dos flujos existentes. Las 7.494 adaptaciones individuales continúan pendientes; reconocimiento de sinónimos, faltantes y ASR requieren integración. Se ejecutaron tests del selector puro con fixtures, no recetas.
4. Revisión independiente: ver REVISION_INDEPENDIENTE.md, con reconstrucción separada, análisis de límites y pruebas reportadas. No atribuir a los tests de texto validación de habla real.

Fuentes oficiales:
- https://learn.microsoft.com/en-us/dotnet/api/system.speech.recognition.recognizedphrase.confidence?view=netframework-4.8.1 : apertura directa inglesa falló en el navegador de investigación; se consultó resultado indexado de documentación oficial localizada Microsoft sobre confianza relativa, alternativas y dependencia del motor. No se verificó soporte del runtime de usuario.
- https://learn.microsoft.com/fr-fr/%20dotnet/api/system.speech.recognition.recognizedphrase.confidence?view=netframework-4.8.1 : URL oficial localizada devuelta por buscador; extracto utilizado, sin copiar extensamente.
- https://learn.microsoft.com/en-us/uwp/api/windows.media.speechrecognition.speechrecognitionresult.confidence?view=winrt-28000 : resultado oficial indexado sobre alternativas ordenadas y confianza; vista incluye advertencia de prerelease, no se recomienda como versión desplegada.
- https://www.w3.org/TR/semantic-interpretation/ : abierto directamente; recomendación histórica 2007 sobre interpretación semántica, consultada ahora. Se usa para separar transcripción de intención, no para afirmar implementación actual.

No se eligió proveedor ASR ni se afirma que funcione gratis, localmente o sin red en el equipo. La selección y las condiciones de privacidad son decisiones de integración posteriores.
