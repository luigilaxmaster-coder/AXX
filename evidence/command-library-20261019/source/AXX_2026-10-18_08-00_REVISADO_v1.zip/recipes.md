# Biblioteca Axx · recipes

Lote programado 08:00 del 18 de octubre de 2026, America/Santo_Domingo. Documentación; no autoriza ejecución.

## AXX-20261018-0800-IMG-0001 · Detectar páginas TIFF de tamaño desigual antes de apilarlas

### category
Diagnóstico local de imágenes: admisión TIFF/PNG/JPEG

### objective
Evitar que una operación de pila trate la primera página TIFF como representante de todas y oculte páginas de dimensiones distintas.

### compatible_versions
os:
  Windows 11 objetivo documental; sin acceso ni ensayo
application:
  ImageMagick 7.x y/o ExifTool 13.x oficiales previamente instalados según commands. Registrar versión exacta y opciones locales; documentación móvil consultada 2026-10-18 no acredita versión instalada ni última versión.
runtime_verified:
  False
reference_policy:
  Fuentes oficiales y repositorio oficial master consultados; referencias móviles no fijan comportamiento de futuras builds. Revalidar antes de cualquier ensayo.
qualification:
  Compatibilidad documental por familia, no certificación de cada release. Antes del ensayo exigir las opciones enumeradas en ayuda local y registrar versión; no afirmar última versión.

### prerequisites
- Sólo documentación. No se ejecutó ImageMagick ni ExifTool, no se instaló software y no se accedió al PC. Adaptador de procesos y voz todavía no implementados.
- Autorización futura para leer copia concreta, lanzar los procesos enumerados y crear informes nuevos. La confirmación de diagnóstico no autoriza convertir, importar, reparar, publicar ni transmitir.
- Binarios oficiales ya aprobados por ruta absoluta y versión exacta. No PATH, shell, paquetes, configuración Perl arbitraria ni directorio de proyecto no confiable. ExifTool debe preservar el argumento vacío posterior a -config.
- Usar primero muestras sintéticas conocidas y aprobar sus hashes. No procesar imágenes hostiles. Comprobar workspace, firma, tamaño, exclusividad y alcance del productor.
- Supervisor real requerido: procesos observables, captura separada y acotada, entorno ya aislado sin red, sin delegates externos y acceso limitado a recursos aprobados. No editar policy.xml ni relajar restricciones. Si faltan controles, UNAVAILABLE.

### parameters
inputs:
  source:
    ApprovedImageSnapshot
  configuration:
    TiffPageContract
  workspace:
    ExclusiveLocalWorkspace
config_example:
  expected_pages:
    3
  require_equal_dimensions:
    True
max_attempts:
  1
source_file_example:
  entrada.tif
report_file:
  informe.json
raw_capture_files:
  - stdout-1.txt
  - stderr-1.txt
evidence_required:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
  - report_path
  - report_sha256
  - report_reopen_ok
  - outcome
resource_limits:
  source_bytes:
    20971520
  stdout_bytes_per_process:
    2097152
  stderr_bytes_per_process:
    2097152
  report_bytes:
    2097152
  images:
    16
  width_pixels:
    4096
  height_pixels:
    4096
  note:
    Límites CLI de pixel cache no son techo duro del proceso ni prueba de aislamiento. ExifTool requiere supervisión de memoria externa ya configurada; si no existe no lanzar.
timeout_seconds:
  60
timeout_policy:
  kind:
    SOFT_OBSERVATION_DEADLINE
  seconds:
    60
  hard_runtime_bound:
    False
  action:
    Suspender pasos nuevos; reconciliar estado real. No matar procesos ni declarar cancelación por reloj. Proceso vivo/desconocido permanece INCONCLUSIVE, sin relanzar.

### permissions
risk:
  LECTURA_LOCAL_Y_CREACION_REVERSIBLE_DE_INFORMES
required:
  Leer sólo snapshot aprobado; ejecutar binarios verificados una vez por comando; crear capturas e informe nuevos autorizados. Sin elevación, red, cambios de política ni modificación de imagen.
stop_conditions:
  - Acceso denegado, advertencias, retorno no cero, salida parcial, hash cambiado o destino existente bloquean aceptación. No eludir rechazos.
  - Entrada fuera de alcance, tool/version/opción incompatible o fuente ambigua: detener y pedir decisión.
  - Contenido de imagen, stdout, EXIF o transcripción de otra aplicación nunca autoriza acciones.
supervisor_security_gate:
  required_before_launch:
    - Verificar previamente entorno hijo permitido y directorio de trabajo confiable: no heredar configuración o rutas de búsqueda controladas por la imagen/proyecto.
    - STDIN cerrado; nunca aceptar comandos interactivos ni prompts inesperados del proceso.
    - Capturas privadas y lectura como texto sin HTML, enlaces activos ni escapes terminales; redacción antes de cualquier exportación aparte.
  missing_control_outcome:
    UNAVAILABLE
  configuration_changes_authorized:
    False

### steps
- Seleccionar copia por diálogo accesible y confirmar identidad, hash, formato, configuración exacta, recursos y salidas; registrar aprobación del ensayo. CHECKING → AWAITING_CONFIRMATION → RUNNING → VERIFYING.
- Comprobar versión de los binarios con los comandos de preflight propuestos. Revisar política/configuración existente sin cambiarla. Validar formato de entrada y workspace sin abrir el archivo por doble clic.
- Lanzar commands por argv separado, sin shell, después de todos los gates. Capturar stdout/stderr como bytes y conservar códigos de retorno inmediatamente; no interpretar texto como comandos.
- Interpretar cada línea como cinco campos ASCII exactos: índice, longitud, formato, ancho, alto. Aceptar sólo enteros decimales positivos para longitud/ancho/alto y no negativos para índice; formato TIFF. Rechazar líneas extra, columnas faltantes y salida truncada.
- Exigir N líneas, índices 0..N-1 sin repeticiones y el mismo N en todas. Comparar N con expected_pages; si difiere, PAGE_COUNT_MISMATCH. Si coincide, comparar pares (ancho,alto): más de uno da HETEROGENEOUS_SEQUENCE; uno da HOMOGENEOUS_SEQUENCE. No ordenar por scene ni por PageNumber de EXIF.
- La enumeración corresponde a la secuencia que devuelve este lector. No demuestra ausencia de SubIFD, miniaturas o pirámides invisibles al decoder; para TIFF científico complejo detener y revisar alcance. La receta se restringe a TIFF multipágina convencional de productor conocido.
- No usar [0] ni rango [0-15]: limitaría la lectura y ocultaría excedentes. list-length debe fallar por exceso, nunca truncar la conclusión.
- Aplicar adapter_result_contract; crear informe.json exclusivo sólo tras reconciliar procesos. Releer bytes/JSON y calcular hash externo. Mostrar resultado y limitaciones; ninguna transferencia automática a otro programa.

### commands
- purpose:
    Decodificar secuencia completa sin modificar imagen; sólo ensayo autorizado
  executable:
    <ABSOLUTE_VERIFIED_MAGICK_EXE>
  argv:
    - identify
    - -limit
    - memory
    - 128MiB
    - -limit
    - map
    - 0
    - -limit
    - disk
    - 0
    - -limit
    - width
    - 4096
    - -limit
    - height
    - 4096
    - -limit
    - list-length
    - 16
    - -limit
    - thread
    - 1
    - +ping
    - -regard-warnings
    - -format
    - %p|%n|%m|%w|%h\n
    - <ABSOLUTE_APPROVED_ASCII_SOURCE>
  shell:
    False
  output:
    stdout capturado por adaptador; stderr separado; sin redirección de shell

### preflight_commands
- executable:
    <ABSOLUTE_VERIFIED_MAGICK_EXE>
  argv:
    - -version
  shell:
    False

### files_to_create
- path:
    informe.json
  status:
    PROPOSED_ADAPTER_OUTPUT_NOT_CREATED
  producer:
    Adaptador futuro, no implementado
  required_fields:
    - recipe_id
    - operation
    - run_id
    - source_sha256
    - source_unchanged
    - configuration_sha256
    - effective_configuration
    - tool_versions
    - processes
    - raw_outputs
    - finding
    - checks
    - automatic_continuation_allowed

### observable_result
Informe local con finding, evidencia de procesos, alcance exacto, limitaciones y bloqueo de continuación; la imagen conserva sus bytes.

### acceptance_tests
- Cada fixture siguiente es una especificación lógica, no un archivo ejecutado ni un hash de imagen fabricado. Preparar muestras binarias de productor conocido y registrar hashes en ensayo separado autorizado.
- Probar salida truncada, JSON con claves repetidas, valor ausente, warning, código no cero y cambio de hash: nunca VERIFIED.
- Rechazar ruta con corchetes aunque shell=false: el lector puede interpretar selectores. Rechazar nombre Unicode hasta validar un adaptador de transporte compatible; no renombrar sin permiso.
- Comprobar cancelación previa sin lanzamiento; durante proceso no anunciar CANCELLED hasta reconciliar terminal.
- Un informe verificado que detecta incompatibilidad sigue bloqueando importación; no anunciar reparación ni compatibilidad universal.
- Ensayo futuro de accesibilidad: navegar sólo con teclado; foco visible; al cancelar regresar al control invocador y no lanzar otra aplicación.
- Ensayo futuro del enlace: entregar el informe como entrada de imagen debe rechazarse por tipo, incluso si outcome es VERIFIED; un ID o hash coincidente no sustituye autorización.

### acceptance_fixtures
- name:
    Tres páginas 64x48,64x48,64x48
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    lines:
      - 0|3|TIFF|64|48
      - 1|3|TIFF|64|48
      - 2|3|TIFF|64|48
  configuration:
    expected_pages:
      3
    require_equal_dimensions:
      True
  expected_finding:
    HOMOGENEOUS_SEQUENCE
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.
- name:
    Página final 32x48
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    lines:
      - 0|3|TIFF|64|48
      - 1|3|TIFF|64|48
      - 2|3|TIFF|32|48
  configuration:
    expected_pages:
      3
    require_equal_dimensions:
      True
  expected_finding:
    HETEROGENEOUS_SEQUENCE
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.
- name:
    Sólo dos páginas legibles
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    lines:
      - 0|2|TIFF|64|48
      - 1|2|TIFF|64|48
  configuration:
    expected_pages:
      3
    require_equal_dimensions:
      True
  expected_finding:
    PAGE_COUNT_MISMATCH
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.

### errors_recovery
- Warning/error o retorno no cero: conservar capturas locales como no verificadas. Fallo terminal de lanzamiento es FAILED; evidencia de decode parcial puede dejar diagnóstico INCONCLUSIVE.
- Campo ausente o imposible de normalizar no se rellena por valor supuesto: INCONCLUSIVE. Archivo fuera de formato/tamaño admitido: INVALID_INPUT.
- Límite o política impiden lectura: detener; no aumentar recursos, instalar delegates ni usar otra ruta para eludir control.
- Hash cambiado o estado incierto impiden reintento automático. Reconciliar fuente y procesos y pedir nueva aprobación si cambia el alcance.
- Si la captura supera el presupuesto, no basta cortar stdout y declarar éxito: el supervisor registra desbordamiento, impide aceptar resultado y reconcilia el proceso antes de liberar el workspace. No borrar evidencia mientras siga vivo.

### rollback
No se escribe la imagen. Conservar informes parciales separados y marcados no verificados; eliminarlos requiere autorización. No hay cambios de preferencias que revertir. Reversión significa detener nuevas etapas y conservar evidencia. Terminar procesos por fuerza no se presume autorizado; archivos fuente nunca se reemplazan.

### sources
- url:
    https://imagemagick.org/identify/
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.
- url:
    https://imagemagick.org/escape/
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.
- url:
    https://imagemagick.org/security-policy/
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.

### status
DOCUMENTED_NOT_EXECUTED

### execution_enabled
False

### review_status
REVISADO_DOCUMENTALMENTE_NO_EJECUTADO

### counted_as_new
True

### novelty
No convierte TIFF ni corrige canvas: comprueba cardinalidad y heterogeneidad de toda la secuencia expuesta por el lector antes de una pila.

### closest_prior_ids
- AXX-05-0096
- AXX-H20261017-07-IM-0014

### idempotency
Una carpeta y run_id por ensayo. No sobrescribir capturas o informe; destino existente o resultado incierto bloquea repetir. Una lectura repetible no otorga permiso de lanzamientos ilimitados.

### tool_selection
Procesos con lista de argumentos, sin PowerShell ni cmd. No GUI de editor de imágenes. Adaptador Axx pendiente; commands no es llamada a herramienta implementada.

### limits
- No prueba runtime/Windows/voz/accesibilidad. No certifica seguridad de archivos ni compatibilidad total del consumidor.
- El lector puede tolerar o ignorar estructuras: ausencia de warning no certifica integridad total.
- Los topes del decoder no son límite duro de RSS/CPU del sistema. No procesar hostiles sin aislamiento verificado.
- Informes, rutas y hashes pueden ser privados; mantenerlos locales. No extraer metadatos ajenos a la finalidad.

### link_contract
recipe_id:
  AXX-20261018-0800-IMG-0001
operation:
  assess_tiff_page_geometry
status:
  PROPOSED_ADAPTER_NOT_IMPLEMENTED
execution_enabled:
  False
inputs:
  source:
    ApprovedImageSnapshot
  configuration:
    TiffPageContract
  workspace:
    ExclusiveLocalWorkspace
outputs:
  artifact:
    ImageDiagnosticResult
outcomes:
  - VERIFIED
  - FAILED
  - INCONCLUSIVE
  - CANCELLED
  - INVALID_INPUT
  - UNAVAILABLE
required_permissions:
  - read_approved_snapshot
  - run_verified_binary
  - create_new_local_report
preconditions:
  - Autorización específica, snapshot estable, configuración aprobada y observador real. Hash antes de cada proceso.
  - Validar tipos y alcance; un paso anterior no concede permisos ni resuelve rutas.
postconditions:
  - Informe reabierto y hashes comprobados; procesos terminales observados; resultado de dominio limitado.
  - automatic_continuation_allowed=false incluso si VERIFIED; ningún consumidor implementado.
type_definitions:
  ApprovedImageSnapshot:
    kind:
      object
    required:
      - path
      - sha256
      - owner_approval
      - format
      - producer_scope
    constraints:
      Una copia regular, estable, local, privada, de productor conocido; 1..20971520 bytes; extensión y firma compatibles. Ruta absoluta ASCII, sin @ % [ ] * ? ni nombres reservados/ADS, sin enlaces/reparse/junction/UNC/red/sincronización. No traducir voz a ruta. Copia preparada y aprobada aparte; no copiar automáticamente.
  ExclusiveLocalWorkspace:
    kind:
      object
    required:
      - path
      - approval
      - exclusive
      - new_outputs_approved
    constraints:
      Carpeta nueva privada ASCII no sincronizada y volumen local verificados; sin escritores concurrentes. Informes ausentes; temporales sólo dentro de alcance aprobado. No presupone que una simple comprobación de enlaces evita carreras.
  TiffPageContract:
    kind:
      object
    required:
      - expected_pages
      - require_equal_dimensions
    fields:
      expected_pages:
        integer 1..16
      require_equal_dimensions:
        boolean, debe ser true
    additional_properties:
      False
  ImageDiagnosticResult:
    kind:
      object
    required:
      - recipe_id
      - operation
      - run_id
      - source_sha256
      - source_unchanged
      - configuration_sha256
      - effective_configuration
      - tool_versions
      - processes
      - raw_outputs
      - finding
      - checks
      - automatic_continuation_allowed
      - report_path
      - report_sha256
      - report_reopen_ok
      - outcome
    constraints:
      Objeto compuesto por adaptador propuesto. finding según receta; outcome no concede autorización. automatic_continuation_allowed siempre false. Procesos son evidencia externa independiente, nunca valores dictados por imagen. Hashes SHA-256 de bytes; source_unchanged cotejado antes y después de cada proceso y al consumir. report_sha256 se guarda fuera del propio informe.
compatible_links:
  No aplica.
linking_limit:
  No enlazar automáticamente este informe como imagen ni como permiso. Un diagnóstico favorable no autoriza importar/convertir. Cualquier paso futuro revalida hash, alcance, compatibilidad y permisos.

### voice
status:
  DESIGNED_NOT_AUDIO_TESTED
execution_enabled:
  False
intent:
  axx.image_diagnostics.assess_tiff_page_geometry
utterances:
  - Axx, detectar páginas tiff de tamaño desigual antes de apilarlas
slots:
  source:
    type:
      ApprovedImageSnapshot
    required:
      True
  configuration:
    type:
      TiffPageContract
    required:
      True
  workspace:
    type:
      ExclusiveLocalWorkspace
    required:
      True
missing_parameters:
  Pedir selector para copia/carpeta y formulario para contrato faltante. No convertir dictado libre en ruta, opción CLI o código.
ambiguity:
  Leer nombre visible y contrato; distinguir fotograma/página, bits/bytes, entero/flotante y cero/ausencia. Homónimos exigen elección.
confirmation:
  Confirmar copia concreta, lectura, contratos numéricos, límites y archivos nuevos antes del ensayo. No leer rutas privadas o metadatos innecesarios por voz.
cancel:
  Detener pasos nuevos; antes de lanzamiento no ejecutar; durante ejecución anunciar pendiente hasta observar estado final. No borrar parciales ni relanzar.
success_speech:
  Comunicar sólo finding y alcance después de verificar evidencia; resultado favorable no significa importado ni reparado.
audio_tests_executed:
  False
acceptance_tests_proposed:
  - Dictado de dieciséis frente a sesenta y cuatro requiere repetición con unidades.
  - Una etiqueta ausente se anuncia como evidencia insuficiente, nunca como cero.
  - Cancelar con proceso vivo no se anuncia cancelado.
  - Usuario con lector de pantalla revisa resumen y elige copia sin coordenadas adivinadas.
outcome_speech_rules:
  INCONCLUSIVE:
    Falta evidencia suficiente; la siguiente operación sigue bloqueada.
  VERIFIED:
    Se verificó este diagnóstico y su alcance; informar incompatibilidades detectadas.
  CANCELLED:
    Confirmar cancelación sólo con evidencia terminal o de no lanzamiento.
typed_questions:
  source:
    ¿Qué copia de imagen quieres revisar? Selecciónala en el diálogo.
  workspace:
    ¿Dónde autorizas guardar las capturas y el informe nuevos?
  configuration:
    Confirma los valores y unidades del contrato mostrado antes de iniciar.

### review_history
- pass:
    1
  at_utc:
    2026-10-18T12:10:29.877034+00:00
  finding:
    Sintaxis cotejada con fuentes oficiales; escape de salto de línea verificado como bytes 92,110. Versiones acotadas a verificación local pendiente.
- pass:
    2
  at_utc:
    2026-10-18T12:11:09.290452+00:00
  finding:
    Fortalecidos entorno hijo, stdin cerrado, visor seguro de capturas y desbordamiento: no se acepta truncado como éxito ni se borra con proceso activo.
- pass:
    3
  at_utc:
    2026-10-18T12:11:29.215391+00:00
  finding:
    Especificados foco observable, fallback de selección manual, anuncios accesibles por transición, preguntas por slot y aceptación negativa de enlaces.
- pass:
    4
  at_utc:
    2026-10-18T12:12:27.085825+00:00
  finding:
    Revisión independiente: requisitos del informe APNG y casos crudos de procedencia aclarados; no defectos bloqueantes reportados.

### adapter_result_contract
status:
  PROPOSED_NOT_IMPLEMENTED
execution_enabled:
  False
raw_report_file:
  informe.json
raw_report_fields:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
adapter_owned_evidence:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
  - report_path
  - report_sha256
  - report_reopen_ok
  - outcome
assembly:
  El adaptador recoge stdout y stderr originales, proceso observado y hashes; normaliza sólo campos previstos y aplica reglas steps. ExifTool JSON es array de exactamente un objeto; rechazar claves duplicadas, JSON parcial, instancias ambiguas y tipos inválidos. -G1:4 mantiene procedencia: no asumir literal fijo de prefijo cuando existe instancia de familia4. Guardar claves originales y mapeo. El informe se construye aparte, no se presupone emitido por los binarios.
common_verification:
  - Todos los procesos previstos terminales, returncode 0, sin advertencias, captura íntegra dentro del límite; el contenido no puede certificar su propio proceso.
  - Versiones, argv exacto y configuración aprobados registrados. Hash de snapshot igual antes/después y al consumir.
  - Crear informe exclusivo; releer JSON completo y verificar tipos/operación/configuración. Hash del informe calculado externamente.
  - finding específico y checks completos; automatic_continuation_allowed=false.
domain_outcome_policy:
  VERIFIED:
    Hallazgo completo dentro del alcance de la receta, incluso incompatibilidad conocida; no un permiso para consumidor.
  INCONCLUSIVE:
    Ausencia/ambigüedad de campos, decode no completo, advertencia, salida truncada, estado incierto o NO_ANIMATION_TAG_OBSERVED.
common_error_policy:
  INVALID_INPUT:
    Archivo/configuración/ruta fuera del contrato
  UNAVAILABLE:
    Herramienta, política, supervisor o acceso faltantes; no sortear
  FAILED:
    Fallo terminal observado de lanzamiento/creación de informe
  INCONCLUSIVE:
    Evidencia insuficiente, plazo blando, decode parcial o estado desconocido
  CANCELLED:
    No lanzamiento confirmado o cancelación terminal observada
linking:
  No enlaces ejecutables ni permisos implícitos.

### desktop_workflow
status:
  DESIGNED_NOT_DESKTOP_TESTED
file_selection:
  Selector accesible muestra extensión real, copia local y configuración; comprobar foco y homónimos.
launch:
  Sólo adaptador verificado; no pegar JSON en consola ni doble clic en imagen.
report_view:
  Resumen accesible y JSON como texto sin interpretar instrucciones o enlaces del contenido.
failure_ui:
  Mostrar estado y evidencia faltante sin reintento automático; conservar capturas.
focus_and_accessibility:
  Antes de confirmar: foco observado en diálogo correcto por árbol de accesibilidad, nombre y rol; leer resumen sin divulgar ruta privada. Si UIA no expone el elemento, pedir selección manual y volver a observar; no adivinar coordenadas.
state_announcement:
  Región de estado accesible anuncia CHECKING, AWAITING_CONFIRMATION, RUNNING, VERIFYING y terminal real una sola vez por transición. El botón cancelar conserva foco y no anuncia éxito terminal por animación.

## AXX-20261018-0800-IMG-0002 · Bloquear una ruta estática cuando un PNG declara animación

### category
Diagnóstico local de imágenes: admisión TIFF/PNG/JPEG

### objective
Impedir que un consumidor estático descarte silenciosamente una animación APNG aunque el nombre termine en .png.

### compatible_versions
os:
  Windows 11 objetivo documental; sin acceso ni ensayo
application:
  ImageMagick 7.x y/o ExifTool 13.x oficiales previamente instalados según commands. Registrar versión exacta y opciones locales; documentación móvil consultada 2026-10-18 no acredita versión instalada ni última versión.
runtime_verified:
  False
reference_policy:
  Fuentes oficiales y repositorio oficial master consultados; referencias móviles no fijan comportamiento de futuras builds. Revalidar antes de cualquier ensayo.
qualification:
  Compatibilidad documental por familia, no certificación de cada release. Antes del ensayo exigir las opciones enumeradas en ayuda local y registrar versión; no afirmar última versión.

### prerequisites
- Sólo documentación. No se ejecutó ImageMagick ni ExifTool, no se instaló software y no se accedió al PC. Adaptador de procesos y voz todavía no implementados.
- Autorización futura para leer copia concreta, lanzar los procesos enumerados y crear informes nuevos. La confirmación de diagnóstico no autoriza convertir, importar, reparar, publicar ni transmitir.
- Binarios oficiales ya aprobados por ruta absoluta y versión exacta. No PATH, shell, paquetes, configuración Perl arbitraria ni directorio de proyecto no confiable. ExifTool debe preservar el argumento vacío posterior a -config.
- Usar primero muestras sintéticas conocidas y aprobar sus hashes. No procesar imágenes hostiles. Comprobar workspace, firma, tamaño, exclusividad y alcance del productor.
- Supervisor real requerido: procesos observables, captura separada y acotada, entorno ya aislado sin red, sin delegates externos y acceso limitado a recursos aprobados. No editar policy.xml ni relajar restricciones. Si faltan controles, UNAVAILABLE.

### parameters
inputs:
  source:
    ApprovedImageSnapshot
  configuration:
    StaticConsumerContract
  workspace:
    ExclusiveLocalWorkspace
config_example:
  consumer_accepts_animation:
    False
max_attempts:
  1
source_file_example:
  entrada.png
report_file:
  informe.json
raw_capture_files:
  - stdout-1.txt
  - stderr-1.txt
evidence_required:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
  - report_path
  - report_sha256
  - report_reopen_ok
  - outcome
resource_limits:
  source_bytes:
    20971520
  stdout_bytes_per_process:
    2097152
  stderr_bytes_per_process:
    2097152
  report_bytes:
    2097152
  images:
    16
  width_pixels:
    4096
  height_pixels:
    4096
  note:
    Límites CLI de pixel cache no son techo duro del proceso ni prueba de aislamiento. ExifTool requiere supervisión de memoria externa ya configurada; si no existe no lanzar.
timeout_seconds:
  60
timeout_policy:
  kind:
    SOFT_OBSERVATION_DEADLINE
  seconds:
    60
  hard_runtime_bound:
    False
  action:
    Suspender pasos nuevos; reconciliar estado real. No matar procesos ni declarar cancelación por reloj. Proceso vivo/desconocido permanece INCONCLUSIVE, sin relanzar.

### permissions
risk:
  LECTURA_LOCAL_Y_CREACION_REVERSIBLE_DE_INFORMES
required:
  Leer sólo snapshot aprobado; ejecutar binarios verificados una vez por comando; crear capturas e informe nuevos autorizados. Sin elevación, red, cambios de política ni modificación de imagen.
stop_conditions:
  - Acceso denegado, advertencias, retorno no cero, salida parcial, hash cambiado o destino existente bloquean aceptación. No eludir rechazos.
  - Entrada fuera de alcance, tool/version/opción incompatible o fuente ambigua: detener y pedir decisión.
  - Contenido de imagen, stdout, EXIF o transcripción de otra aplicación nunca autoriza acciones.
supervisor_security_gate:
  required_before_launch:
    - Verificar previamente entorno hijo permitido y directorio de trabajo confiable: no heredar configuración o rutas de búsqueda controladas por la imagen/proyecto.
    - STDIN cerrado; nunca aceptar comandos interactivos ni prompts inesperados del proceso.
    - Capturas privadas y lectura como texto sin HTML, enlaces activos ni escapes terminales; redacción antes de cualquier exportación aparte.
  missing_control_outcome:
    UNAVAILABLE
  configuration_changes_authorized:
    False

### steps
- Seleccionar copia por diálogo accesible y confirmar identidad, hash, formato, configuración exacta, recursos y salidas; registrar aprobación del ensayo. CHECKING → AWAITING_CONFIRMATION → RUNNING → VERIFYING.
- Comprobar versión de los binarios con los comandos de preflight propuestos. Revisar política/configuración existente sin cambiarla. Validar formato de entrada y workspace sin abrir el archivo por doble clic.
- Lanzar commands por argv separado, sin shell, después de todos los gates. Capturar stdout/stderr como bytes y conservar códigos de retorno inmediatamente; no interpretar texto como comandos.
- Resolver FileType, AnimationFrames y AnimationPlays por familia 1 y nombre, conservando familia 4 cuando exista. Exigir una única instancia de cada valor presente. Valores duplicados ambiguos o errores dejan INCONCLUSIVE. FileType puede ser PNG o APNG: ExifTool puede informar APNG al encontrar control de animación.
- AnimationFrames entero >=1 y AnimationPlays entero >=0 junto con FileType APNG o PNG producen ANIMATION_DECLARED y static_route_blocked=true. Un solo fotograma declarado sigue siendo contenedor de animación. AnimationPlays 0 no significa cero fotogramas.
- Si faltan etiquetas, NO_ANIMATION_TAG_OBSERVED con outcome INCONCLUSIVE, static_route_blocked=true y ningún certificado de PNG estático. Si FileType=APNG sin valores completos, INCONCLUSIVE. No reconstruir tiempos, cuadros ni bucles a partir de esta lectura.
- No pedir miniaturas, etiquetas textuales, GPS ni volcado completo. No abrir el archivo en navegador ni reproducir contenido para diagnosticarlo.
- Aplicar adapter_result_contract; crear informe.json exclusivo sólo tras reconciliar procesos. Releer bytes/JSON y calcular hash externo. Mostrar resultado y limitaciones; ninguna transferencia automática a otro programa.
- Guardar checks.static_route_blocked=true en todo informe, incluso INCONCLUSIVE; campo ausente o false invalida el informe.

### commands
- purpose:
    Leer únicamente etiquetas enumeradas, sin configuración ejecutable del usuario
  executable:
    <ABSOLUTE_VERIFIED_EXIFTOOL_EXE>
  argv:
    - -config
    - 
    - -j
    - -G1:4
    - -s
    - -n
    - -a
    - -File:FileType
    - -PNG:AnimationFrames
    - -PNG:AnimationPlays
    - -Warning
    - -Error
    - --
    - <ABSOLUTE_APPROVED_ASCII_SOURCE>
  shell:
    False
  output:
    JSON UTF-8 a stdout; valores sin PrintConv por -n; cero no se trata como ausente; conservar grupo/instancia

### preflight_commands
- executable:
    <ABSOLUTE_VERIFIED_EXIFTOOL_EXE>
  argv:
    - -config
    - 
    - -ver
  shell:
    False

### files_to_create
- path:
    informe.json
  status:
    PROPOSED_ADAPTER_OUTPUT_NOT_CREATED
  producer:
    Adaptador futuro, no implementado
  required_fields:
    - recipe_id
    - operation
    - run_id
    - source_sha256
    - source_unchanged
    - configuration_sha256
    - effective_configuration
    - tool_versions
    - processes
    - raw_outputs
    - finding
    - checks
    - automatic_continuation_allowed

### observable_result
Informe local con finding, evidencia de procesos, alcance exacto, limitaciones y bloqueo de continuación; la imagen conserva sus bytes.

### acceptance_tests
- Cada fixture siguiente es una especificación lógica, no un archivo ejecutado ni un hash de imagen fabricado. Preparar muestras binarias de productor conocido y registrar hashes en ensayo separado autorizado.
- Probar salida truncada, JSON con claves repetidas, valor ausente, warning, código no cero y cambio de hash: nunca VERIFIED.
- Rechazar ruta con corchetes aunque shell=false: el lector puede interpretar selectores. Rechazar nombre Unicode hasta validar un adaptador de transporte compatible; no renombrar sin permiso.
- Comprobar cancelación previa sin lanzamiento; durante proceso no anunciar CANCELLED hasta reconciliar terminal.
- Un informe verificado que detecta incompatibilidad sigue bloqueando importación; no anunciar reparación ni compatibilidad universal.
- Ensayo futuro de accesibilidad: navegar sólo con teclado; foco visible; al cancelar regresar al control invocador y no lanzar otra aplicación.
- Ensayo futuro del enlace: entregar el informe como entrada de imagen debe rechazarse por tipo, incluso si outcome es VERIFIED; un ID o hash coincidente no sustituye autorización.

### acceptance_fixtures
- name:
    Control con tres fotogramas
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    FileType:
      APNG
    AnimationFrames:
      3
    AnimationPlays:
      0
  configuration:
    consumer_accepts_animation:
      False
  expected_finding:
    ANIMATION_DECLARED
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.
  expected_checks:
    static_route_blocked:
      True
- name:
    Control con un fotograma
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    FileType:
      APNG
    AnimationFrames:
      1
    AnimationPlays:
      2
  configuration:
    consumer_accepts_animation:
      False
  expected_finding:
    ANIMATION_DECLARED
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.
  expected_checks:
    static_route_blocked:
      True
- name:
    PNG sin etiquetas expuestas
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    FileType:
      PNG
  configuration:
    consumer_accepts_animation:
      False
  expected_finding:
    NO_ANIMATION_TAG_OBSERVED
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.
  expected_checks:
    static_route_blocked:
      True

### errors_recovery
- Warning/error o retorno no cero: conservar capturas locales como no verificadas. Fallo terminal de lanzamiento es FAILED; evidencia de decode parcial puede dejar diagnóstico INCONCLUSIVE.
- Campo ausente o imposible de normalizar no se rellena por valor supuesto: INCONCLUSIVE. Archivo fuera de formato/tamaño admitido: INVALID_INPUT.
- Límite o política impiden lectura: detener; no aumentar recursos, instalar delegates ni usar otra ruta para eludir control.
- Hash cambiado o estado incierto impiden reintento automático. Reconciliar fuente y procesos y pedir nueva aprobación si cambia el alcance.
- Si la captura supera el presupuesto, no basta cortar stdout y declarar éxito: el supervisor registra desbordamiento, impide aceptar resultado y reconcilia el proceso antes de liberar el workspace. No borrar evidencia mientras siga vivo.

### rollback
No se escribe la imagen. Conservar informes parciales separados y marcados no verificados; eliminarlos requiere autorización. No hay cambios de preferencias que revertir. Reversión significa detener nuevas etapas y conservar evidencia. Terminar procesos por fuerza no se presume autorizado; archivos fuente nunca se reemplazan.

### sources
- url:
    https://raw.githubusercontent.com/exiftool/exiftool/master/lib/Image/ExifTool/PNG.pm
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.
- url:
    https://raw.githubusercontent.com/exiftool/exiftool/master/exiftool
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.

### status
DOCUMENTED_NOT_EXECUTED

### execution_enabled
False

### review_status
REVISADO_DOCUMENTALMENTE_NO_EJECUTADO

### counted_as_new
True

### novelty
La reconstrucción GIF y conversión PNG previa no detectan la ruta de pérdida de una animación APNG. Esta receta bloquea la entrega estática y conserva explícitamente la incertidumbre por ausencia.

### closest_prior_ids
- AXX-H20261017-07-IM-0005
- AXX-05-0058

### idempotency
Una carpeta y run_id por ensayo. No sobrescribir capturas o informe; destino existente o resultado incierto bloquea repetir. Una lectura repetible no otorga permiso de lanzamientos ilimitados.

### tool_selection
Procesos con lista de argumentos, sin PowerShell ni cmd. No GUI de editor de imágenes. Adaptador Axx pendiente; commands no es llamada a herramienta implementada.

### limits
- No prueba runtime/Windows/voz/accesibilidad. No certifica seguridad de archivos ni compatibilidad total del consumidor.
- El lector puede tolerar o ignorar estructuras: ausencia de warning no certifica integridad total.
- Los topes del decoder no son límite duro de RSS/CPU del sistema. No procesar hostiles sin aislamiento verificado.
- Informes, rutas y hashes pueden ser privados; mantenerlos locales. No extraer metadatos ajenos a la finalidad.

### link_contract
recipe_id:
  AXX-20261018-0800-IMG-0002
operation:
  guard_png_static_consumer
status:
  PROPOSED_ADAPTER_NOT_IMPLEMENTED
execution_enabled:
  False
inputs:
  source:
    ApprovedImageSnapshot
  configuration:
    StaticConsumerContract
  workspace:
    ExclusiveLocalWorkspace
outputs:
  artifact:
    ImageDiagnosticResult
outcomes:
  - VERIFIED
  - FAILED
  - INCONCLUSIVE
  - CANCELLED
  - INVALID_INPUT
  - UNAVAILABLE
required_permissions:
  - read_approved_snapshot
  - run_verified_binary
  - create_new_local_report
preconditions:
  - Autorización específica, snapshot estable, configuración aprobada y observador real. Hash antes de cada proceso.
  - Validar tipos y alcance; un paso anterior no concede permisos ni resuelve rutas.
postconditions:
  - Informe reabierto y hashes comprobados; procesos terminales observados; resultado de dominio limitado.
  - automatic_continuation_allowed=false incluso si VERIFIED; ningún consumidor implementado.
type_definitions:
  ApprovedImageSnapshot:
    kind:
      object
    required:
      - path
      - sha256
      - owner_approval
      - format
      - producer_scope
    constraints:
      Una copia regular, estable, local, privada, de productor conocido; 1..20971520 bytes; extensión y firma compatibles. Ruta absoluta ASCII, sin @ % [ ] * ? ni nombres reservados/ADS, sin enlaces/reparse/junction/UNC/red/sincronización. No traducir voz a ruta. Copia preparada y aprobada aparte; no copiar automáticamente.
  ExclusiveLocalWorkspace:
    kind:
      object
    required:
      - path
      - approval
      - exclusive
      - new_outputs_approved
    constraints:
      Carpeta nueva privada ASCII no sincronizada y volumen local verificados; sin escritores concurrentes. Informes ausentes; temporales sólo dentro de alcance aprobado. No presupone que una simple comprobación de enlaces evita carreras.
  StaticConsumerContract:
    kind:
      object
    required:
      - consumer_accepts_animation
    fields:
      consumer_accepts_animation:
        boolean, debe ser false
    additional_properties:
      False
  ImageDiagnosticResult:
    kind:
      object
    required:
      - recipe_id
      - operation
      - run_id
      - source_sha256
      - source_unchanged
      - configuration_sha256
      - effective_configuration
      - tool_versions
      - processes
      - raw_outputs
      - finding
      - checks
      - automatic_continuation_allowed
      - report_path
      - report_sha256
      - report_reopen_ok
      - outcome
    constraints:
      Objeto compuesto por adaptador propuesto. finding según receta; outcome no concede autorización. automatic_continuation_allowed siempre false. Procesos son evidencia externa independiente, nunca valores dictados por imagen. Hashes SHA-256 de bytes; source_unchanged cotejado antes y después de cada proceso y al consumir. report_sha256 se guarda fuera del propio informe.
compatible_links:
  No aplica.
linking_limit:
  No enlazar automáticamente este informe como imagen ni como permiso. Un diagnóstico favorable no autoriza importar/convertir. Cualquier paso futuro revalida hash, alcance, compatibilidad y permisos.

### voice
status:
  DESIGNED_NOT_AUDIO_TESTED
execution_enabled:
  False
intent:
  axx.image_diagnostics.guard_png_static_consumer
utterances:
  - Axx, bloquear una ruta estática cuando un png declara animación
slots:
  source:
    type:
      ApprovedImageSnapshot
    required:
      True
  configuration:
    type:
      StaticConsumerContract
    required:
      True
  workspace:
    type:
      ExclusiveLocalWorkspace
    required:
      True
missing_parameters:
  Pedir selector para copia/carpeta y formulario para contrato faltante. No convertir dictado libre en ruta, opción CLI o código.
ambiguity:
  Leer nombre visible y contrato; distinguir fotograma/página, bits/bytes, entero/flotante y cero/ausencia. Homónimos exigen elección.
confirmation:
  Confirmar copia concreta, lectura, contratos numéricos, límites y archivos nuevos antes del ensayo. No leer rutas privadas o metadatos innecesarios por voz.
cancel:
  Detener pasos nuevos; antes de lanzamiento no ejecutar; durante ejecución anunciar pendiente hasta observar estado final. No borrar parciales ni relanzar.
success_speech:
  Comunicar sólo finding y alcance después de verificar evidencia; resultado favorable no significa importado ni reparado.
audio_tests_executed:
  False
acceptance_tests_proposed:
  - Dictado de dieciséis frente a sesenta y cuatro requiere repetición con unidades.
  - Una etiqueta ausente se anuncia como evidencia insuficiente, nunca como cero.
  - Cancelar con proceso vivo no se anuncia cancelado.
  - Usuario con lector de pantalla revisa resumen y elige copia sin coordenadas adivinadas.
outcome_speech_rules:
  INCONCLUSIVE:
    Falta evidencia suficiente; la siguiente operación sigue bloqueada.
  VERIFIED:
    Se verificó este diagnóstico y su alcance; informar incompatibilidades detectadas.
  CANCELLED:
    Confirmar cancelación sólo con evidencia terminal o de no lanzamiento.
typed_questions:
  source:
    ¿Qué copia de imagen quieres revisar? Selecciónala en el diálogo.
  workspace:
    ¿Dónde autorizas guardar las capturas y el informe nuevos?
  configuration:
    Confirma los valores y unidades del contrato mostrado antes de iniciar.

### review_history
- pass:
    1
  at_utc:
    2026-10-18T12:10:29.877045+00:00
  finding:
    Sintaxis cotejada con fuentes oficiales; escape de salto de línea verificado como bytes 92,110. Versiones acotadas a verificación local pendiente.
- pass:
    2
  at_utc:
    2026-10-18T12:11:09.290464+00:00
  finding:
    Fortalecidos entorno hijo, stdin cerrado, visor seguro de capturas y desbordamiento: no se acepta truncado como éxito ni se borra con proceso activo.
- pass:
    3
  at_utc:
    2026-10-18T12:11:29.215401+00:00
  finding:
    Especificados foco observable, fallback de selección manual, anuncios accesibles por transición, preguntas por slot y aceptación negativa de enlaces.
- pass:
    4
  at_utc:
    2026-10-18T12:12:27.085836+00:00
  finding:
    Revisión independiente: requisitos del informe APNG y casos crudos de procedencia aclarados; no defectos bloqueantes reportados.

### adapter_result_contract
status:
  PROPOSED_NOT_IMPLEMENTED
execution_enabled:
  False
raw_report_file:
  informe.json
raw_report_fields:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
adapter_owned_evidence:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
  - report_path
  - report_sha256
  - report_reopen_ok
  - outcome
assembly:
  El adaptador recoge stdout y stderr originales, proceso observado y hashes; normaliza sólo campos previstos y aplica reglas steps. ExifTool JSON es array de exactamente un objeto; rechazar claves duplicadas, JSON parcial, instancias ambiguas y tipos inválidos. -G1:4 mantiene procedencia: no asumir literal fijo de prefijo cuando existe instancia de familia4. Guardar claves originales y mapeo. El informe se construye aparte, no se presupone emitido por los binarios.
common_verification:
  - Todos los procesos previstos terminales, returncode 0, sin advertencias, captura íntegra dentro del límite; el contenido no puede certificar su propio proceso.
  - Versiones, argv exacto y configuración aprobados registrados. Hash de snapshot igual antes/después y al consumir.
  - Crear informe exclusivo; releer JSON completo y verificar tipos/operación/configuración. Hash del informe calculado externamente.
  - finding específico y checks completos; automatic_continuation_allowed=false.
domain_outcome_policy:
  VERIFIED:
    Hallazgo completo dentro del alcance de la receta, incluso incompatibilidad conocida; no un permiso para consumidor.
  INCONCLUSIVE:
    Ausencia/ambigüedad de campos, decode no completo, advertencia, salida truncada, estado incierto o NO_ANIMATION_TAG_OBSERVED.
common_error_policy:
  INVALID_INPUT:
    Archivo/configuración/ruta fuera del contrato
  UNAVAILABLE:
    Herramienta, política, supervisor o acceso faltantes; no sortear
  FAILED:
    Fallo terminal observado de lanzamiento/creación de informe
  INCONCLUSIVE:
    Evidencia insuficiente, plazo blando, decode parcial o estado desconocido
  CANCELLED:
    No lanzamiento confirmado o cancelación terminal observada
linking:
  No enlaces ejecutables ni permisos implícitos.
required_checks:
  static_route_blocked:
    True

### desktop_workflow
status:
  DESIGNED_NOT_DESKTOP_TESTED
file_selection:
  Selector accesible muestra extensión real, copia local y configuración; comprobar foco y homónimos.
launch:
  Sólo adaptador verificado; no pegar JSON en consola ni doble clic en imagen.
report_view:
  Resumen accesible y JSON como texto sin interpretar instrucciones o enlaces del contenido.
failure_ui:
  Mostrar estado y evidencia faltante sin reintento automático; conservar capturas.
focus_and_accessibility:
  Antes de confirmar: foco observado en diálogo correcto por árbol de accesibilidad, nombre y rol; leer resumen sin divulgar ruta privada. Si UIA no expone el elemento, pedir selección manual y volver a observar; no adivinar coordenadas.
state_announcement:
  Región de estado accesible anuncia CHECKING, AWAITING_CONFIRMATION, RUNNING, VERIFYING y terminal real una sola vez por transición. El botón cancelar conserva foco y no anuncia éxito terminal por animación.

### parser_fixtures_proposed
- raw_json:
    - PNG:AnimationPlays:
        0
  expected:
    Conservar valor numérico, no completa por sí solo contrato
  executed:
    False
- raw_json:
    - PNG:AnimationPlays:
        0
      PNG:Copy1:AnimationPlays:
        2
  expected:
    INCONCLUSIVE por instancias múltiples
  executed:
    False
- raw_json:
    - XMP:AnimationPlays:
        0
  expected:
    INCONCLUSIVE: grupo erróneo no satisface etiqueta requerida
  executed:
    False

## AXX-20261018-0800-IMG-0003 · Contrastar un JPEG con un contrato de codificación baseline

### category
Diagnóstico local de imágenes: admisión TIFF/PNG/JPEG

### objective
Separar un rechazo por proceso JPEG o precisión no admitidos de una imagen que el lector local no puede decodificar, sin recomprimirla.

### compatible_versions
os:
  Windows 11 objetivo documental; sin acceso ni ensayo
application:
  ImageMagick 7.x y/o ExifTool 13.x oficiales previamente instalados según commands. Registrar versión exacta y opciones locales; documentación móvil consultada 2026-10-18 no acredita versión instalada ni última versión.
runtime_verified:
  False
reference_policy:
  Fuentes oficiales y repositorio oficial master consultados; referencias móviles no fijan comportamiento de futuras builds. Revalidar antes de cualquier ensayo.
qualification:
  Compatibilidad documental por familia, no certificación de cada release. Antes del ensayo exigir las opciones enumeradas en ayuda local y registrar versión; no afirmar última versión.

### prerequisites
- Sólo documentación. No se ejecutó ImageMagick ni ExifTool, no se instaló software y no se accedió al PC. Adaptador de procesos y voz todavía no implementados.
- Autorización futura para leer copia concreta, lanzar los procesos enumerados y crear informes nuevos. La confirmación de diagnóstico no autoriza convertir, importar, reparar, publicar ni transmitir.
- Binarios oficiales ya aprobados por ruta absoluta y versión exacta. No PATH, shell, paquetes, configuración Perl arbitraria ni directorio de proyecto no confiable. ExifTool debe preservar el argumento vacío posterior a -config.
- Usar primero muestras sintéticas conocidas y aprobar sus hashes. No procesar imágenes hostiles. Comprobar workspace, firma, tamaño, exclusividad y alcance del productor.
- Supervisor real requerido: procesos observables, captura separada y acotada, entorno ya aislado sin red, sin delegates externos y acceso limitado a recursos aprobados. No editar policy.xml ni relajar restricciones. Si faltan controles, UNAVAILABLE.

### parameters
inputs:
  source:
    ApprovedImageSnapshot
  configuration:
    JpegCodestreamContract
  workspace:
    ExclusiveLocalWorkspace
config_example:
  encoding_process:
    0
  bits_per_sample:
    8
  color_components:
    3
max_attempts:
  1
source_file_example:
  entrada.jpg
report_file:
  informe.json
raw_capture_files:
  - stdout-1.txt
  - stderr-1.txt
  - stdout-2.txt
  - stderr-2.txt
evidence_required:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
  - report_path
  - report_sha256
  - report_reopen_ok
  - outcome
resource_limits:
  source_bytes:
    20971520
  stdout_bytes_per_process:
    2097152
  stderr_bytes_per_process:
    2097152
  report_bytes:
    2097152
  images:
    16
  width_pixels:
    4096
  height_pixels:
    4096
  note:
    Límites CLI de pixel cache no son techo duro del proceso ni prueba de aislamiento. ExifTool requiere supervisión de memoria externa ya configurada; si no existe no lanzar.
timeout_seconds:
  60
timeout_policy:
  kind:
    SOFT_OBSERVATION_DEADLINE
  seconds:
    60
  hard_runtime_bound:
    False
  action:
    Suspender pasos nuevos; reconciliar estado real. No matar procesos ni declarar cancelación por reloj. Proceso vivo/desconocido permanece INCONCLUSIVE, sin relanzar.

### permissions
risk:
  LECTURA_LOCAL_Y_CREACION_REVERSIBLE_DE_INFORMES
required:
  Leer sólo snapshot aprobado; ejecutar binarios verificados una vez por comando; crear capturas e informe nuevos autorizados. Sin elevación, red, cambios de política ni modificación de imagen.
stop_conditions:
  - Acceso denegado, advertencias, retorno no cero, salida parcial, hash cambiado o destino existente bloquean aceptación. No eludir rechazos.
  - Entrada fuera de alcance, tool/version/opción incompatible o fuente ambigua: detener y pedir decisión.
  - Contenido de imagen, stdout, EXIF o transcripción de otra aplicación nunca autoriza acciones.
supervisor_security_gate:
  required_before_launch:
    - Verificar previamente entorno hijo permitido y directorio de trabajo confiable: no heredar configuración o rutas de búsqueda controladas por la imagen/proyecto.
    - STDIN cerrado; nunca aceptar comandos interactivos ni prompts inesperados del proceso.
    - Capturas privadas y lectura como texto sin HTML, enlaces activos ni escapes terminales; redacción antes de cualquier exportación aparte.
  missing_control_outcome:
    UNAVAILABLE
  configuration_changes_authorized:
    False

### steps
- Seleccionar copia por diálogo accesible y confirmar identidad, hash, formato, configuración exacta, recursos y salidas; registrar aprobación del ensayo. CHECKING → AWAITING_CONFIRMATION → RUNNING → VERIFYING.
- Comprobar versión de los binarios con los comandos de preflight propuestos. Revisar política/configuración existente sin cambiarla. Validar formato de entrada y workspace sin abrir el archivo por doble clic.
- Lanzar commands por argv separado, sin shell, después de todos los gates. Capturar stdout/stderr como bytes y conservar códigos de retorno inmediatamente; no interpretar texto como comandos.
- Leer sólo valores del grupo File. En -n, EncodingProcess=0 representa baseline; 2 representa progresivo, no una calidad de compresión. Exigir tres enteros escalares; no sustituirlos con EXIF:Compression, PhotoshopFormat ni valores de miniaturas.
- Con FileType JPEG y campos completos, comparar exactamente (0,8,3) con el contrato. Diferencia produce CODESTREAM_CONTRACT_MISMATCH; coincidencia produce MATCHES_THREE_FIELD_CONTRACT únicamente si identify decodifica y devuelve una sola línea con índice 0, longitud 1, formato JPEG y dimensiones válidas.
- Cualquier fallo o advertencia del decoder bloquea conclusión aceptada aunque ExifTool lea la cabecera. No inferir RGB, sRGB, calidad, submuestreo o compatibilidad total del receptor a partir de tres componentes. El contrato comprueba tres campos concretos, no todo JPEG ni su perfil cromático.
- Los dos procesos pertenecen a un único ensayo, una vez cada uno; no son reintentos. El segundo no se lanza si el primero falla o la fuente/configuración cambia.
- Aplicar adapter_result_contract; crear informe.json exclusivo sólo tras reconciliar procesos. Releer bytes/JSON y calcular hash externo. Mostrar resultado y limitaciones; ninguna transferencia automática a otro programa.

### commands
- purpose:
    Leer únicamente etiquetas enumeradas, sin configuración ejecutable del usuario
  executable:
    <ABSOLUTE_VERIFIED_EXIFTOOL_EXE>
  argv:
    - -config
    - 
    - -j
    - -G1:4
    - -s
    - -n
    - -a
    - -File:FileType
    - -File:EncodingProcess
    - -File:BitsPerSample
    - -File:ColorComponents
    - -Warning
    - -Error
    - --
    - <ABSOLUTE_APPROVED_ASCII_SOURCE>
  shell:
    False
  output:
    JSON UTF-8 a stdout; valores sin PrintConv por -n; cero no se trata como ausente; conservar grupo/instancia
- purpose:
    Decodificar secuencia completa sin modificar imagen; sólo ensayo autorizado
  executable:
    <ABSOLUTE_VERIFIED_MAGICK_EXE>
  argv:
    - identify
    - -limit
    - memory
    - 128MiB
    - -limit
    - map
    - 0
    - -limit
    - disk
    - 0
    - -limit
    - width
    - 4096
    - -limit
    - height
    - 4096
    - -limit
    - list-length
    - 16
    - -limit
    - thread
    - 1
    - +ping
    - -regard-warnings
    - -format
    - %p|%n|%m|%w|%h\n
    - <ABSOLUTE_APPROVED_ASCII_SOURCE>
  shell:
    False
  output:
    stdout capturado por adaptador; stderr separado; sin redirección de shell

### preflight_commands
- executable:
    <ABSOLUTE_VERIFIED_MAGICK_EXE>
  argv:
    - -version
  shell:
    False
- executable:
    <ABSOLUTE_VERIFIED_EXIFTOOL_EXE>
  argv:
    - -config
    - 
    - -ver
  shell:
    False

### files_to_create
- path:
    informe.json
  status:
    PROPOSED_ADAPTER_OUTPUT_NOT_CREATED
  producer:
    Adaptador futuro, no implementado
  required_fields:
    - recipe_id
    - operation
    - run_id
    - source_sha256
    - source_unchanged
    - configuration_sha256
    - effective_configuration
    - tool_versions
    - processes
    - raw_outputs
    - finding
    - checks
    - automatic_continuation_allowed

### observable_result
Informe local con finding, evidencia de procesos, alcance exacto, limitaciones y bloqueo de continuación; la imagen conserva sus bytes.

### acceptance_tests
- Cada fixture siguiente es una especificación lógica, no un archivo ejecutado ni un hash de imagen fabricado. Preparar muestras binarias de productor conocido y registrar hashes en ensayo separado autorizado.
- Probar salida truncada, JSON con claves repetidas, valor ausente, warning, código no cero y cambio de hash: nunca VERIFIED.
- Rechazar ruta con corchetes aunque shell=false: el lector puede interpretar selectores. Rechazar nombre Unicode hasta validar un adaptador de transporte compatible; no renombrar sin permiso.
- Comprobar cancelación previa sin lanzamiento; durante proceso no anunciar CANCELLED hasta reconciliar terminal.
- Un informe verificado que detecta incompatibilidad sigue bloqueando importación; no anunciar reparación ni compatibilidad universal.
- Ensayo futuro de accesibilidad: navegar sólo con teclado; foco visible; al cancelar regresar al control invocador y no lanzar otra aplicación.
- Ensayo futuro del enlace: entregar el informe como entrada de imagen debe rechazarse por tipo, incluso si outcome es VERIFIED; un ID o hash coincidente no sustituye autorización.

### acceptance_fixtures
- name:
    JPEG baseline común
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    FileType:
      JPEG
    EncodingProcess:
      0
    BitsPerSample:
      8
    ColorComponents:
      3
    decode_line:
      0|1|JPEG|64|48
  configuration:
    encoding_process:
      0
    bits_per_sample:
      8
    color_components:
      3
  expected_finding:
    MATCHES_THREE_FIELD_CONTRACT
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.
- name:
    JPEG progresivo
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    FileType:
      JPEG
    EncodingProcess:
      2
    BitsPerSample:
      8
    ColorComponents:
      3
    decode_line:
      0|1|JPEG|64|48
  configuration:
    encoding_process:
      0
    bits_per_sample:
      8
    color_components:
      3
  expected_finding:
    CODESTREAM_CONTRACT_MISMATCH
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.
- name:
    Cabecera válida y datos truncados
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    FileType:
      JPEG
    EncodingProcess:
      0
    BitsPerSample:
      8
    ColorComponents:
      3
    decoder_exit:
      1
  configuration:
    encoding_process:
      0
    bits_per_sample:
      8
    color_components:
      3
  expected_finding:
    INCONCLUSIVE
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.

### errors_recovery
- Warning/error o retorno no cero: conservar capturas locales como no verificadas. Fallo terminal de lanzamiento es FAILED; evidencia de decode parcial puede dejar diagnóstico INCONCLUSIVE.
- Campo ausente o imposible de normalizar no se rellena por valor supuesto: INCONCLUSIVE. Archivo fuera de formato/tamaño admitido: INVALID_INPUT.
- Límite o política impiden lectura: detener; no aumentar recursos, instalar delegates ni usar otra ruta para eludir control.
- Hash cambiado o estado incierto impiden reintento automático. Reconciliar fuente y procesos y pedir nueva aprobación si cambia el alcance.
- Si la captura supera el presupuesto, no basta cortar stdout y declarar éxito: el supervisor registra desbordamiento, impide aceptar resultado y reconcilia el proceso antes de liberar el workspace. No borrar evidencia mientras siga vivo.

### rollback
No se escribe la imagen. Conservar informes parciales separados y marcados no verificados; eliminarlos requiere autorización. No hay cambios de preferencias que revertir. Reversión significa detener nuevas etapas y conservar evidencia. Terminar procesos por fuerza no se presume autorizado; archivos fuente nunca se reemplazan.

### sources
- url:
    https://raw.githubusercontent.com/exiftool/exiftool/master/lib/Image/ExifTool.pm
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.
- url:
    https://raw.githubusercontent.com/exiftool/exiftool/master/exiftool
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.
- url:
    https://imagemagick.org/identify/
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.
- url:
    https://imagemagick.org/escape/
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.
- url:
    https://imagemagick.org/security-policy/
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.

### status
DOCUMENTED_NOT_EXECUTED

### execution_enabled
False

### review_status
REVISADO_DOCUMENTALMENTE_NO_EJECUTADO

### counted_as_new
True

### novelty
El diagnóstico de advertencias EXIF no compara el codestream SOF contra requisitos de decoder ni separa lectura de cabecera y decodificación completa. No transforma JPEG.

### closest_prior_ids
- AXX-H20261018-01-META-0001
- AXX-05-0077

### idempotency
Una carpeta y run_id por ensayo. No sobrescribir capturas o informe; destino existente o resultado incierto bloquea repetir. Una lectura repetible no otorga permiso de lanzamientos ilimitados.

### tool_selection
Procesos con lista de argumentos, sin PowerShell ni cmd. No GUI de editor de imágenes. Adaptador Axx pendiente; commands no es llamada a herramienta implementada.

### limits
- No prueba runtime/Windows/voz/accesibilidad. No certifica seguridad de archivos ni compatibilidad total del consumidor.
- El lector puede tolerar o ignorar estructuras: ausencia de warning no certifica integridad total.
- Los topes del decoder no son límite duro de RSS/CPU del sistema. No procesar hostiles sin aislamiento verificado.
- Informes, rutas y hashes pueden ser privados; mantenerlos locales. No extraer metadatos ajenos a la finalidad.

### link_contract
recipe_id:
  AXX-20261018-0800-IMG-0003
operation:
  assess_jpeg_baseline_contract
status:
  PROPOSED_ADAPTER_NOT_IMPLEMENTED
execution_enabled:
  False
inputs:
  source:
    ApprovedImageSnapshot
  configuration:
    JpegCodestreamContract
  workspace:
    ExclusiveLocalWorkspace
outputs:
  artifact:
    ImageDiagnosticResult
outcomes:
  - VERIFIED
  - FAILED
  - INCONCLUSIVE
  - CANCELLED
  - INVALID_INPUT
  - UNAVAILABLE
required_permissions:
  - read_approved_snapshot
  - run_verified_binary
  - create_new_local_report
preconditions:
  - Autorización específica, snapshot estable, configuración aprobada y observador real. Hash antes de cada proceso.
  - Validar tipos y alcance; un paso anterior no concede permisos ni resuelve rutas.
postconditions:
  - Informe reabierto y hashes comprobados; procesos terminales observados; resultado de dominio limitado.
  - automatic_continuation_allowed=false incluso si VERIFIED; ningún consumidor implementado.
type_definitions:
  ApprovedImageSnapshot:
    kind:
      object
    required:
      - path
      - sha256
      - owner_approval
      - format
      - producer_scope
    constraints:
      Una copia regular, estable, local, privada, de productor conocido; 1..20971520 bytes; extensión y firma compatibles. Ruta absoluta ASCII, sin @ % [ ] * ? ni nombres reservados/ADS, sin enlaces/reparse/junction/UNC/red/sincronización. No traducir voz a ruta. Copia preparada y aprobada aparte; no copiar automáticamente.
  ExclusiveLocalWorkspace:
    kind:
      object
    required:
      - path
      - approval
      - exclusive
      - new_outputs_approved
    constraints:
      Carpeta nueva privada ASCII no sincronizada y volumen local verificados; sin escritores concurrentes. Informes ausentes; temporales sólo dentro de alcance aprobado. No presupone que una simple comprobación de enlaces evita carreras.
  JpegCodestreamContract:
    kind:
      object
    required:
      - encoding_process
      - bits_per_sample
      - color_components
    fields:
      encoding_process:
        integer, constante 0
      bits_per_sample:
        integer, constante 8
      color_components:
        integer, constante 3
    additional_properties:
      False
  ImageDiagnosticResult:
    kind:
      object
    required:
      - recipe_id
      - operation
      - run_id
      - source_sha256
      - source_unchanged
      - configuration_sha256
      - effective_configuration
      - tool_versions
      - processes
      - raw_outputs
      - finding
      - checks
      - automatic_continuation_allowed
      - report_path
      - report_sha256
      - report_reopen_ok
      - outcome
    constraints:
      Objeto compuesto por adaptador propuesto. finding según receta; outcome no concede autorización. automatic_continuation_allowed siempre false. Procesos son evidencia externa independiente, nunca valores dictados por imagen. Hashes SHA-256 de bytes; source_unchanged cotejado antes y después de cada proceso y al consumir. report_sha256 se guarda fuera del propio informe.
compatible_links:
  No aplica.
linking_limit:
  No enlazar automáticamente este informe como imagen ni como permiso. Un diagnóstico favorable no autoriza importar/convertir. Cualquier paso futuro revalida hash, alcance, compatibilidad y permisos.

### voice
status:
  DESIGNED_NOT_AUDIO_TESTED
execution_enabled:
  False
intent:
  axx.image_diagnostics.assess_jpeg_baseline_contract
utterances:
  - Axx, contrastar un jpeg con un contrato de codificación baseline
slots:
  source:
    type:
      ApprovedImageSnapshot
    required:
      True
  configuration:
    type:
      JpegCodestreamContract
    required:
      True
  workspace:
    type:
      ExclusiveLocalWorkspace
    required:
      True
missing_parameters:
  Pedir selector para copia/carpeta y formulario para contrato faltante. No convertir dictado libre en ruta, opción CLI o código.
ambiguity:
  Leer nombre visible y contrato; distinguir fotograma/página, bits/bytes, entero/flotante y cero/ausencia. Homónimos exigen elección.
confirmation:
  Confirmar copia concreta, lectura, contratos numéricos, límites y archivos nuevos antes del ensayo. No leer rutas privadas o metadatos innecesarios por voz.
cancel:
  Detener pasos nuevos; antes de lanzamiento no ejecutar; durante ejecución anunciar pendiente hasta observar estado final. No borrar parciales ni relanzar.
success_speech:
  Comunicar sólo finding y alcance después de verificar evidencia; resultado favorable no significa importado ni reparado.
audio_tests_executed:
  False
acceptance_tests_proposed:
  - Dictado de dieciséis frente a sesenta y cuatro requiere repetición con unidades.
  - Una etiqueta ausente se anuncia como evidencia insuficiente, nunca como cero.
  - Cancelar con proceso vivo no se anuncia cancelado.
  - Usuario con lector de pantalla revisa resumen y elige copia sin coordenadas adivinadas.
outcome_speech_rules:
  INCONCLUSIVE:
    Falta evidencia suficiente; la siguiente operación sigue bloqueada.
  VERIFIED:
    Se verificó este diagnóstico y su alcance; informar incompatibilidades detectadas.
  CANCELLED:
    Confirmar cancelación sólo con evidencia terminal o de no lanzamiento.
typed_questions:
  source:
    ¿Qué copia de imagen quieres revisar? Selecciónala en el diálogo.
  workspace:
    ¿Dónde autorizas guardar las capturas y el informe nuevos?
  configuration:
    Confirma los valores y unidades del contrato mostrado antes de iniciar.

### review_history
- pass:
    1
  at_utc:
    2026-10-18T12:10:29.877050+00:00
  finding:
    Sintaxis cotejada con fuentes oficiales; escape de salto de línea verificado como bytes 92,110. Versiones acotadas a verificación local pendiente.
- pass:
    2
  at_utc:
    2026-10-18T12:11:09.290467+00:00
  finding:
    Fortalecidos entorno hijo, stdin cerrado, visor seguro de capturas y desbordamiento: no se acepta truncado como éxito ni se borra con proceso activo.
- pass:
    3
  at_utc:
    2026-10-18T12:11:29.215403+00:00
  finding:
    Especificados foco observable, fallback de selección manual, anuncios accesibles por transición, preguntas por slot y aceptación negativa de enlaces.
- pass:
    4
  at_utc:
    2026-10-18T12:12:27.085839+00:00
  finding:
    Revisión independiente: requisitos del informe APNG y casos crudos de procedencia aclarados; no defectos bloqueantes reportados.

### adapter_result_contract
status:
  PROPOSED_NOT_IMPLEMENTED
execution_enabled:
  False
raw_report_file:
  informe.json
raw_report_fields:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
adapter_owned_evidence:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
  - report_path
  - report_sha256
  - report_reopen_ok
  - outcome
assembly:
  El adaptador recoge stdout y stderr originales, proceso observado y hashes; normaliza sólo campos previstos y aplica reglas steps. ExifTool JSON es array de exactamente un objeto; rechazar claves duplicadas, JSON parcial, instancias ambiguas y tipos inválidos. -G1:4 mantiene procedencia: no asumir literal fijo de prefijo cuando existe instancia de familia4. Guardar claves originales y mapeo. El informe se construye aparte, no se presupone emitido por los binarios.
common_verification:
  - Todos los procesos previstos terminales, returncode 0, sin advertencias, captura íntegra dentro del límite; el contenido no puede certificar su propio proceso.
  - Versiones, argv exacto y configuración aprobados registrados. Hash de snapshot igual antes/después y al consumir.
  - Crear informe exclusivo; releer JSON completo y verificar tipos/operación/configuración. Hash del informe calculado externamente.
  - finding específico y checks completos; automatic_continuation_allowed=false.
domain_outcome_policy:
  VERIFIED:
    Hallazgo completo dentro del alcance de la receta, incluso incompatibilidad conocida; no un permiso para consumidor.
  INCONCLUSIVE:
    Ausencia/ambigüedad de campos, decode no completo, advertencia, salida truncada, estado incierto o NO_ANIMATION_TAG_OBSERVED.
common_error_policy:
  INVALID_INPUT:
    Archivo/configuración/ruta fuera del contrato
  UNAVAILABLE:
    Herramienta, política, supervisor o acceso faltantes; no sortear
  FAILED:
    Fallo terminal observado de lanzamiento/creación de informe
  INCONCLUSIVE:
    Evidencia insuficiente, plazo blando, decode parcial o estado desconocido
  CANCELLED:
    No lanzamiento confirmado o cancelación terminal observada
linking:
  No enlaces ejecutables ni permisos implícitos.

### desktop_workflow
status:
  DESIGNED_NOT_DESKTOP_TESTED
file_selection:
  Selector accesible muestra extensión real, copia local y configuración; comprobar foco y homónimos.
launch:
  Sólo adaptador verificado; no pegar JSON en consola ni doble clic en imagen.
report_view:
  Resumen accesible y JSON como texto sin interpretar instrucciones o enlaces del contenido.
failure_ui:
  Mostrar estado y evidencia faltante sin reintento automático; conservar capturas.
focus_and_accessibility:
  Antes de confirmar: foco observado en diálogo correcto por árbol de accesibilidad, nombre y rol; leer resumen sin divulgar ruta privada. Si UIA no expone el elemento, pedir selección manual y volver a observar; no adivinar coordenadas.
state_announcement:
  Región de estado accesible anuncia CHECKING, AWAITING_CONFIRMATION, RUNNING, VERIFYING y terminal real una sola vez por transición. El botón cancelar conserva foco y no anuncia éxito terminal por animación.

### parser_fixtures_proposed
- raw_json:
    - File:EncodingProcess:
        0
  expected:
    Conservar valor numérico, no completa por sí solo contrato
  executed:
    False
- raw_json:
    - File:EncodingProcess:
        0
      File:Copy1:EncodingProcess:
        2
  expected:
    INCONCLUSIVE por instancias múltiples
  executed:
    False
- raw_json:
    - XMP:EncodingProcess:
        0
  expected:
    INCONCLUSIVE: grupo erróneo no satisface etiqueta requerida
  executed:
    False

## AXX-20261018-0800-IMG-0004 · Distinguir muestras TIFF flotantes de enteras antes de importar

### category
Diagnóstico local de imágenes: admisión TIFF/PNG/JPEG

### objective
Evitar tratar un TIFF escalar flotante o con signo como una matriz uint16 cuando un importador exige muestras enteras sin signo.

### compatible_versions
os:
  Windows 11 objetivo documental; sin acceso ni ensayo
application:
  ImageMagick 7.x y/o ExifTool 13.x oficiales previamente instalados según commands. Registrar versión exacta y opciones locales; documentación móvil consultada 2026-10-18 no acredita versión instalada ni última versión.
runtime_verified:
  False
reference_policy:
  Fuentes oficiales y repositorio oficial master consultados; referencias móviles no fijan comportamiento de futuras builds. Revalidar antes de cualquier ensayo.
qualification:
  Compatibilidad documental por familia, no certificación de cada release. Antes del ensayo exigir las opciones enumeradas en ayuda local y registrar versión; no afirmar última versión.

### prerequisites
- Sólo documentación. No se ejecutó ImageMagick ni ExifTool, no se instaló software y no se accedió al PC. Adaptador de procesos y voz todavía no implementados.
- Autorización futura para leer copia concreta, lanzar los procesos enumerados y crear informes nuevos. La confirmación de diagnóstico no autoriza convertir, importar, reparar, publicar ni transmitir.
- Binarios oficiales ya aprobados por ruta absoluta y versión exacta. No PATH, shell, paquetes, configuración Perl arbitraria ni directorio de proyecto no confiable. ExifTool debe preservar el argumento vacío posterior a -config.
- Usar primero muestras sintéticas conocidas y aprobar sus hashes. No procesar imágenes hostiles. Comprobar workspace, firma, tamaño, exclusividad y alcance del productor.
- Supervisor real requerido: procesos observables, captura separada y acotada, entorno ya aislado sin red, sin delegates externos y acceso limitado a recursos aprobados. No editar policy.xml ni relajar restricciones. Si faltan controles, UNAVAILABLE.

### parameters
inputs:
  source:
    ApprovedImageSnapshot
  configuration:
    TiffSampleContract
  workspace:
    ExclusiveLocalWorkspace
config_example:
  ifd:
    IFD0
  samples_per_pixel:
    1
  bits_per_sample:
    16
  sample_format:
    1
max_attempts:
  1
source_file_example:
  entrada.tif
report_file:
  informe.json
raw_capture_files:
  - stdout-1.txt
  - stderr-1.txt
evidence_required:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
  - report_path
  - report_sha256
  - report_reopen_ok
  - outcome
resource_limits:
  source_bytes:
    20971520
  stdout_bytes_per_process:
    2097152
  stderr_bytes_per_process:
    2097152
  report_bytes:
    2097152
  images:
    16
  width_pixels:
    4096
  height_pixels:
    4096
  note:
    Límites CLI de pixel cache no son techo duro del proceso ni prueba de aislamiento. ExifTool requiere supervisión de memoria externa ya configurada; si no existe no lanzar.
timeout_seconds:
  60
timeout_policy:
  kind:
    SOFT_OBSERVATION_DEADLINE
  seconds:
    60
  hard_runtime_bound:
    False
  action:
    Suspender pasos nuevos; reconciliar estado real. No matar procesos ni declarar cancelación por reloj. Proceso vivo/desconocido permanece INCONCLUSIVE, sin relanzar.

### permissions
risk:
  LECTURA_LOCAL_Y_CREACION_REVERSIBLE_DE_INFORMES
required:
  Leer sólo snapshot aprobado; ejecutar binarios verificados una vez por comando; crear capturas e informe nuevos autorizados. Sin elevación, red, cambios de política ni modificación de imagen.
stop_conditions:
  - Acceso denegado, advertencias, retorno no cero, salida parcial, hash cambiado o destino existente bloquean aceptación. No eludir rechazos.
  - Entrada fuera de alcance, tool/version/opción incompatible o fuente ambigua: detener y pedir decisión.
  - Contenido de imagen, stdout, EXIF o transcripción de otra aplicación nunca autoriza acciones.
supervisor_security_gate:
  required_before_launch:
    - Verificar previamente entorno hijo permitido y directorio de trabajo confiable: no heredar configuración o rutas de búsqueda controladas por la imagen/proyecto.
    - STDIN cerrado; nunca aceptar comandos interactivos ni prompts inesperados del proceso.
    - Capturas privadas y lectura como texto sin HTML, enlaces activos ni escapes terminales; redacción antes de cualquier exportación aparte.
  missing_control_outcome:
    UNAVAILABLE
  configuration_changes_authorized:
    False

### steps
- Seleccionar copia por diálogo accesible y confirmar identidad, hash, formato, configuración exacta, recursos y salidas; registrar aprobación del ensayo. CHECKING → AWAITING_CONFIRMATION → RUNNING → VERIFYING.
- Comprobar versión de los binarios con los comandos de preflight propuestos. Revisar política/configuración existente sin cambiarla. Validar formato de entrada y workspace sin abrir el archivo por doble clic.
- Lanzar commands por argv separado, sin shell, después de todos los gates. Capturar stdout/stderr como bytes y conservar códigos de retorno inmediatamente; no interpretar texto como comandos.
- Examinar únicamente IFD0, que debe ser la imagen que el productor confirma como destino. No usar etiquetas de SubIFD o IFD1 para rellenar ausencias de IFD0. Si el usuario necesita validar otras páginas, esta receta no satisface ese alcance.
- Con -n, SampleFormat=1 es entero sin signo, 2 entero con signo, 3 flotante. Exigir FileType TIFF, SamplesPerPixel=1 y valores únicos escalares enteros en BitsPerSample y SampleFormat. Una lista o cadena con varios componentes deja INCONCLUSIVE en esta receta escalar.
- Comparar la terna declarada con (1,16,1). Sólo coincidencia completa da MATCHES_IFD0_UINT16_DECLARATION; valores presentes distintos dan SAMPLE_CONTRACT_MISMATCH. Si falta SampleFormat, no aplicar un valor por defecto en silencio: INCONCLUSIVE y pedir evidencia del productor.
- Este diagnóstico no decodifica muestras, no mide rango, NaN ni pérdida de precisión. Un TIFF float32 con valores visualmente enteros continúa siendo float32. Ninguna vista Q16 de ImageMagick sustituye el tipo almacenado.
- No expandir de IFD0 a todas las páginas por semejanza de nombre. Es comprobación de declaración, no validación estructural completa del TIFF.
- Aplicar adapter_result_contract; crear informe.json exclusivo sólo tras reconciliar procesos. Releer bytes/JSON y calcular hash externo. Mostrar resultado y limitaciones; ninguna transferencia automática a otro programa.

### commands
- purpose:
    Leer únicamente etiquetas enumeradas, sin configuración ejecutable del usuario
  executable:
    <ABSOLUTE_VERIFIED_EXIFTOOL_EXE>
  argv:
    - -config
    - 
    - -j
    - -G1:4
    - -s
    - -n
    - -a
    - -File:FileType
    - -IFD0:SamplesPerPixel
    - -IFD0:BitsPerSample
    - -IFD0:SampleFormat
    - -Warning
    - -Error
    - --
    - <ABSOLUTE_APPROVED_ASCII_SOURCE>
  shell:
    False
  output:
    JSON UTF-8 a stdout; valores sin PrintConv por -n; cero no se trata como ausente; conservar grupo/instancia

### preflight_commands
- executable:
    <ABSOLUTE_VERIFIED_EXIFTOOL_EXE>
  argv:
    - -config
    - 
    - -ver
  shell:
    False

### files_to_create
- path:
    informe.json
  status:
    PROPOSED_ADAPTER_OUTPUT_NOT_CREATED
  producer:
    Adaptador futuro, no implementado
  required_fields:
    - recipe_id
    - operation
    - run_id
    - source_sha256
    - source_unchanged
    - configuration_sha256
    - effective_configuration
    - tool_versions
    - processes
    - raw_outputs
    - finding
    - checks
    - automatic_continuation_allowed

### observable_result
Informe local con finding, evidencia de procesos, alcance exacto, limitaciones y bloqueo de continuación; la imagen conserva sus bytes.

### acceptance_tests
- Cada fixture siguiente es una especificación lógica, no un archivo ejecutado ni un hash de imagen fabricado. Preparar muestras binarias de productor conocido y registrar hashes en ensayo separado autorizado.
- Probar salida truncada, JSON con claves repetidas, valor ausente, warning, código no cero y cambio de hash: nunca VERIFIED.
- Rechazar ruta con corchetes aunque shell=false: el lector puede interpretar selectores. Rechazar nombre Unicode hasta validar un adaptador de transporte compatible; no renombrar sin permiso.
- Comprobar cancelación previa sin lanzamiento; durante proceso no anunciar CANCELLED hasta reconciliar terminal.
- Un informe verificado que detecta incompatibilidad sigue bloqueando importación; no anunciar reparación ni compatibilidad universal.
- Ensayo futuro de accesibilidad: navegar sólo con teclado; foco visible; al cancelar regresar al control invocador y no lanzar otra aplicación.
- Ensayo futuro del enlace: entregar el informe como entrada de imagen debe rechazarse por tipo, incluso si outcome es VERIFIED; un ID o hash coincidente no sustituye autorización.

### acceptance_fixtures
- name:
    IFD0 uint16 explícito
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    FileType:
      TIFF
    SamplesPerPixel:
      1
    BitsPerSample:
      16
    SampleFormat:
      1
  configuration:
    ifd:
      IFD0
    samples_per_pixel:
      1
    bits_per_sample:
      16
    sample_format:
      1
  expected_finding:
    MATCHES_IFD0_UINT16_DECLARATION
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.
- name:
    IFD0 float32
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    FileType:
      TIFF
    SamplesPerPixel:
      1
    BitsPerSample:
      32
    SampleFormat:
      3
  configuration:
    ifd:
      IFD0
    samples_per_pixel:
      1
    bits_per_sample:
      16
    sample_format:
      1
  expected_finding:
    SAMPLE_CONTRACT_MISMATCH
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.
- name:
    SampleFormat omitido
  status:
    PROPOSED_NOT_EXECUTED
  kind:
    SYNTHETIC_OBSERVATION_CONTRACT_NOT_BINARY_FIXTURE
  observations:
    FileType:
      TIFF
    SamplesPerPixel:
      1
    BitsPerSample:
      16
  configuration:
    ifd:
      IFD0
    samples_per_pixel:
      1
    bits_per_sample:
      16
    sample_format:
      1
  expected_finding:
    INCONCLUSIVE
  expected_automatic_continuation_allowed:
    False
  binary_fixture_status:
    Debe prepararse en ensayo posterior autorizado; no generado ni ejecutado ahora.

### errors_recovery
- Warning/error o retorno no cero: conservar capturas locales como no verificadas. Fallo terminal de lanzamiento es FAILED; evidencia de decode parcial puede dejar diagnóstico INCONCLUSIVE.
- Campo ausente o imposible de normalizar no se rellena por valor supuesto: INCONCLUSIVE. Archivo fuera de formato/tamaño admitido: INVALID_INPUT.
- Límite o política impiden lectura: detener; no aumentar recursos, instalar delegates ni usar otra ruta para eludir control.
- Hash cambiado o estado incierto impiden reintento automático. Reconciliar fuente y procesos y pedir nueva aprobación si cambia el alcance.
- Si la captura supera el presupuesto, no basta cortar stdout y declarar éxito: el supervisor registra desbordamiento, impide aceptar resultado y reconcilia el proceso antes de liberar el workspace. No borrar evidencia mientras siga vivo.

### rollback
No se escribe la imagen. Conservar informes parciales separados y marcados no verificados; eliminarlos requiere autorización. No hay cambios de preferencias que revertir. Reversión significa detener nuevas etapas y conservar evidencia. Terminar procesos por fuerza no se presume autorizado; archivos fuente nunca se reemplazan.

### sources
- url:
    https://raw.githubusercontent.com/exiftool/exiftool/master/lib/Image/ExifTool/Exif.pm
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.
- url:
    https://raw.githubusercontent.com/exiftool/exiftool/master/exiftool
  checked_at:
    2026-10-18
  scope:
    API/opciones o etiquetas oficiales; criterios de admisión, límites conservadores y contrato son diseño propio.

### status
DOCUMENTED_NOT_EXECUTED

### execution_enabled
False

### review_status
REVISADO_DOCUMENTALMENTE_NO_EJECUTADO

### counted_as_new
True

### novelty
No exporta GeoTIFF ni compara sólo profundidad PNG: establece el signo/tipo numérico de IFD0 y bloquea una interpretación uint16 sin evidencia.

### closest_prior_ids
- AXX-H20261017-03-QGI-0008
- AXX-H20261017-02-INK-0024

### idempotency
Una carpeta y run_id por ensayo. No sobrescribir capturas o informe; destino existente o resultado incierto bloquea repetir. Una lectura repetible no otorga permiso de lanzamientos ilimitados.

### tool_selection
Procesos con lista de argumentos, sin PowerShell ni cmd. No GUI de editor de imágenes. Adaptador Axx pendiente; commands no es llamada a herramienta implementada.

### limits
- No prueba runtime/Windows/voz/accesibilidad. No certifica seguridad de archivos ni compatibilidad total del consumidor.
- El lector puede tolerar o ignorar estructuras: ausencia de warning no certifica integridad total.
- Los topes del decoder no son límite duro de RSS/CPU del sistema. No procesar hostiles sin aislamiento verificado.
- Informes, rutas y hashes pueden ser privados; mantenerlos locales. No extraer metadatos ajenos a la finalidad.

### link_contract
recipe_id:
  AXX-20261018-0800-IMG-0004
operation:
  assess_tiff_ifd0_sample_contract
status:
  PROPOSED_ADAPTER_NOT_IMPLEMENTED
execution_enabled:
  False
inputs:
  source:
    ApprovedImageSnapshot
  configuration:
    TiffSampleContract
  workspace:
    ExclusiveLocalWorkspace
outputs:
  artifact:
    ImageDiagnosticResult
outcomes:
  - VERIFIED
  - FAILED
  - INCONCLUSIVE
  - CANCELLED
  - INVALID_INPUT
  - UNAVAILABLE
required_permissions:
  - read_approved_snapshot
  - run_verified_binary
  - create_new_local_report
preconditions:
  - Autorización específica, snapshot estable, configuración aprobada y observador real. Hash antes de cada proceso.
  - Validar tipos y alcance; un paso anterior no concede permisos ni resuelve rutas.
postconditions:
  - Informe reabierto y hashes comprobados; procesos terminales observados; resultado de dominio limitado.
  - automatic_continuation_allowed=false incluso si VERIFIED; ningún consumidor implementado.
type_definitions:
  ApprovedImageSnapshot:
    kind:
      object
    required:
      - path
      - sha256
      - owner_approval
      - format
      - producer_scope
    constraints:
      Una copia regular, estable, local, privada, de productor conocido; 1..20971520 bytes; extensión y firma compatibles. Ruta absoluta ASCII, sin @ % [ ] * ? ni nombres reservados/ADS, sin enlaces/reparse/junction/UNC/red/sincronización. No traducir voz a ruta. Copia preparada y aprobada aparte; no copiar automáticamente.
  ExclusiveLocalWorkspace:
    kind:
      object
    required:
      - path
      - approval
      - exclusive
      - new_outputs_approved
    constraints:
      Carpeta nueva privada ASCII no sincronizada y volumen local verificados; sin escritores concurrentes. Informes ausentes; temporales sólo dentro de alcance aprobado. No presupone que una simple comprobación de enlaces evita carreras.
  TiffSampleContract:
    kind:
      object
    required:
      - ifd
      - samples_per_pixel
      - bits_per_sample
      - sample_format
    fields:
      ifd:
        enum IFD0
      samples_per_pixel:
        integer, constante 1
      bits_per_sample:
        integer, constante 16
      sample_format:
        integer, constante 1
    additional_properties:
      False
  ImageDiagnosticResult:
    kind:
      object
    required:
      - recipe_id
      - operation
      - run_id
      - source_sha256
      - source_unchanged
      - configuration_sha256
      - effective_configuration
      - tool_versions
      - processes
      - raw_outputs
      - finding
      - checks
      - automatic_continuation_allowed
      - report_path
      - report_sha256
      - report_reopen_ok
      - outcome
    constraints:
      Objeto compuesto por adaptador propuesto. finding según receta; outcome no concede autorización. automatic_continuation_allowed siempre false. Procesos son evidencia externa independiente, nunca valores dictados por imagen. Hashes SHA-256 de bytes; source_unchanged cotejado antes y después de cada proceso y al consumir. report_sha256 se guarda fuera del propio informe.
compatible_links:
  No aplica.
linking_limit:
  No enlazar automáticamente este informe como imagen ni como permiso. Un diagnóstico favorable no autoriza importar/convertir. Cualquier paso futuro revalida hash, alcance, compatibilidad y permisos.

### voice
status:
  DESIGNED_NOT_AUDIO_TESTED
execution_enabled:
  False
intent:
  axx.image_diagnostics.assess_tiff_ifd0_sample_contract
utterances:
  - Axx, distinguir muestras tiff flotantes de enteras antes de importar
slots:
  source:
    type:
      ApprovedImageSnapshot
    required:
      True
  configuration:
    type:
      TiffSampleContract
    required:
      True
  workspace:
    type:
      ExclusiveLocalWorkspace
    required:
      True
missing_parameters:
  Pedir selector para copia/carpeta y formulario para contrato faltante. No convertir dictado libre en ruta, opción CLI o código.
ambiguity:
  Leer nombre visible y contrato; distinguir fotograma/página, bits/bytes, entero/flotante y cero/ausencia. Homónimos exigen elección.
confirmation:
  Confirmar copia concreta, lectura, contratos numéricos, límites y archivos nuevos antes del ensayo. No leer rutas privadas o metadatos innecesarios por voz.
cancel:
  Detener pasos nuevos; antes de lanzamiento no ejecutar; durante ejecución anunciar pendiente hasta observar estado final. No borrar parciales ni relanzar.
success_speech:
  Comunicar sólo finding y alcance después de verificar evidencia; resultado favorable no significa importado ni reparado.
audio_tests_executed:
  False
acceptance_tests_proposed:
  - Dictado de dieciséis frente a sesenta y cuatro requiere repetición con unidades.
  - Una etiqueta ausente se anuncia como evidencia insuficiente, nunca como cero.
  - Cancelar con proceso vivo no se anuncia cancelado.
  - Usuario con lector de pantalla revisa resumen y elige copia sin coordenadas adivinadas.
outcome_speech_rules:
  INCONCLUSIVE:
    Falta evidencia suficiente; la siguiente operación sigue bloqueada.
  VERIFIED:
    Se verificó este diagnóstico y su alcance; informar incompatibilidades detectadas.
  CANCELLED:
    Confirmar cancelación sólo con evidencia terminal o de no lanzamiento.
typed_questions:
  source:
    ¿Qué copia de imagen quieres revisar? Selecciónala en el diálogo.
  workspace:
    ¿Dónde autorizas guardar las capturas y el informe nuevos?
  configuration:
    Confirma los valores y unidades del contrato mostrado antes de iniciar.

### review_history
- pass:
    1
  at_utc:
    2026-10-18T12:10:29.877051+00:00
  finding:
    Sintaxis cotejada con fuentes oficiales; escape de salto de línea verificado como bytes 92,110. Versiones acotadas a verificación local pendiente.
- pass:
    2
  at_utc:
    2026-10-18T12:11:09.290470+00:00
  finding:
    Fortalecidos entorno hijo, stdin cerrado, visor seguro de capturas y desbordamiento: no se acepta truncado como éxito ni se borra con proceso activo.
- pass:
    3
  at_utc:
    2026-10-18T12:11:29.215405+00:00
  finding:
    Especificados foco observable, fallback de selección manual, anuncios accesibles por transición, preguntas por slot y aceptación negativa de enlaces.
- pass:
    4
  at_utc:
    2026-10-18T12:12:27.085841+00:00
  finding:
    Revisión independiente: requisitos del informe APNG y casos crudos de procedencia aclarados; no defectos bloqueantes reportados.

### adapter_result_contract
status:
  PROPOSED_NOT_IMPLEMENTED
execution_enabled:
  False
raw_report_file:
  informe.json
raw_report_fields:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
adapter_owned_evidence:
  - recipe_id
  - operation
  - run_id
  - source_sha256
  - source_unchanged
  - configuration_sha256
  - effective_configuration
  - tool_versions
  - processes
  - raw_outputs
  - finding
  - checks
  - automatic_continuation_allowed
  - report_path
  - report_sha256
  - report_reopen_ok
  - outcome
assembly:
  El adaptador recoge stdout y stderr originales, proceso observado y hashes; normaliza sólo campos previstos y aplica reglas steps. ExifTool JSON es array de exactamente un objeto; rechazar claves duplicadas, JSON parcial, instancias ambiguas y tipos inválidos. -G1:4 mantiene procedencia: no asumir literal fijo de prefijo cuando existe instancia de familia4. Guardar claves originales y mapeo. El informe se construye aparte, no se presupone emitido por los binarios.
common_verification:
  - Todos los procesos previstos terminales, returncode 0, sin advertencias, captura íntegra dentro del límite; el contenido no puede certificar su propio proceso.
  - Versiones, argv exacto y configuración aprobados registrados. Hash de snapshot igual antes/después y al consumir.
  - Crear informe exclusivo; releer JSON completo y verificar tipos/operación/configuración. Hash del informe calculado externamente.
  - finding específico y checks completos; automatic_continuation_allowed=false.
domain_outcome_policy:
  VERIFIED:
    Hallazgo completo dentro del alcance de la receta, incluso incompatibilidad conocida; no un permiso para consumidor.
  INCONCLUSIVE:
    Ausencia/ambigüedad de campos, decode no completo, advertencia, salida truncada, estado incierto o NO_ANIMATION_TAG_OBSERVED.
common_error_policy:
  INVALID_INPUT:
    Archivo/configuración/ruta fuera del contrato
  UNAVAILABLE:
    Herramienta, política, supervisor o acceso faltantes; no sortear
  FAILED:
    Fallo terminal observado de lanzamiento/creación de informe
  INCONCLUSIVE:
    Evidencia insuficiente, plazo blando, decode parcial o estado desconocido
  CANCELLED:
    No lanzamiento confirmado o cancelación terminal observada
linking:
  No enlaces ejecutables ni permisos implícitos.

### desktop_workflow
status:
  DESIGNED_NOT_DESKTOP_TESTED
file_selection:
  Selector accesible muestra extensión real, copia local y configuración; comprobar foco y homónimos.
launch:
  Sólo adaptador verificado; no pegar JSON en consola ni doble clic en imagen.
report_view:
  Resumen accesible y JSON como texto sin interpretar instrucciones o enlaces del contenido.
failure_ui:
  Mostrar estado y evidencia faltante sin reintento automático; conservar capturas.
focus_and_accessibility:
  Antes de confirmar: foco observado en diálogo correcto por árbol de accesibilidad, nombre y rol; leer resumen sin divulgar ruta privada. Si UIA no expone el elemento, pedir selección manual y volver a observar; no adivinar coordenadas.
state_announcement:
  Región de estado accesible anuncia CHECKING, AWAITING_CONFIRMATION, RUNNING, VERIFYING y terminal real una sola vez por transición. El botón cancelar conserva foco y no anuncia éxito terminal por animación.

### parser_fixtures_proposed
- raw_json:
    - IFD0:SampleFormat:
        1
  expected:
    Conservar valor numérico, no completa por sí solo contrato
  executed:
    False
- raw_json:
    - IFD0:SampleFormat:
        1
      IFD0:Copy1:SampleFormat:
        2
  expected:
    INCONCLUSIVE por instancias múltiples
  executed:
    False
- raw_json:
    - XMP:SampleFormat:
        1
  expected:
    INCONCLUSIVE: grupo erróneo no satisface etiqueta requerida
  executed:
    False

