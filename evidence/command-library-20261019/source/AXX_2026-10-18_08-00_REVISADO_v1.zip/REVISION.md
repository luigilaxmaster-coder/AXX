# Revisión documental

Cuatro pasadas posteriores al borrador, registradas con hallazgos concretos y cambios en REVISION_CUATRO_PASADAS.json y CHANGELOG.json. La cuarta es independiente. Las verificaciones locales abarcan estructura, IDs, igualdad MD/JSONL, mapa de voz y hashes; no ejecución de las recetas ni pruebas del equipo Windows. Los escenarios de aceptación son propuestos.

Las páginas directas exiftool.org fallaron con 403; se contrastaron fuentes oficiales del repositorio. Las ramas master y documentación web son móviles. Revalidar versión local y opciones antes de habilitar. Ninguna receta se habilita por completar revisión documental. Los límites de recursos no certifican aislamiento de un archivo hostil. Capturas y resultado deben observarse realmente.
