# Enlaces y voz

Todos los IDs previos se conservan con sus estados; nuevos contratos tipados se incluyen en cada receta. Ningún adaptador ni audio individual se ha probado. No hay consumidores compatibles verificados: compatible_links está vacío y toda continuación automática está deshabilitada. Un informe no es una imagen ni un permiso. Los parámetros dictados no se interpolan en shell; selección accesible y confirmación preceden cualquier ensayo futuro. Las etiquetas de voz, mapas y tests añaden cero instrucciones al total.
