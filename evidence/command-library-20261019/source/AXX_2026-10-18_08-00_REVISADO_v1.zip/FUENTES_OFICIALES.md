# Fuentes oficiales consultadas, 2026-10-18

Se consultaron con la herramienta web; ningún binario de diagnóstico fue ejecutado. Las reglas de aceptación, voz, límites y aislamiento son diseño documental, no promesas del proveedor.

- https://imagemagick.org/identify/ : identify y +ping para lectura de píxeles; -format, -regard-warnings. script/identify.php redirige a esta página.
- https://imagemagick.org/escape/ : %p índice de lista, %n longitud de secuencia, %m formato, %w/%h dimensiones. No confundir %p con %s.
- https://imagemagick.org/security-policy/ : límites de recursos y restricciones; no se modifica política.
- https://raw.githubusercontent.com/exiftool/exiftool/master/exiftool : documentación oficial del ejecutable. -config vacío desactiva configuración por defecto; JSON, nombres de grupo/instancia y -n. Rama móvil: cotejar versión instalada.
- https://raw.githubusercontent.com/exiftool/exiftool/master/lib/Image/ExifTool/PNG.pm : AnimationControl: AnimationFrames y AnimationPlays; extracción puede designar FileType APNG.
- https://raw.githubusercontent.com/exiftool/exiftool/master/lib/Image/ExifTool.pm : tabla JPEG::SOF, grupo File; EncodingProcess 0 baseline, 2 progresivo; BitsPerSample y ColorComponents.
- https://raw.githubusercontent.com/exiftool/exiftool/master/lib/Image/ExifTool/Exif.pm : tabla SampleFormat: 1 sin signo, 2 con signo, 3 flotante, 4 indefinido, 5/6 complejos.

Transparencia de acceso: las aperturas directas a exiftool.org/TagNames/{PNG,JPEG,EXIF}.html y páginas pod devolvieron 403/error en esta sesión. La búsqueda mostró extractos oficiales, pero la evidencia primaria de valores y opciones se apoya en las lecturas exitosas del repositorio oficial anteriores. No se afirma haber abierto con éxito páginas bloqueadas.

## Novedad
Comparación leída de dedup_corpus.jsonl de 0700 y 0800 y recetas de 0700. Se revisaron especialmente ImageMagick 20261017-07, ExifTool META 20261018-01, conversiones AXX-05 y flujos GIS/PNG. Los cuatro resultados añaden gates de admisión distintos: secuencia TIFF heterogénea, descarte de animación APNG, contrato SOF JPEG y tipo escalar IFD0 TIFF. Testvectors históricos no cuentan como recetas nuevas.

## Límites de validación
Fixtures son contratos sintéticos de observaciones; no archivos binarios ni ensayos realizados. Ninguna prueba de Windows, decoder, voz o adaptador. Los cuatro registros permanecen DOCUMENTED_NOT_EXECUTED, execution_enabled:false.
