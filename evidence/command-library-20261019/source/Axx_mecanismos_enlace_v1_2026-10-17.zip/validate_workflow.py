#!/usr/bin/env python3
"""Offline design validator. No execution, subprocess, network, approval or runtime verifier.
Implements exactly the JSON Schema keywords used by workflow.schema.json, then
semantic graph/contract checks. Not a general JSON Schema implementation.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path
ROOT=Path(__file__).parent
class Invalid(ValueError): pass
def need(ok,msg):
 if not ok: raise Invalid(msg)
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def read(p):
 def unique(pairs):
  result={}
  for k,v in pairs:
   need(k not in result,'duplicate JSON key: '+k); result[k]=v
  return result
 return json.loads(Path(p).read_text(encoding='utf-8'),object_pairs_hook=unique,parse_constant=lambda x: (_ for _ in ()).throw(Invalid('non-finite number')))
def structural(value,s,path='$'):
 supported={'$schema','$id','title','type','properties','required','additionalProperties','oneOf','enum','const','items','minItems','maxItems','uniqueItems','minLength','pattern','minimum','maximum','minProperties'}
 need(set(s)<=supported,'unsupported schema keyword')
 if 'oneOf' in s:
  matches=0
  for candidate in s['oneOf']:
   try:structural(value,candidate,path); matches+=1
   except Invalid:pass
  need(matches==1,path+': oneOf requires exactly one shape')
 if 'const' in s:need(type(value)==type(s['const']) and value==s['const'],path+': wrong constant')
 if 'enum' in s:need(value in s['enum'],path+': unknown enumeration')
 types={'object':dict,'array':list,'string':str,'integer':int}
 if 'type' in s:need(type(value) is types[s['type']],path+': wrong JSON type')
 if isinstance(value,dict):
  need(len(value)>=s.get('minProperties',0),path+': too few properties')
  need(set(s.get('required',[]))<=set(value),path+': missing required fields')
  for k,v in value.items():
   child=s.get('properties',{}).get(k,s.get('additionalProperties',True))
   need(child is not False,path+': unknown field '+k)
   if isinstance(child,dict):structural(v,child,path+'.'+k)
 if isinstance(value,list):
  need(s.get('minItems',0)<=len(value)<=s.get('maxItems',float('inf')),path+': array size')
  if s.get('uniqueItems'):need(len({json.dumps(x,sort_keys=True) for x in value})==len(value),path+': duplicate array items')
  if 'items' in s:
   for i,v in enumerate(value):structural(v,s['items'],path+'['+str(i)+']')
 if isinstance(value,str):
  need(len(value)>=s.get('minLength',0),path+': empty string')
  if 'pattern' in s:need(re.search(s['pattern'],value) is not None,path+': pattern mismatch')
 if type(value) is int:need(s.get('minimum',-float('inf'))<=value<=s.get('maximum',float('inf')),path+': integer bound')
def validate(workflow,contracts,catalog,schema):
 structural(workflow,schema)
 records={}; cs={}
 for r in catalog['records']:
  need(r['id'] not in records,'duplicate catalog ID');records[r['id']]=r
  need(r['entry'].get('id')==r['id'],'catalog ID mismatch')
  need(r['entry'].get('execution_enabled') is False,'catalog execution enabled')
  need(digest(r['entry'])==r['entry_sha256'],'catalog entry hash mismatch')
 for c in contracts['contracts']:
  rid=c['recipe_id']; need(rid not in cs,'duplicate contract ID');cs[rid]=c
  need(rid in records,'contract missing catalog ID')
  need(c['source_sha256']==records[rid]['entry_sha256'],'contract hash mismatch')
  need(c['status']=='PROPOSED_ADAPTER_NOT_IMPLEMENTED' and c['execution_enabled'] is False,'contract runtime enabled')
  need(type(c['idempotent']) is bool and type(c['max_attempts']) is int and 1<=c['max_attempts']<=3,'invalid contract retry bound')
  need(c['idempotent'] or c['max_attempts']==1,'nonidempotent contract retries')
  need(all(type(c[k]) is list and c[k] and all(type(x) is str and x for x in c[k]) for k in ['effects','required_permissions','preconditions','postconditions','outcomes']),'contract metadata missing')
  need(len(c['outcomes'])==len(set(c['outcomes'])),'duplicate contract outcomes')
  for o in c['outputs'].values():need(o['available_on'] and set(o['available_on'])<=set(c['outcomes']),'invalid output outcomes')
 steps={}
 for s in workflow['steps']:
  need(s['id'] not in steps,'duplicate step ID');steps[s['id']]=s
  need(s['recipe_id'] in cs,'missing recipe ID')
  c=cs[s['recipe_id']]
  need(s['source_sha256']==c['source_sha256'],'step hash mismatch')
  need(set(s['inputs'])==set(c['inputs']),'unknown or missing input port')
  need(set(s['permissions'])==set(c['required_permissions']),'per-step permission requirements mismatch')
  n=s['retry']['max_attempts'];need(n<=c['max_attempts'],'retry exceeds contract bound')
  need(c['idempotent'] or n==1,'nonidempotent retry forbidden')
  need(set(s['on_outcome'])==set(c['outcomes']),'missing or unknown outcome route')
  good={x for o in c['outputs'].values() for x in o['available_on']}
  need(all(action=='HALT' for outcome,action in s['on_outcome'].items() if outcome not in good),'unverified outcomes must halt')
 for s in steps.values():
  need(set(s['depends_on'])<=set(steps),'unknown dependency')
  need(s['id'] not in s['depends_on'],'self dependency')
 visiting=set();done=set()
 def walk(sid):
  need(sid not in visiting,'dependency cycle')
  if sid in done:return
  visiting.add(sid)
  for dep in steps[sid]['depends_on']:walk(dep)
  visiting.remove(sid);done.add(sid)
 for sid in steps:walk(sid)
 for s in steps.values():
  c=cs[s['recipe_id']];guard=s.get('when')
  if guard:
   need(guard['step'] in s['depends_on'],'guard must be explicit dependency')
   origin=steps[guard['step']];oc=cs[origin['recipe_id']]
   need(guard['outcome'] in oc['outcomes'],'unknown guard outcome')
   need(origin['on_outcome'][guard['outcome']]=='CONTINUE','guard on halted outcome')
  for port,b in s['inputs'].items():
   expected=c['inputs'][port]
   if 'literal' in b:
    need(b['type']==expected,'literal type mismatch')
    need(expected not in ['GitOID','ZoteroAttachment','BlobPresenceChanges'],'verified artifact requires upstream reference')
    if expected=='HexPrefix':need(re.fullmatch('[0-9a-fA-F]{4,64}',b['literal']) is not None,'bad hex prefix')
    # Symbolic fixture paths only: not a filesystem safety certification.
    if expected in ['LocalRepo','LocalPDF','NewLocalPDF']:need(b['literal'].startswith('fixture/') and '..' not in b['literal'].split('/') and '\\' not in b['literal'],'only symbolic fixture paths allowed')
   else:
    need(b['from'] in s['depends_on'],'reference must be explicit dependency')
    source=steps[b['from']];sc=cs[source['recipe_id']]
    need(b['port'] in sc['outputs'],'unknown output port')
    output=sc['outputs'][b['port']]
    need(output['type']==expected,'reference type mismatch')
    need(guard and guard['step']==b['from'] and guard['outcome'] in output['available_on'],'reference lacks verified availability guard')
  # Enforce same symbolic repository across the demonstrated Git edge.
  if s['recipe_id']=='AXX-H20261016-19-GIT-0028' and 'from' in s['inputs']['oid']:
   source=steps[s['inputs']['oid']['from']]
   need(s['inputs']['repo']==source['inputs'].get('repo'),'Git repository scope mismatch')
 return {'valid':True,'execution_enabled':False,'runtime_verified':False,'steps':len(steps),'meaning':'Definition is structurally and semantically compatible with proposed contracts; no recipe or pre/postcondition was executed.'}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('workflow');p.add_argument('--contracts',default=str(ROOT/'contracts.json'));p.add_argument('--catalog',default=str(ROOT/'catalog_subset.json'));a=p.parse_args()
 try: result=validate(read(a.workflow),read(a.contracts),read(a.catalog),read(ROOT/'workflow.schema.json'))
 except (Invalid,KeyError,TypeError,ValueError,OSError) as e:print(json.dumps({'valid':False,'error':str(e)}));return 1
 print(json.dumps(result));return 0
if __name__=='__main__':raise SystemExit(main())
