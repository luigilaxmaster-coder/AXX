# Axx · Mecanismos de enlace de comandos

Complemento v1 · 17-10-2026 · **0 instrucciones nuevas contabilizadas**.

## Qué aporta

- Diseño de una capa que conecta recetas existentes en tareas de varios pasos.
- Contratos de entradas/salidas, dependencias y condiciones explícitas.
- Permisos independientes, cancelación, checkpoints y manejo de resultados inciertos.
- Dos ejemplos basados en IDs reales: análisis de objeto Git e importación/exportación de anotaciones Zotero.
- Esquema y validador offline para comprobar definiciones, con pruebas negativas.
- Plan de integración gradual en Axx, todavía pendiente de ejecución.

Empieza por ARQUITECTURA_ENLACES.md y PLAN_INTEGRACION.md. Consulta la documentación del validador para sus argumentos exactos, campos admitidos y resultados de pruebas.

## Estado real

El validador analiza archivos de definición. Los adaptadores, el scheduler de escritorio, la máquina de estados persistente y las acciones en las aplicaciones son propuestas. Ninguna receta fue ejecutada en la PC ni integrada al asistente. Los ejemplos tienen execution_enabled:false y deben conservarlo hasta que exista autorización y verificación específica. Las pruebas offline no certifican Git, Zotero, Windows ni la integración de Axx.

El subconjunto de catálogo conserva los IDs y contenidos existentes para comprobar referencias, sin sumarlos nuevamente al acumulado. Los contratos que los envuelven son propuestas explícitas, no capacidades descubiertas en las aplicaciones.

## Integridad y versiones

Conservar este ZIP como una instantánea y comparar SHA-256 antes de reutilizarlo. El manifiesto enumera los archivos del paquete excepto a sí mismo. Un hash verifica igualdad de bytes frente a una referencia confiable; no autentica por sí solo el autor. La carpeta mantiene los permisos de edición por enlace existentes. No incluir secretos ni datos del equipo al compartir futuros ejemplos.

El informe de revisión describe defectos encontrados y correcciones. Los archivos fuente y las pruebas incluidas pertenecen únicamente al validador de definiciones; no son un lanzador de comandos.
