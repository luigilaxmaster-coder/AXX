"""Selftests of definition validation, never of Git/Zotero/application behavior."""
import copy
import unittest
from validate_workflow import ROOT,read,validate,Invalid,digest
class DefinitionTests(unittest.TestCase):
 def setUp(self):
  self.w=read(ROOT/'workflow_git.json');self.c=read(ROOT/'contracts.json');self.k=read(ROOT/'catalog_subset.json');self.s=read(ROOT/'workflow.schema.json')
 def check(self):return validate(self.w,self.c,self.k,self.s)
 def reject(self,change):
  change()
  with self.assertRaises(Invalid):self.check()
 def test_valid_git(self):self.assertFalse(self.check()['runtime_verified'])
 def test_valid_zotero(self):self.w=read(ROOT/'workflow_zotero.json');self.assertTrue(self.check()['valid'])
 def test_missing_id(self):self.reject(lambda:self.w['steps'][0].update(recipe_id='MISSING'))
 def test_step_hash(self):self.reject(lambda:self.w['steps'][0].update(source_sha256='0'*64))
 def test_contract_hash(self):self.reject(lambda:self.c['contracts'][0].update(source_sha256='0'*64))
 def test_catalog_hash(self):self.reject(lambda:self.k['records'][0]['entry'].update(title='changed'))
 def test_cycle(self):self.reject(lambda:self.w['steps'][0].update(depends_on=['history']))
 def test_missing_dependency(self):self.reject(lambda:self.w['steps'][1].update(depends_on=[]))
 def test_unknown_dependency(self):self.reject(lambda:self.w['steps'][0].update(depends_on=['absent']))
 def test_reference_type(self):self.reject(lambda:self.c['contracts'][1]['inputs'].update(oid='LocalPDF'))
 def test_unknown_output(self):self.reject(lambda:self.w['steps'][1]['inputs']['oid'].update(port='missing'))
 def test_unknown_input(self):self.reject(lambda:self.w['steps'][0]['inputs'].update(extra={'type':'Text','literal':'x'}))
 def test_runtime_enabled(self):self.reject(lambda:self.w.update(execution_enabled=True))
 def test_runtime_numeric_false(self):self.reject(lambda:self.w.update(execution_enabled=0))
 def test_contract_enabled(self):self.reject(lambda:self.c['contracts'][0].update(execution_enabled=True))
 def test_retry_unbounded(self):self.reject(lambda:self.w['steps'][0]['retry'].update(max_attempts=99))
 def test_nonidempotent_retry(self):
  self.w=read(ROOT/'workflow_zotero.json');self.c['contracts'][2]['max_attempts']=2
  self.reject(lambda:self.w['steps'][0]['retry'].update(max_attempts=2))
 def test_permissions_missing(self):self.reject(lambda:self.w['steps'][0].update(permissions={}))
 def test_permissions_fake_grant(self):self.reject(lambda:self.w['steps'][0]['permissions'].update(read_exact_synthetic_repo='APPROVED'))
 def test_missing_guard(self):self.reject(lambda:self.w['steps'][1].pop('when'))
 def test_unverified_guard(self):self.reject(lambda:self.w['steps'][1]['when'].update(require_verified=False))
 def test_ambiguous_branch(self):self.reject(lambda:self.w['steps'][0]['on_outcome'].update(AMBIGUOUS='CONTINUE'))
 def test_unknown_route(self):self.reject(lambda:self.w['steps'][0]['on_outcome'].update(FAKE='HALT'))
 def test_unknown_field(self):self.reject(lambda:self.w.update(command='echo invalid'))
 def test_scope_mismatch(self):self.reject(lambda:self.w['steps'][1]['inputs']['repo'].update(literal='fixture/other'))
 def test_prefix_injection(self):self.reject(lambda:self.w['steps'][0]['inputs']['prefix'].update(literal='abcd; echo bad'))
 def test_duplicate_id(self):self.reject(lambda:self.w['steps'][1].update(id='resolve'))
 def test_path_traversal(self):self.reject(lambda:self.w['steps'][0]['inputs']['repo'].update(literal='fixture/../private'))
if __name__=='__main__':unittest.main(verbosity=2)
