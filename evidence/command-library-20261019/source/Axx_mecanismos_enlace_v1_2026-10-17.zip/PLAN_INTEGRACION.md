# Plan concreto de integración en Axx

Estado: propuesta técnica; no instalada. Esta entrega no altera el asistente ni habilita comandos.

## Mapa de relaciones

Mantener dos grafos separados:

- **Grafo de conocimiento**: relaciones informativas entre recetas (`produces`, `consumes`, `requires`, `alternative_to`, `compensates`, `related_to`). Puede contener ciclos, porque no es un plan de ejecución. Cada relación conserva autor, evidencia, versión y confianza; una similitud semántica es una sugerencia, no compatibilidad demostrada.
- **Grafo de ejecución**: copia congelada de los nodos elegidos para una tarea y sus dependencias; obligatoriamente acíclica. Contiene parámetros concretos, ramas explícitas y permisos por paso.

No transformar `related_to` en un enlace ejecutable. Para promover una sugerencia a `produces → consumes` deben coincidir tipo, semántica, unidad, restricciones, contexto y verificaciones. Ejemplo: un identificador de objeto Git puede ser un commit, tree o blob; no pasar un commit al nodo que necesita un blob aunque ambos se representen como hash.

## Índices y selección

Indexar los IDs existentes por objetivo, aplicación, plataforma, versión, tipos, efectos, permisos, recuperación, coste y tiempo. Usar búsqueda léxica/semántica para recuperar candidatos, y filtros deterministas para eliminar incompatibles. La similitud no debe saltarse un bloqueo de política ni rehabilitar una receta sin pruebas.

Un motor de composición podrá buscar hacia atrás desde el resultado esperado. Ejemplo: “PDF con anotaciones visibles” requiere un artefacto validado de exportación; éste consume un adjunto con anotaciones verificadas; si las anotaciones externas aún no se importaron, propone importación. Si ya existen, propone omitir esa acción y comprobar el estado. No inventar un nodo de conversión si no está registrado.

Para evitar explosión combinatoria, limitar profundidad de plan, candidatos por puerto y presupuesto de planificación. Empezar con profundidad 6, hasta 5 candidatos por puerto y 30 nodos por plan como parámetros de diseño revisables, no capacidades medidas. Cuando no haya solución compatible, devolver el requisito que falta.

## Paquetes de contratos

La receta original se conserva. Un adaptador complementario referencia `command_id` y su digest exacto; declara puertos y política. El contrato propuesto debe pasar por estados PROPOSED → REVIEWED → ADAPTER_TESTED → USER_ENABLED. El paquete actual permanece PROPOSED_ADAPTER_NOT_IMPLEMENTED incluso si la definición es válida. No usar una revisión documental como ADAPTER_TESTED.

El futuro importador necesita un mapa explícito por versión del catálogo: normalizar nombres de campos, conservar texto original y rechazar IDs duplicados con contenido conflictivo. Registrar migraciones; una versión de esquema desconocida se rechaza sin reinterpretación silenciosa. Los suplementos de prueba no pasan al registro de comandos ejecutables.

## Entregables por módulo de implementación futura

| Módulo | Trabajo concreto | Criterio de aceptación | Dependencias |
|---|---|---|---|
| Importador | Resolver IDs y versiones, verificar hashes | Rechaza contenido cambiado y IDs ambiguos | Catálogo congelado |
| Contratos | Definir entradas/salidas semánticas por adaptador | Ningún puerto obligatorio huérfano | Recetas y expertos de aplicación |
| Compilador | Tipos, DAG, ramas, límites | Casos negativos detectados con código específico | Importador y contratos |
| Política | Acción y recurso exactos, aprobación por nodo | Lectura no concede escritura ni transmisión | Identidad y política real de Axx |
| Scheduler | Cola, mutex GUI, leases, presupuestos | No interfiere con otro flujo ni usuario | Journal y adaptadores |
| Journal | Persistencia transaccional y recuperación | Reinicio no duplica un efecto incierto | Base de datos local aprobada |
| Adaptador piloto | Una herramienta de solo lectura | Resultado y postcondición comprobados en versión exacta | Autorización de ensayo |
| Verificador | Evidencia separada del emisor | Detecta clic sin efecto y salidas falsas | Observadores de aplicación |
| UI | Plan, permisos, avance, cancelar y errores | Teclado, foco y lector de pantalla; sin falsos éxitos | Estados del scheduler |

Esfuerzo aún incierto: depende de los módulos existentes, APIs disponibles y accesibilidad real de cada aplicación. No fijar fechas ni habilitar cambios antes de inspeccionar el repositorio autorizado. Prioridad P0: importador, política, verificación y cancelación; P1: piloto y journal; P2: selección automática y optimización.

## Diseño visual del flujo

Conservar el personaje Axx y sus controles radiales aprobados; añadir un panel anclado para el plan, sin reemplazarlo por una bandeja ajena al diseño. Cada nodo debe mostrar acción, aplicación, recurso, entrada, salida prevista, permiso y estado. Una flecha indica transferencia de datos o dependencia, no progreso verificado.

Estados asíncronos: esperando permiso, esperando recurso, ejecutando, verificando, pausado, cancelación solicitada, resultado incierto, error recuperable, recuperación manual y terminado. Mostrar texto e iconos, no color solamente. Orden de Tab coherente, foco visible y retorno de foco al cerrar. Compatibilidad con zoom, tamaños pequeños y reducción de movimiento. No animar éxito antes de la postcondición.

Prompt para implementación visual y continua:

“Preserva la identidad y disposición radial de Axx. Crea el visor de flujos anclado al personaje con jerarquía legible, tipografía consistente, espaciado, contraste accesible y diseño responsive. Incluye todos los estados asíncronos y sus acciones permitidas, navegación por teclado y foco visible. Separa resultado previsto, acción iniciada y evidencia verificada. Antes de cada ciclo mide errores, tiempos y accesibilidad; planifica un cambio acotado, impleméntalo, prueba con datos sintéticos y compara contra el baseline. Revierte si empeora seguridad, funcionalidad, accesibilidad o rendimiento. No cambies el permiso de un paso porque otro fue autorizado. No declares funcionando ninguna integración sin prueba real delimitada.”

## Pruebas futuras obligatorias

1. Cancelar después de un efecto y antes de guardar checkpoint; al reiniciar, conciliar y no duplicar.
2. Usuario cambia el documento durante el flujo; detener por fingerprint diferente.
3. Rama no seleccionada produce SKIPPED; ningún consumidor lee su salida.
4. Token de aprobación caducado o plan modificado; solicitar autorización nuevamente.
5. Popup toma el foco; no enviar teclas al destino equivocado.
6. Comando informa éxito pero archivo esperado no existe; INCONCLUSIVE o FAILED, nunca VERIFIED.
7. Compensación encuentra un archivo modificado por otro proceso; preservar y pedir intervención.
8. Modelo recibe texto malicioso de una web; no altera permisos ni definición congelada.
9. Dos instancias actúan sobre la misma biblioteca; solo una obtiene el recurso y el fencing token vigente.
10. Cambio de versión de aplicación; invalidar adaptador hasta comprobar compatibilidad.

Estas diez pruebas son un plan pendiente, no resultados ejecutados. Las pruebas reales de esta entrega solo evalúan definiciones offline y se enumeran en su informe correspondiente.
