# Cambios v1

17-10-2026: diseño inicial complementario, sin modificar la aplicación.

- Cuatro contratos propuestos y dos flujos de dos pasos con IDs reales.
- Comparación independiente de objetos completos y hashes con fuentes originales.
- Corrección UTF-8 explícito para lectura de JSON en Windows; prueba real en Windows pendiente.
- Aclaración: no se valida propagación SKIPPED ni joins de runtime.
- Fixture Zotero alineado: página 2, color conocido y cantidad de páginas registrada.
- 28 pruebas offline y dos ejemplos verificados en Python 3.12.14 Linux. Revisión independiente añadió 10 mutaciones negativas.
- Cero recetas ejecutadas y cero nuevas instrucciones contabilizadas.
