# Revisión independiente del mecanismo de enlaces

Fecha: 2026-10-17. Alcance: documentación y definiciones offline, sin ejecución de recetas, aplicaciones, PC, Git, Zotero ni red.

## Resultado

Sin defectos bloqueantes en el alcance declarado. Los adaptadores, autorización real, transiciones de ejecución, propagación SKIPPED, reconciliación y cancelación siguen pendientes de implementación y pruebas. Esta revisión no certifica su funcionamiento ni habilita ejecución. El complemento aporta 0 instrucciones nuevas; reutiliza cuatro entradas existentes sin alterar sus valores.

## Verificación realizada

- Lectura completa de arquitectura, plan de integración, contratos, ejemplos, esquema, validador, pruebas y límites.
- 28 pruebas incluidas ejecutadas de forma independiente: PASS.
- Dos ejemplos validados por CLI: valid:true, execution_enabled:false, runtime_verified:false.
- 10 mutaciones independientes rechazadas: versión desconocida, guardia sobre desenlace HALT, desenlace desconocido, permisos ausentes en consumidor, OID literal que simula evidencia, permiso extra, booleano como intentos, dependencia repetida, guardia propia y rutas de desenlace vacías.
- Cuatro IDs comparados con originales: Git 0028/0029, líneas 27/28 del lote 2026-10-16_1900/revised/git.jsonl; Zotero 0001/0002, líneas 1/2 del lote 2026-10-17_1800/revised/zotero.jsonl.
- En cada entrada: igualdad del objeto completo, ID, SHA-256 canónico y SHA-256 de la línea original con terminador. Coinciden. Los paths relativos finales también se resolvieron y comprobaron.
- Revisión de correspondencia semántica: OID genérico no presentado como blob demostrado; consumidor exige verificar tipo antes de log. Resultado limitado a cambios de multiplicidad. Importación Zotero conserva eliminación de anotaciones del PDF, copia de respaldo, efectos sobre biblioteca y control de sincronización. Adaptación del marcador de exportación expresamente declarada como propuesta.
- Autorización: declaraciones obligatorias por nodo, no permisos heredados ni aprobaciones reales; falsos valores APPROVED rechazados por esquema.
- Reintentos: un intento para los cuatro contratos; incertidumbre no autoriza repetición. No hay motor de reintentos.
- Higiene: revisión del contenido y búsqueda de patrones comunes de credenciales, sin coincidencias. Los ejemplos contienen datos sintéticos. Esto no equivale a garantía absoluta de ausencia de secretos.

## Correcciones verificadas

1. La documentación final precisa que cobertura de ramas significa rutas de desenlace y guardias de disponibilidad, sin prueba de SKIPPED ni uniones en ejecución.
2. El contrato final de importación exige página 2, color conocido y número de páginas registrado, alineado con la aceptación del exportador.
3. Detectada durante la revisión coordinada una dependencia de codificación por defecto que podía afectar Windows: la lectura JSON usa ahora UTF-8 explícito. Se repitieron las 28 pruebas y el ejemplo Zotero después del cambio, sin fallos ni avisos de codificación. No se realizó prueba en Windows.

Las pruebas adicionales solo alteraron definiciones en memoria. No se ejecutó ninguna acción descrita por las recetas.
