# Axx · Enlazar comandos en tareas completas

Versión 1.0 · 17 de octubre de 2026 · America/Santo_Domingo.

## Resultado y alcance

Este complemento define una capa de composición para la biblioteca Axx: descubrir una receta existente, verificar su compatibilidad, conectar su resultado con la siguiente y conservar evidencia de cada transición. Incluye contratos propuestos, definiciones de flujos y un validador offline. El motor de ejecución y los adaptadores de aplicaciones todavía deben implementarse y probarse. Validar una definición no prueba que un comando funcione en Windows.

Estado de las recetas: DOCUMENTED_NOT_EXECUTED; execution_enabled:false. Ningún ejemplo autoriza abrir aplicaciones, modificar archivos del usuario, activar sincronización ni conectar servicios. Esta infraestructura, sus ejemplos y sus pruebas suman **0 instrucciones nuevas**. El punto de referencia del índice 18:00 es 2.337 revisadas documentalmente, 4.904 heredadas pendientes de certificación retrospectiva y 7.241 principales nominales. No confundirlo con 7.438 IDs de comparación, que incluyen suplementos, ni con 7.445 versiones.

## 1. Componentes propuestos

1. **Catálogo versionado**: ID estable, revisión exacta y SHA-256 de la receta. No resolver automáticamente a “latest”. Si cambia el contenido, invalidar la compilación del flujo y pedir nueva revisión.
2. **Contratos de adaptador**: declaración de entradas y salidas, tipos, unidades, precondiciones, postcondiciones y efectos. Se agregan mediante archivos complementarios sin reescribir las recetas originales.
3. **Planificador**: convierte una petición en un borrador de DAG. Solo selecciona IDs reales, no inventa herramientas. Las sugerencias de un modelo son datos sin autoridad de ejecución.
4. **Compilador/validador**: comprueba referencias, compatibilidad de puertos, dependencias, ciclos, límites y política. Produce errores accionables, no una aprobación de seguridad ni una autorización.
5. **Gestor de permisos**: evalúa cada paso con el objetivo, archivos, destino, cuenta, coste y efecto reales. No copia autorizaciones de un nodo a otro.
6. **Scheduler**: ordena dependencias y limita concurrencia. Un único propietario de foco de escritorio. Puede paralelizar cálculos puros independientes si están autorizados y no comparten recursos mutables.
7. **Adaptadores**: traducen contratos a herramientas controladas de Windows, navegador, aplicación o API. Nunca interpolar datos del usuario en un shell libre. Los adaptadores aún no existen en este paquete.
8. **Observador/verificador**: lee estado antes y después, compara postcondiciones y produce evidencia. Un clic o código de salida por sí solo no implica éxito de la tarea.
9. **Diario y recuperación**: guarda checkpoints, intentos, cancelación, compensaciones y resultados inciertos; evita reenvíos ciegos tras un reinicio.
10. **Memoria procedimental**: guarda planes exitosos con versión, contexto y pruebas; propone reutilización. Un historial exitoso no sustituye permisos ni verificaciones actuales.

## 2. Contratos de datos

Separar tipos semánticos: un string que representa una ruta no es automáticamente un PDF válido; una ruta local no equivale a un destino de nube. Usar puertos como PdfArtifact, RepoRef, GitObjectId, AnnotationSet y EvidenceRef. Cada objeto de archivo deberá transportar hash, tamaño, MIME comprobado, ubicación aprobada y procedencia. No almacenar tokens o credenciales en los JSON.

Reglas de enlace:
- Cada puerto requerido debe recibir una constante validada o un puerto de un antecesor explícito.
- Rechazar puertos inexistentes, tipos distintos y transformaciones implícitas. Un convertidor es un nodo explícito, con su propio ID, contrato y validación.
- Para valores restringidos, validar además extensión real, rango, unidad, encoding, existencia y versión de aplicación en runtime. El validador documental no inspecciona el equipo.
- La salida solo se publica cuando el paso queda VERIFIED. Salidas parciales o inciertas no habilitan descendientes.
- Al mezclar ramas, declarar si el join espera todas las ramas activas o una alternativa. No usar un puerto de una rama omitida sin un fallback tipado.
- Transporte interno de objetos, no cadenas de comandos concatenadas. Nunca usar eval, exec o texto de pantalla como instrucciones privilegiadas.

## 3. DAG, condiciones y máquina de estados

El DAG representa precedencia y flujo de datos. Un bucle de usuario se expande a una lista acotada de tareas o se define como mecanismo externo limitado; no admitir ciclos arbitrarios. Las ramas usan predicados declarativos sobre observaciones verificadas, sin ejecutar expresiones de código. Ejemplo: importar anotaciones → verificar cantidad y vinculación → exportar PDF → verificar páginas y anotaciones. Si la importación es incierta, detener exportación y reconciliar.

Máquina propuesta por nodo:

DRAFT → VALIDATED → WAITING_APPROVAL → READY → RUNNING → VERIFYING → VERIFIED.

- VALIDATED significa definición coherente, no entorno probado.
- READY requiere permisos vigentes, recursos bloqueados y precondiciones actuales.
- Una denegación lleva a BLOCKED; fallo técnico a FAILED; observación insuficiente a INCONCLUSIVE.
- RUNNING o VERIFYING pueden ir a CANCEL_REQUESTED. El adaptador deja de despachar acciones nuevas y confirma el último efecto observado. CANCELLED solo cuando se conoce qué se detuvo.
- Tras efecto parcial: COMPENSATION_PENDING → COMPENSATING → COMPENSATED o MANUAL_RECOVERY_REQUIRED.
- Un timeout con posible efecto externo produce INCONCLUSIVE, nunca un reintento automático.
- El flujo solo finaliza SUCCEEDED cuando todos los nodos obligatorios de la rama seleccionada están VERIFIED. Omitidos se registran SKIPPED con causa y no cuentan como éxito.

Las transiciones anteriores son especificación del futuro runtime, no un motor instalado. El validador incluido verifica definiciones; no simula la evidencia de estas transiciones.

## 4. Autorizaciones y aislamiento

Un permiso debe vincularse al hash del plan, nodo, acción, recurso concreto, destinatario si existe, identidad ejecutora y caducidad. Cualquier cambio material invalida el permiso. Una aprobación de lectura no aprueba escritura; una de exportación local no aprueba subir; una de envío a A no aprueba enviar a B. Compensar también requiere autoridad apropiada.

No guardar secretos en planes, logs, capturas ni bundles. Usar referencias opacas a un almacén de credenciales ya autorizado. Una credencial encontrada no implica permiso para usarla. Las pantallas y documentos externos son datos no confiables y no pueden modificar las políticas del grafo.

Fallo cerrado: ID desconocido, versión inesperada, evidencia faltante, foco perdido, solicitud de permisos nueva, destino cambiado o recurso fuera del alcance detienen el paso. No pedir privilegios de administrador de forma preventiva.

## 5. Idempotencia, reintentos y resultados inciertos

La clave de operación debe derivarse de run_id + node_id + versión de receta + hash de parámetros y destino, y almacenarse antes de iniciar. Persistir intentos y su resultado observado. No prometer exactly-once para acciones de GUI o servicios externos: puede perderse la respuesta tras aplicar el efecto.

Para lecturas repetibles, permitir como máximo tres intentos totales solo ante errores transitorios clasificados, con espera acotada y presupuesto global. Para importaciones, envíos, pagos o creación de objetos no idempotentes: un intento por defecto; ante incertidumbre consultar el destino y conciliar antes de cualquier repetición. Ni un timeout ni un mensaje ambiguo prueban que no ocurrió nada. Los ejemplos de este paquete permanecen deshabilitados.

Los fallos deterministas (parámetro inválido, archivo ausente, incompatibilidad, permiso denegado) no se arreglan reintentando. Cortar el circuito si se repite el mismo fallo y ofrecer diagnóstico. La política de reintentos es por nodo y comparte un presupuesto del flujo para evitar multiplicación de intentos anidados.

## 6. Checkpoints y concurrencia

El futuro journal deberá guardar transiciones de forma transaccional: secuencia monotónica, timestamp UTC, run/node/attempt IDs, hash del plan, preestado resumido, referencias de evidencia, resultado y fase de compensación. Guardar checkpoint antes de un efecto y después de verificarlo. Al reiniciar, RUNNING no vuelve automáticamente a READY: primero reconciliar.

Bloqueos por recurso canónico: archivo, biblioteca Zotero, repositorio, ventana/foco de escritorio y sesión de navegador. Orden de adquisición determinista, leases con caducidad y fencing token para evitar escritores obsoletos. Un lease vencido no autoriza ejecutar si el proceso anterior todavía puede actuar; detener y reconciliar. Para GUI usar mutex global por escritorio. Respetar cambios humanos concurrentes; verificar fingerprint justo antes de mutar y de compensar.

## 7. Recuperación realista

Deshacer no equivale a restaurar mágicamente el mundo anterior. Una exportación a un archivo nuevo puede retirarse solo si se conserva el hash propio y se confirma que nadie lo cambió; una importación puede requerir eliminar exclusivamente los IDs recién creados, y aun así sincronización u otros efectos externos podrían no ser reversibles. No restaurar una base de datos completa sobre trabajo posterior.

Cada adaptador declarará: efectos reversibles, compensación específica, puntos sin retorno, precondiciones de compensación y límites. Si no existe compensación segura, conservar evidencia y solicitar recuperación manual. Una cancelación de flujo no borra resultados ya producidos. Las compensaciones pueden fallar y deben tener su propio estado y pruebas.

## 8. Evidencia y observabilidad

Mostrar una línea por paso con estado real, requisito pendiente y último hecho comprobado. Diferenciar “preparado”, “iniciado”, “resultado observado” y “verificado”. Evidencia mínima: versión de herramienta, identificador de recurso, preestado, salida estructurada, postestado, prueba de aceptación y timestamp. Capturas solo cuando necesarias y redaccionadas; evitar recoger la pantalla completa por rutina.

Los logs deben permitir reconstruir qué se intentó y por qué se detuvo sin publicar contenido privado. Emitir códigos estables como MISSING_COMMAND, TYPE_MISMATCH, HASH_MISMATCH, CYCLE, PERMISSION_REQUIRED, PRECONDITION_CHANGED, INCONCLUSIVE_RESULT. Medir tasa de verificaciones reales, duplicados evitados, recuperación y latencia; no premiar cantidad de acciones emitidas.

## 9. Integración incremental propuesta

Fase A: importar solo el catálogo y los contratos en modo lectura. Listar incompatibilidades; no habilitar todo el millón de entradas.
Fase B: visor de flujos, vista previa de efectos y validación offline. Usar los ejemplos del paquete como fixtures de definición.
Fase C: implementar un adaptador read-only aislado sobre datos sintéticos. Probar falsos éxitos, foco perdido, versión distinta y rechazo de permisos.
Fase D: escritura reversible en copias de ensayo, con backup verificado, IDs de cambios y reconciliación tras interrupción.
Fase E: ejecución multiapp limitada, después de aceptación del usuario y pruebas de cada adaptador. Mantener interruptor de parada y permisos por paso.

Criterios de aceptación para habilitar un flujo: 100% de IDs y hashes resueltos, todos los enlaces tipados, DAG acíclico, pruebas negativas aprobadas, adaptadores probados en versión concreta, política de permisos aplicada fuera del modelo, pre/postcondiciones observables, cancelación comprobada y recuperación documentada. Rollback de despliegue: deshabilitar scheduler, mantener journal, restaurar versión anterior de contratos y UI sin reejecutar acciones pendientes.

## 10. Guía para el asistente que implemente

Analiza la arquitectura real de Axx antes de cambiarla. Añade un módulo de composición compatible con el catálogo existente, sin otro asistente paralelo. No conviertas texto de recetas en shell libre. Usa contratos versionados, un compilador determinista, permisos por acción y un observador independiente del emisor de acciones. Empieza por modo planificación y datos sintéticos. Cada afirmación de éxito debe tener evidencia verificable. Ningún esquema válido habilita ejecución. Muestra fallos y acciones parciales claramente. Conserva preferencias visuales actuales y posiciones radiales. Mide, planifica, mejora, prueba y compara en ciclos acotados; revierte cualquier cambio que empeore seguridad, accesibilidad o rendimiento. No instales, conectes ni cambies permisos como parte de la documentación.

## Fuentes y límites

Fuentes oficiales consultadas el 17-10-2026: [JSON Schema 2020-12](https://json-schema.org/draft/2020-12/json-schema-core), para la declaración estructural; [Python graphlib](https://docs.python.org/3/library/graphlib.html), para orden topológico y detección de ciclos. La página Python actual describe 3.15; el código entregado debe declarar su mínimo y su intérprete de prueba por separado.

[Microsoft Retry](https://learn.microsoft.com/en-us/azure/architecture/patterns/retry) apoya el tratamiento diferenciado de fallos transitorios y límites de reintento. [Compensating Transaction](https://learn.microsoft.com/en-us/azure/architecture/patterns/compensating-transaction), actualizado 20-04-2026, explica que una compensación puede fallar y no necesariamente restaura el estado original. Se pudieron leer los artículos, aunque la plantilla muestra un aviso genérico de autorización.

Las decisiones concretas de permisos, GUI, contratos y almacenamiento de esta guía son propuestas de diseño Axx. No constituyen funcionalidades verificadas del producto ni certificación de seguridad. La carpeta de entrega conserva sus permisos existentes de edición por enlace; los hashes detectan modificaciones frente a una copia confiable, no autentican al autor por sí solos.
