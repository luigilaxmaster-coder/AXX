# Validador offline: alcance exacto

Este prototipo valida definiciones. No implementa un motor de ejecución, adaptadores, permisos ni verificaciones de aplicaciones. Los cuatro contratos tienen estado `PROPOSED_ADAPTER_NOT_IMPLEMENTED`; las recetas conservan `execution_enabled: false`. Los dos flujos que pasan la validación son ejemplos documentales. Sus condiciones describen resultados futuros verificados, no observaciones realizadas aquí.

## Archivos y uso

- `workflow.schema.json`: esquema cerrado de flujos, JSON Schema 2020-12.
- `contracts.json`: cuatro contratos propuestos, con tipos, efectos, permisos exigidos, precondiciones, poscondiciones y salidas disponibles según el resultado.
- `catalog_subset.json`: cuatro entradas originales completas, sin modificar sus valores, con procedencia y hashes. Las rutas son relativas a la raíz de la biblioteca horaria. `source_line_sha256` identifica los bytes originales de cada línea JSONL, incluido el salto de línea. `entry_sha256` identifica JSON UTF-8 con claves ordenadas, sin espacios insignificantes, Unicode sin escapar y sin números no finitos. Se conservan todos los valores originales, pero no el formato textual de la línea.
- `workflow_git.json`: 0029 resuelve un prefijo y 0028 busca cambios de presencia del blob en el mismo repositorio. Un OID no demuestra que el objeto sea un blob: el segundo contrato exige comprobar el tipo antes de consultar el historial. No se obtiene un historial exhaustivo de renombres ni prueba de la primera introducción.
- `workflow_zotero.json`: 0002 importa anotaciones y 0001 exporta una copia que deberá comprobarse en un lector externo. La importación modifica PDF y biblioteca y exige un respaldo que se abra correctamente. El marcador de aceptación de la exportación se convierte en parámetro propuesto: adapta el ENSAYO fijo de la receta al ENSAYO_EXTERNO TEST importado. No se han alterado las entradas originales. Ambas operaciones se consideran no idempotentes y permiten un solo intento.

Desde esta carpeta:

    python validate_workflow.py workflow_git.json
    python validate_workflow.py workflow_zotero.json
    python -m unittest test_validator -v

Solo se necesita la biblioteca estándar de Python. Versión ensayada: Python 3.12.14 en Linux. Mínimo declarado para esta entrega: Python 3.12; otras versiones y Windows no se han ensayado. Los archivos JSON se leen explícitamente como UTF-8, sin depender de la configuración regional de Windows. El validador lee JSON local y comunica compatibilidad de definiciones. Nunca evalúa comandos ni invoca subprocesos, aplicaciones, red o el ordenador del usuario.

## Comprobaciones implementadas

El esquema enumera todos los campos admitidos del flujo, pasos, enlaces, condiciones y reintentos; rechaza campos desconocidos. El validador implementa exactamente el subconjunto de palabras clave que usa ese esquema y añade: IDs duplicados; recetas y dependencias conocidas; hashes canónicos de entradas incorporadas y referencias fijadas en contratos/pasos; ejecución desactivada; puertos obligatorios; referencias a salidas; igualdad exacta de tipos nominales; ausencia de ciclos; dependencias explícitas; condiciones de disponibilidad de salidas; cobertura de rutas declaradas por resultado (no propagación de SKIPPED ni uniones en ejecución); salida HALT obligatoria para resultados no verificados; declaraciones de permisos por paso; límites de intentos y prohibición de repetir operaciones no idempotentes. En el enlace Git demostrado, comprueba el mismo repositorio simbólico. Restringe rutas simbólicas de ensayo y prefijos hexadecimales. Al cargar archivos rechaza claves JSON duplicadas y constantes numéricas no finitas.

## Lo que no comprueba ni certifica

No es un motor general de JSON Schema: solo implementa las palabras clave del esquema incluido. `contracts.json` y `catalog_subset.json` no tienen esquemas JSON propios. Se comprueban campos centrales, identidades, hashes, ejecución desactivada, reintentos y presencia de metadatos; siguen siendo entradas locales de diseño, no autoridades autenticadas. No puede detectar una alteración coordinada de entradas y hashes sin una fuente independiente de confianza. Comprueba los hashes canónicos de las entradas incorporadas, no los hashes de líneas originales: el paquete portátil no contiene los JSONL originales. Estos últimos hashes permiten una comparación independiente de procedencia.

Los efectos, precondiciones y poscondiciones del contrato son requisitos informativos para revisión humana. Se comprueba su presencia, no su cumplimiento. Los tipos nominales son nombres propuestos: no prueban existencia o contenido de archivos, tipo real de objeto, permisos, estado de interfaz ni finalización de acciones. Los permisos deben conservar el valor `REQUIRES_APPROVAL_AT_RUNTIME`; declararlos no los concede. `require_verified: true` exige una futura comprobación, pero no aporta evidencia ni certifica resultados de aplicaciones. Las rutas simbólicas no autorizan acceso y no se resuelven contra el sistema de archivos. No se implementan conjunciones de condiciones de varios productores, conversiones implícitas, planificador paralelo, ejecución ni reintentos automáticos. Los formatos arbitrariamente malformados de contratos/catálogos quedan fuera de la garantía del esquema de flujos.

Todos los contratos limitan los intentos a uno, incluidas las lecturas Git, para no ampliar las reglas originales de recuperación. El esquema genérico permite un máximo de tres; prevalece el límite más estricto del contrato. Ninguna rama repara, instala, cambia seguridad, descarga, sincroniza, sobrescribe ni repite una mutación incierta.
